﻿using System;
using System.Collections.Generic;

namespace Bookify.Core.DTOs
{
    public class BookingDto
    {
        public int Id { get; set; }
        public string UserId { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public string UserEmail { get; set; } = string.Empty;
        public int RoomId { get; set; }
        public string RoomNumber { get; set; } = string.Empty;
        public int RoomTypeId { get; set; }
        public string RoomTypeName { get; set; } = string.Empty;
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public int NumberOfGuests { get; set; }
        public decimal TotalAmount { get; set; }
        public string BookingStatus { get; set; } = string.Empty;
        public string ConfirmationCode { get; set; } = string.Empty;
        public DateTime BookingDate { get; set; }
        public string SpecialRequests { get; set; } = string.Empty;
        public int TotalNights { get; set; }
        public DateTime? CancellationDate { get; set; }
        public string? CancellationReason { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }

    }

    public class CreateBookingDto
    {
        public string UserId { get; set; } = string.Empty;
        public int RoomTypeId { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public int NumberOfGuests { get; set; }
        public string SpecialRequests { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }
        public string RoomTypeName { get; set; }
        public string RoomTypeDescription { get; set; }

    }

    public class UpdateBookingDto
    {
        public int Id { get; set; }
        public string BookingStatus { get; set; } = string.Empty;
        public string SpecialRequests { get; set; } = string.Empty;
    }

    public class BookingFilterDto
    {
        public string ConfirmationCode { get; set; } = string.Empty;
        public DateTime? CheckInDateFrom { get; set; }
        public DateTime? CheckInDateTo { get; set; }
        public string BookingStatus { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }
}