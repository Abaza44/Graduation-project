﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Bookify.Core.DTOs
{
    public class RoomDto
    {
        public int Id { get; set; }
        public int RoomTypeId { get; set; }
        public string RoomTypeName { get; set; } = string.Empty;
        public string RoomNumber { get; set; } = string.Empty;
        public string Floor { get; set; } = string.Empty;
        public string View { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public string? AdditionalNotes { get; set; }
        public DateTime? LastMaintenanceDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public int TotalBookings { get; set; }
        public int ActiveBookings { get; set; }
    }

    public class CreateRoomDto
    {
        [Required(ErrorMessage = "Room type is required")]
        public int RoomTypeId { get; set; }

        [Required(ErrorMessage = "Room number is required")]
        [StringLength(10, ErrorMessage = "Room number cannot exceed 10 characters")]
        public string RoomNumber { get; set; } = string.Empty;

        [Required(ErrorMessage = "Floor is required")]
        [StringLength(10, ErrorMessage = "Floor cannot exceed 10 characters")]
        public string Floor { get; set; } = string.Empty;

        [Required(ErrorMessage = "View is required")]
        public string View { get; set; } = string.Empty;

        [Required(ErrorMessage = "Status is required")]
        public string Status { get; set; } = "Available";

        [StringLength(500, ErrorMessage = "Additional notes cannot exceed 500 characters")]
        public string? AdditionalNotes { get; set; }

        public DateTime? LastMaintenanceDate { get; set; }
    }

    public class UpdateRoomDto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Room type is required")]
        public int RoomTypeId { get; set; }

        [Required(ErrorMessage = "Room number is required")]
        [StringLength(10, ErrorMessage = "Room number cannot exceed 10 characters")]
        public string RoomNumber { get; set; } = string.Empty;

        [Required(ErrorMessage = "Floor is required")]
        [StringLength(10, ErrorMessage = "Floor cannot exceed 10 characters")]
        public string Floor { get; set; } = string.Empty;

        [Required(ErrorMessage = "View is required")]
        public string View { get; set; } = string.Empty;

        [Required(ErrorMessage = "Status is required")]
        public string Status { get; set; } = "Available";

        [StringLength(500, ErrorMessage = "Additional notes cannot exceed 500 characters")]
        public string? AdditionalNotes { get; set; }

        public DateTime? LastMaintenanceDate { get; set; }
    }
}