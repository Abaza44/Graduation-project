﻿using System;
using System.Collections.Generic;

namespace Bookify.Core.DTOs
{
    public class RoomWithDetailsDto
    {
        public int Id { get; set; }
        public string RoomNumber { get; set; } = string.Empty;
        public int RoomTypeId { get; set; }
        public string RoomTypeName { get; set; } = string.Empty;
        public string Floor { get; set; } = string.Empty;
        public string View { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public string? AdditionalNotes { get; set; }
        public DateTime? LastMaintenanceDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public int TotalBookings { get; set; }
        public int ActiveBookings { get; set; }
    }
}