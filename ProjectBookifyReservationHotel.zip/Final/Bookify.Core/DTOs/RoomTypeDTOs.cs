﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Bookify.Core.DTOs
{
    public class RoomTypeDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal PricePerNight { get; set; }
        public int Capacity { get; set; }
        public decimal SizeInSqFt { get; set; }
        public bool IsActive { get; set; }
        public List<string> ImageUrls { get; set; } = new();
        public List<string> Amenities { get; set; } = new();
        public List<int> AmenityIds { get; set; } = new(); // Added
        public double AverageRating { get; set; }
        public int TotalReviews { get; set; }
        public int AvailableRooms { get; set; } // Changed from AvailableRoomsCount
        public int TotalRooms { get; set; } // Added
        public int TotalBookings { get; set; } // Added
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
    }

    public class CreateRoomTypeDto
    {
        [Required(ErrorMessage = "Room type name is required")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Price per night is required")]
        [Range(0.01, 10000, ErrorMessage = "Price must be between $0.01 and $10,000")]
        public decimal PricePerNight { get; set; }

        [Required(ErrorMessage = "Capacity is required")]
        [Range(1, 20, ErrorMessage = "Capacity must be between 1 and 20 guests")]
        public int Capacity { get; set; }

        [Required(ErrorMessage = "Room size is required")]
        [Range(1, 5000, ErrorMessage = "Room size must be between 1 and 5000 sq ft")]
        public decimal SizeInSqFt { get; set; }

        public List<int> AmenityIds { get; set; } = new();
    }

    public class UpdateRoomTypeDto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Room type name is required")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Price per night is required")]
        [Range(0.01, 10000, ErrorMessage = "Price must be between $0.01 and $10,000")]
        public decimal PricePerNight { get; set; }

        [Required(ErrorMessage = "Capacity is required")]
        [Range(1, 20, ErrorMessage = "Capacity must be between 1 and 20 guests")]
        public int Capacity { get; set; }

        [Required(ErrorMessage = "Room size is required")]
        [Range(1, 5000, ErrorMessage = "Room size must be between 1 and 5000 sq ft")]
        public decimal SizeInSqFt { get; set; }

        public bool IsActive { get; set; }
        public List<int> AmenityIds { get; set; } = new();
        public int AvailableRoomsCount { get; set; }

    }
}