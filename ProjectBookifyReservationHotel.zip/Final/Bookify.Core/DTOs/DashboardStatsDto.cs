﻿using System;
using System.Collections.Generic;

namespace Bookify.Core.DTOs
{
    public class DashboardStatsDto
    {
        public int TotalBookingsToday { get; set; }
        public int TotalBookingsThisMonth { get; set; }
        public decimal RevenueToday { get; set; }
        public decimal RevenueThisMonth { get; set; }
        public int AvailableRooms { get; set; }
        public int TotalRooms { get; set; }
        public double OccupancyRate { get; set; }
        public int PendingBookings { get; set; }
        public int CheckInsToday { get; set; }
        public int CheckOutsToday { get; set; }
    }

    public class RevenueReportDto
    {
        public DateTime Date { get; set; }
        public decimal Revenue { get; set; }
        public int BookingsCount { get; set; }
    }

    public class OccupancyReportDto
    {
        public DateTime Date { get; set; }
        public int OccupiedRooms { get; set; }
        public int TotalRooms { get; set; }
        public double OccupancyRate { get; set; }
    }

    public class PopularRoomTypeDto
    {
        public string RoomTypeName { get; set; }
        public int BookingsCount { get; set; }
        public decimal TotalRevenue { get; set; }
    }
}