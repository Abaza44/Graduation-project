﻿using System.ComponentModel.DataAnnotations;

namespace Bookify.Core.DTOs
{
    public class AmenityDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string IconClass { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
        public int UsageCount { get; set; } // عدد المرات المستخدمة
        public bool IsActive { get; set; } = true;
    }

    public class CreateAmenityDto
    {
        [Required(ErrorMessage = "Amenity name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
        public string Name { get; set; } = string.Empty;

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
        public string Description { get; set; } = string.Empty;

        [StringLength(50, ErrorMessage = "Icon class cannot exceed 50 characters")]
        public string IconClass { get; set; } = "fas fa-check";

        public bool IsActive { get; set; } = true;
    }

    public class UpdateAmenityDto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Amenity name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
        public string Name { get; set; } = string.Empty;

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
        public string Description { get; set; } = string.Empty;

        [StringLength(50, ErrorMessage = "Icon class cannot exceed 50 characters")]
        public string IconClass { get; set; } = "fas fa-check";

        public bool IsActive { get; set; } = true;
    }

    public class AmenityUsageDto
    {
        public int AmenityId { get; set; }
        public string AmenityName { get; set; } = string.Empty;
        public int RoomTypeCount { get; set; }
        public int TotalUsage { get; set; }
    }
}