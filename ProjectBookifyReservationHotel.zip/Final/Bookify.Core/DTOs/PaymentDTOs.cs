﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Bookify.Core.DTOs
{
    public class PaymentDto
    {
        public int Id { get; set; }
        public int BookingId { get; set; }
        public string BookingConfirmationCode { get; set; } = string.Empty;
        public string PaymentMethod { get; set; } = string.Empty;
        public string TransactionId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Currency { get; set; } = string.Empty;
        public string PaymentStatus { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime PaymentDate { get; set; }
        public DateTime? ProcessedDate { get; set; }
        public DateTime? RefundDate { get; set; }
        public string LastFourDigits { get; set; } = string.Empty;
        public string CardType { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
    }

    public class CreatePaymentDto
    {
        [Required]
        public int BookingId { get; set; }

        [Required]
        [MaxLength(50)]
        public string PaymentMethod { get; set; } = string.Empty;

        [Required]
        [Range(0.01, 100000)]
        public decimal Amount { get; set; }

        [MaxLength(500)]
        public string Description { get; set; } = string.Empty;

        // Credit Card Information (for simulation)
        [RequiredIfPaymentMethod("CreditCard")]
        [CreditCard]
        public string CardNumber { get; set; } = string.Empty;

        [RequiredIfPaymentMethod("CreditCard")]
        [StringLength(5, MinimumLength = 5)]
        public string ExpiryDate { get; set; } = string.Empty; // MM/YY

        [RequiredIfPaymentMethod("CreditCard")]
        [StringLength(4, MinimumLength = 3)]
        public string CVV { get; set; } = string.Empty;

        [RequiredIfPaymentMethod("CreditCard")]
        public string CardHolderName { get; set; } = string.Empty;
    }

    public class ProcessPaymentDto
    {
        [Required]
        public int PaymentId { get; set; }

        [Required]
        [MaxLength(100)]
        public string TransactionId { get; set; } = string.Empty;

        [Required]
        [MaxLength(20)]
        public string PaymentStatus { get; set; } = string.Empty;

        [MaxLength(1000)]
        public string PaymentResponse { get; set; } = string.Empty;
    }

    public class RefundPaymentDto
    {
        [Required]
        public int PaymentId { get; set; }

        [MaxLength(500)]
        public string RefundReason { get; set; } = string.Empty;

        [Range(0.01, 100000)]
        public decimal? RefundAmount { get; set; } // Partial refund if null, full refund if specified
    }

    public class PaymentFilterDto
    {
        public string TransactionId { get; set; } = string.Empty;
        public string PaymentStatus { get; set; } = string.Empty;
        public string PaymentMethod { get; set; } = string.Empty;
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public decimal? MinAmount { get; set; }
        public decimal? MaxAmount { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }

    public class PaymentConfirmationDto
    {
        // Payment Method: CreditCard, PayPal, Wallet
        [Required]
        public string PaymentMethod { get; set; } = "CreditCard";

        public string? StripePaymentIntentId { get; set; }
        // ============ Credit Card Fields ============
        [RequiredIfPaymentMethod("CreditCard")]
        public string? CardholderName { get; set; }

        [RequiredIfPaymentMethod("CreditCard")]
        [CreditCard]
        public string? CardNumber { get; set; }

        [RequiredIfPaymentMethod("CreditCard")]
        [StringLength(5, MinimumLength = 5)]
        public string? ExpiryDate { get; set; }

        [RequiredIfPaymentMethod("CreditCard")]
        [StringLength(4, MinimumLength = 3)]
        public string? CVV { get; set; }

        public string? ZipCode { get; set; }

        public bool SaveCard { get; set; }

        // ============ PayPal Fields ============
        [RequiredIfPaymentMethod("PayPal")]
        public string? PayPalOrderId { get; set; }

        public string? PayPalPayerId { get; set; }

        public string? PayPalPayerEmail { get; set; }

        // ============ Wallet Fields ============
        // (Additional wallet fields if needed)
    }

    // Custom validation attribute
    public class RequiredIfPaymentMethodAttribute : ValidationAttribute
    {
        private readonly string _paymentMethod;

        public RequiredIfPaymentMethodAttribute(string paymentMethod)
        {
            _paymentMethod = paymentMethod;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var instance = validationContext.ObjectInstance;
            var methodProperty = instance.GetType().GetProperty("PaymentMethod");

            if (methodProperty != null)
            {
                var methodValue = methodProperty.GetValue(instance) as string;
                if (methodValue == _paymentMethod && (value == null || string.IsNullOrWhiteSpace(value.ToString())))
                {
                    return new ValidationResult($"{validationContext.DisplayName} is required when PaymentMethod is {_paymentMethod}.");
                }
            }

            return ValidationResult.Success;
        }
    }
}