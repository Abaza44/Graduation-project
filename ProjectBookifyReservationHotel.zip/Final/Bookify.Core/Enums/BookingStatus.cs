﻿namespace Bookify.Core.Enums
{
    public enum BookingStatus
    {
        Pending,
        Confirmed,
        CheckedIn,
        CheckedOut,
        Cancelled
    }

    public enum RoomStatus
    {
        Available,
        Occupied,
        Maintenance,
        Cleaning
    }

    public enum PaymentStatus
    {
        Pending,
        Completed,
        Failed,
        Refunded
    }

    public enum PaymentMethod
    {
        CreditCard,
        PayPal,
        Cash
    }
}