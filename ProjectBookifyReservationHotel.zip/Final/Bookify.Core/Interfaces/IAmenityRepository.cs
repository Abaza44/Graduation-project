﻿using Bookify.Core.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces
{
    public interface IAmenityRepository : IGenericRepository<Amenity>
    {
        Task<IEnumerable<Amenity>> GetAmenitiesByRoomTypeAsync(int roomTypeId);
        Task<IEnumerable<Amenity>> GetPopularAmenitiesAsync(int count = 10);
        Task<bool> IsAmenityUsedAsync(int amenityId);
    }
}