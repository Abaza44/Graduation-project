﻿using Bookify.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces
{
    public interface IReviewRepository : IGenericRepository<Review>
    {
        Task<IEnumerable<Review>> GetReviewsByRoomTypeAsync(int roomTypeId);
        Task<IEnumerable<Review>> GetReviewsByUserAsync(string userId);
        Task<IEnumerable<Review>> GetApprovedReviewsAsync();
        Task<IEnumerable<Review>> GetPendingReviewsAsync();
        Task<double> GetAverageRatingAsync(int roomTypeId);
        Task<int> GetReviewCountAsync(int roomTypeId);
    }
}