﻿using Bookify.Core.Entities;
using Bookify.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces
{
    public interface IRoomTypeRepository : IGenericRepository<RoomType>
    {
        // Existing methods
        Task<IEnumerable<RoomType>> GetRoomTypesWithImagesAsync();
        Task<RoomType> GetRoomTypeWithDetailsAsync(int id);
        Task<IEnumerable<RoomType>> GetActiveRoomTypesAsync();
        Task<IEnumerable<RoomType>> GetAvailableRoomTypesAsync(DateTime checkIn, DateTime checkOut);
        Task<IEnumerable<RoomType>> FilterRoomTypesAsync(RoomTypeFilterDto filter);

        // New methods for amenities
        Task<bool> IsAmenityUsedAsync(int amenityId);
        Task<IEnumerable<RoomType>> GetAllRoomTypesWithAmenitiesAsync();

        // Rating methods
        Task<double> GetAverageRatingAsync(int roomTypeId);

        // New methods for statistics and popular room types
        Task<RoomTypeStatistics> GetRoomTypeStatisticsAsync(int roomTypeId);
        Task<IEnumerable<RoomType>> GetPopularRoomTypesAsync(int count = 5);
    }

    // Move the helper class to the interface file or create a separate DTO
    public class RoomTypeStatistics
    {
        public int TotalRooms { get; set; }
        public int AvailableRooms { get; set; }
        public int TotalBookings { get; set; }
        public int TotalReviews { get; set; }
        public double AverageRating { get; set; }
    }
}