﻿using System;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        // Repositories
        IRoomTypeRepository RoomTypes { get; }
        IRoomRepository Rooms { get; }
        IBookingRepository Bookings { get; }
        IAmenityRepository Amenities { get; }
        IImageRepository Images { get; }
        IPaymentRepository Payments { get; }
        IReviewRepository Reviews { get; }

        // Transaction support
        Task BeginTransactionAsync();
        Task CommitTransactionAsync();
        Task RollbackTransactionAsync();

        Task<int> SaveChangesAsync();
    }
}