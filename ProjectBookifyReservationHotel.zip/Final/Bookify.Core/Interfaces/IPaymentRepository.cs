﻿using Bookify.Core.Entities;
using Bookify.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces
{
    public interface IPaymentRepository : IGenericRepository<Payment>
    {
        Task<Payment> GetPaymentWithDetailsAsync(int id);
        Task<Payment> GetPaymentByTransactionIdAsync(string transactionId);
        Task<IEnumerable<Payment>> GetPaymentsByBookingAsync(int bookingId);
        Task<IEnumerable<Payment>> GetPaymentsByUserAsync(string userId);
        Task<IEnumerable<Payment>> FilterPaymentsAsync(PaymentFilterDto filter);
        Task<IEnumerable<Payment>> GetPaymentsByStatusAsync(string status);
        Task<IEnumerable<Payment>> GetPendingPaymentsAsync();
        Task<decimal> GetTotalRevenueAsync(DateTime? startDate = null, DateTime? endDate = null);
        Task<int> GetPaymentCountByStatusAsync(string status);
        Task<bool> TransactionIdExistsAsync(string transactionId);
    }
}