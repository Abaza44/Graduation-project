﻿using Bookify.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces.Services
{
    public interface IReviewService
    {
        Task<ReviewDto> GetReviewByIdAsync(int id);
        Task<IEnumerable<ReviewDto>> GetReviewsByRoomTypeAsync(int roomTypeId);
        Task<IEnumerable<ReviewDto>> GetReviewsByUserAsync(string userId);
        Task<IEnumerable<ReviewDto>> GetPendingReviewsAsync();
        Task<ReviewDto> CreateReviewAsync(CreateReviewDto dto);
        Task<bool> UpdateReviewAsync(UpdateReviewDto dto);
        Task<bool> DeleteReviewAsync(int id);
        Task<bool> ApproveReviewAsync(int id);
        Task<bool> RejectReviewAsync(int id);
        Task<ReviewSummaryDto> GetReviewSummaryAsync(int roomTypeId);
        Task<IEnumerable<ReviewDto>> GetAllReviewsAsync();
        Task<bool> UpdateReviewStatusAsync(int id, string status);
        Task<IEnumerable<ReviewDto>> GetReviewsByStatusAsync(string status);
        Task<ReviewStatisticsDto> GetReviewStatisticsAsync();
    }

    public class ReviewSummaryDto
    {
        public double AverageRating { get; set; }
        public int TotalReviews { get; set; }
        public int FiveStar { get; set; }
        public int FourStar { get; set; }
        public int ThreeStar { get; set; }
        public int TwoStar { get; set; }
        public int OneStar { get; set; }
    }
    // في Bookify.Core/DTOs/ReviewDto.cs أو ملف منفصل
    public class ReviewStatisticsDto
    {
        public int TotalReviews { get; set; }
        public int ApprovedReviews { get; set; }
        public int PendingReviews { get; set; }
        public double AverageRating { get; set; }
        public int TotalRoomTypes { get; set; }
        public int RecentReviews { get; set; }

        // إحصائيات إضافية
        public int FiveStarReviews { get; set; }
        public int FourStarReviews { get; set; }
        public int ThreeStarReviews { get; set; }
        public int TwoStarReviews { get; set; }
        public int OneStarReviews { get; set; }
    }
}