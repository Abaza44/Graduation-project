﻿using Bookify.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces.Services
{
    public interface IAmenityService
    {
        Task<IEnumerable<AmenityDto>> GetAllAmenitiesAsync();
        Task<AmenityDto> GetAmenityByIdAsync(int id);
        Task<AmenityDto> CreateAmenityAsync(CreateAmenityDto dto);
        Task<AmenityDto> UpdateAmenityAsync(UpdateAmenityDto dto);
        Task<bool> DeleteAmenityAsync(int id);
        Task<bool> AmenityExistsAsync(string name, int? id = null);
        Task<IEnumerable<AmenityUsageDto>> GetAmenityUsageStatsAsync();
    }
}