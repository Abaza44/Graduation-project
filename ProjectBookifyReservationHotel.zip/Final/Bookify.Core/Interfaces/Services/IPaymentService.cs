﻿using Bookify.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces.Services
{
    public interface IPaymentService
    {
        Task<PaymentDto> GetPaymentByIdAsync(int id);
        Task<PaymentDto> GetPaymentByTransactionIdAsync(string transactionId);
        Task<IEnumerable<PaymentDto>> GetPaymentsByBookingAsync(int bookingId);
        Task<IEnumerable<PaymentDto>> GetPaymentsByUserAsync(string userId);
        Task<IEnumerable<PaymentDto>> FilterPaymentsAsync(PaymentFilterDto filter);
        Task<PaymentDto> CreatePaymentAsync(CreatePaymentDto dto);
        Task<PaymentDto> ProcessPaymentAsync(ProcessPaymentDto dto);
        Task<bool> RefundPaymentAsync(RefundPaymentDto dto);
        Task<bool> UpdatePaymentStatusAsync(int paymentId, string status);
        Task<PaymentSummaryDto> GetPaymentSummaryAsync(DateTime? startDate = null, DateTime? endDate = null);

        // Simulation methods for payment gateways
        Task<PaymentSimulationResult> SimulatePaymentAsync(CreatePaymentDto dto);
        Task<bool> ValidatePaymentAsync(CreatePaymentDto dto);
    }

    public class PaymentSummaryDto
    {
        public decimal TotalRevenue { get; set; }
        public int TotalTransactions { get; set; }
        public int SuccessfulPayments { get; set; }
        public int FailedPayments { get; set; }
        public int PendingPayments { get; set; }
        public decimal AverageTransactionAmount { get; set; }
    }

    public class PaymentSimulationResult
    {
        public bool Success { get; set; }
        public string TransactionId { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string GatewayResponse { get; set; } = string.Empty;
    }
}