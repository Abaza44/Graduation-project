﻿using System.Threading.Tasks;

namespace Bookify.Core.Interfaces.Services
{
    public interface INotificationService
    {
        Task SendNewBookingNotificationAsync(string bookingId, string roomTypeName);
        Task SendBookingCancellationNotificationAsync(string bookingId);
        Task SendPaymentReceivedNotificationAsync(string bookingId, decimal amount);
    }
}