﻿using Bookify.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces.Services
{
    public interface IRoomTypeService
    {

       
        #region Room Type Methods
        Task<IEnumerable<RoomTypeDto>> GetAllRoomTypesAsync();
        Task<RoomTypeDto> GetRoomTypeByIdAsync(int id);
        Task<IEnumerable<RoomTypeDto>> GetActiveRoomTypesAsync();
        Task<IEnumerable<RoomTypeDto>> GetPopularRoomTypesAsync(int count = 5);
        Task<RoomTypeDto> CreateRoomTypeAsync(CreateRoomTypeDto dto);
        Task<RoomTypeDto> UpdateRoomTypeAsync(UpdateRoomTypeDto dto);
        Task<bool> DeleteRoomTypeAsync(int id);
        Task<bool> ToggleRoomTypeStatusAsync(int id);
        Task<RoomTypeStatistics> GetRoomTypeStatisticsAsync(int roomTypeId);
        #endregion

        #region Room Methods
        Task<IEnumerable<RoomDto>> GetAllRoomsAsync();
        Task<IEnumerable<RoomWithDetailsDto>> GetAllRoomsWithDetailsAsync();
        Task<RoomDto> GetRoomByIdAsync(int id);
        Task<bool> CreateRoomAsync(CreateRoomDto dto);
        Task<bool> UpdateRoomAsync(UpdateRoomDto dto);
        Task<bool> DeleteRoomAsync(int id);
        Task<bool> UpdateRoomStatusAsync(int id, string status);
        Task<bool> RoomNumberExistsAsync(string roomNumber, int? id = null);
        #endregion

        #region Search & Filter Methods
        Task<IEnumerable<RoomTypeDto>> SearchAvailableRoomsAsync(RoomSearchDto search);
        Task<IEnumerable<RoomTypeDto>> FilterRoomTypesAsync(RoomTypeFilterDto filter);
        #endregion

    }

    public class RoomTypeStatistics
    {
        public int TotalRooms { get; set; }
        public int AvailableRooms { get; set; }
        public int TotalBookings { get; set; }
        public int TotalReviews { get; set; }
        public double AverageRating { get; set; }
    }
}