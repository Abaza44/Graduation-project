﻿using Bookify.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces.Services
{
    public interface IDashboardService
    {
        Task<DashboardStatsDto> GetDashboardStatsAsync();
        Task<IEnumerable<RevenueReportDto>> GetRevenueReportAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<OccupancyReportDto>> GetOccupancyReportAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<PopularRoomTypeDto>> GetPopularRoomTypesAsync(int topCount = 5);
    }
}