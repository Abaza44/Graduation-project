﻿using Bookify.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces.Services
{
    public interface IBookingService
    {
        Task<BookingDto> GetBookingByIdAsync(int id);
        Task<BookingDto> GetBookingByConfirmationCodeAsync(string confirmationCode);
        Task<IEnumerable<BookingDto>> GetBookingsByUserAsync(string userId);
        Task<IEnumerable<BookingDto>> FilterBookingsAsync(BookingFilterDto filter);
        Task<BookingDto> CreateBookingAsync(CreateBookingDto dto);
        Task<bool> CancelBookingAsync(int id, string reason);
        Task<bool> ConfirmBookingAsync(int id);
        Task<bool> CheckInAsync(int id);
        Task<bool> CheckOutAsync(int id);
        Task<decimal> CalculateTotalAmountAsync(int roomTypeId, DateTime checkIn, DateTime checkOut);
        Task<bool> IsRoomAvailableAsync(int roomTypeId, DateTime checkIn, DateTime checkOut);

        // Additional methods
        Task<IEnumerable<BookingDto>> GetTodayCheckInsAsync();
        Task<IEnumerable<BookingDto>> GetTodayCheckOutsAsync();
        Task<int> GetBookingCountByStatusAsync(string status);
        Task<decimal> GetTotalRevenueAsync(DateTime? startDate = null, DateTime? endDate = null);
        Task<BookingStatistics> GetBookingStatisticsAsync();
    }

    public class BookingStatistics
    {
        public int TotalBookings { get; set; }
        public int PendingBookings { get; set; }
        public int ConfirmedBookings { get; set; }
        public int CheckedInBookings { get; set; }
        public int CompletedBookings { get; set; }
        public int CancelledBookings { get; set; }
        public decimal TotalRevenue { get; set; }
    }
}