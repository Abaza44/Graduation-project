﻿using System.Threading.Tasks;

namespace Bookify.Core.Interfaces.Services
{
    public interface IEmailService
    {
        Task SendBookingConfirmationAsync(string email, string userName, string confirmationCode, string bookingDetails);
        Task SendBookingCancellationAsync(string email, string userName, string confirmationCode);
        Task SendPaymentConfirmationAsync(string email, string userName, string transactionId, decimal amount);
        Task SendContactFormEmailAsync(string name, string email, string subject, string message);
    }
}