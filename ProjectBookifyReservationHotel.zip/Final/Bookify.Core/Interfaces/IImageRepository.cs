﻿using Bookify.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces
{
    public interface IImageRepository : IGenericRepository<Image>
    {
        Task<IEnumerable<Image>> GetImagesByRoomTypeAsync(int roomTypeId);
        Task<Image> GetPrimaryImageAsync(int roomTypeId);
        Task<bool> SetPrimaryImageAsync(int imageId);
    }
}