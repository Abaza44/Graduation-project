﻿using Bookify.Core.Entities;
using Bookify.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces
{
    public interface IBookingRepository : IGenericRepository<Booking>
    {
        // تأكد من أن هذا التوقيع صحيح
        Task<Booking> GetBookingWithDetailsAsync(int id);

        Task<IEnumerable<Booking>> GetBookingsByUserAsync(string userId);
        Task<Booking> GetBookingByConfirmationCodeAsync(string confirmationCode);
        Task<IEnumerable<Booking>> GetBookingsByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<Booking>> GetBookingsByStatusAsync(string status);
        Task<IEnumerable<Booking>> FilterBookingsAsync(BookingFilterDto filter);
        Task<IEnumerable<Booking>> GetTodayCheckInsAsync();
        Task<IEnumerable<Booking>> GetTodayCheckOutsAsync();
        Task<bool> HasOverlappingBookingAsync(int roomId, DateTime checkIn, DateTime checkOut, int? excludeBookingId = null);
        Task<int> GetTotalBookingsCountAsync(DateTime? date = null);
        Task<decimal> GetTotalRevenueAsync(DateTime? startDate = null, DateTime? endDate = null);
        Task<IEnumerable<Room>> GetAvailableRoomsForBookingAsync(int roomTypeId, DateTime checkIn, DateTime checkOut);
        Task<int> GetBookingCountByStatusAsync(string status);
    }
}