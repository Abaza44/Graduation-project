﻿using Bookify.Core.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bookify.Core.Interfaces
{
    public interface IRoomRepository : IGenericRepository<Room>
    {
        Task<IEnumerable<Room>> GetRoomsWithDetailsAsync();
        Task<Room> GetRoomWithDetailsAsync(int id);
        Task<IEnumerable<Room>> GetAvailableRoomsAsync();
        Task<IEnumerable<Room>> GetRoomsByTypeAsync(int roomTypeId);
        Task<IEnumerable<Room>> GetRoomsByStatusAsync(string status);
        Task<bool> RoomNumberExistsAsync(string roomNumber, int? id = null);
        Task UpdateRoomStatusAsync(int roomId, string status);

        // طريقة للبحث عن الغرف المتاحة حسب النوع والتاريخ
        Task<IEnumerable<Room>> FindAsync(Func<Room, bool> predicate);
    }
}