﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Bookify.Core.Entities
{
    public class Booking
    {

        public int Id { get; set; }

        [Required]
        public string UserId { get; set; }
        public ApplicationUser User { get; set; }

        [Required]
        public int RoomId { get; set; }
        public Room Room { get; set; }

        [Required]
        public int RoomTypeId { get; set; }
        public RoomType RoomType { get; set; }

        [Required]
        public DateTime CheckInDate { get; set; }

        [Required]
        public DateTime CheckOutDate { get; set; }

        public DateTime? ActualCheckInDate { get; set; } // Added
        public DateTime? ActualCheckOutDate { get; set; } // Added

        [Required]
        [Range(1, 10)]
        public int NumberOfGuests { get; set; }

        [Required]
        [Range(0.01, 100000)]
        public decimal TotalAmount { get; set; }

        [Required]
        [MaxLength(20)]
        public string BookingStatus { get; set; } // Pending, Confirmed, CheckedIn, Completed, Cancelled

        [Required]
        [MaxLength(50)]
        public string ConfirmationCode { get; set; }

        public DateTime BookingDate { get; set; }
        public DateTime? CancellationDate { get; set; }

        [MaxLength(500)]
        public string CancellationReason { get; set; }

        [MaxLength(1000)]
        public string SpecialRequests { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;

        // Navigation property for payments
        public ICollection<Payment> Payments { get; set; } = new List<Payment>();
    }
}