﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Bookify.Core.Entities
{
    public class Amenity
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        [MaxLength(500)]
        public string Description { get; set; }

        [MaxLength(50)]
        public string IconClass { get; set; } // For Font Awesome or Bootstrap Icons

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        // Navigation Properties
        public virtual ICollection<RoomTypeAmenity> RoomTypeAmenities { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}