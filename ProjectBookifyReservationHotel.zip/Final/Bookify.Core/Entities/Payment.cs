﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Bookify.Core.Entities
{
    public class Payment
    {
        public int Id { get; set; }

        [Required]
        public int BookingId { get; set; }
        public Booking Booking { get; set; }

        [Required]
        [MaxLength(50)]
        public string PaymentMethod { get; set; } // CreditCard, PayPal, Cash, etc.

        [Required]
        [MaxLength(100)]
        public string TransactionId { get; set; }

        [Required]
        public decimal Amount { get; set; }

        [Required]
        [MaxLength(20)]
        public string Currency { get; set; } = "USD";

        [Required]
        [MaxLength(20)]
        public string PaymentStatus { get; set; } // Pending, Completed, Failed, Refunded

        [MaxLength(500)]
        public string Description { get; set; }

        public DateTime PaymentDate { get; set; }
        public DateTime? ProcessedDate { get; set; }
        public DateTime? RefundDate { get; set; }

        [MaxLength(1000)]
        public string PaymentResponse { get; set; } // Raw response from payment gateway

        // Credit Card Information (encrypted in real implementation)
        [MaxLength(4)]
        public string LastFourDigits { get; set; }

        [MaxLength(50)]
        public string CardType { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;
    }
}