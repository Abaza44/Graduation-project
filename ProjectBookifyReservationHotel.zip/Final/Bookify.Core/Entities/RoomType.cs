﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Bookify.Core.Entities
{
    public class RoomType
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        [Required]
        [MaxLength(1000)]
        public string Description { get; set; }

        [Required]
        [Range(0, double.MaxValue)]
        public decimal PricePerNight { get; set; }

        [Required]
        [Range(1, 10)]
        public int Capacity { get; set; }

        [Range(0, 1000)]
        public decimal SizeInSqFt { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;
        [MaxLength(500)]
        public string? ImageUrl { get; set; }

        // Navigation Properties
        public virtual ICollection<Room> Rooms { get; set; }
        public virtual ICollection<Image> Images { get; set; }
        public virtual ICollection<Review> Reviews { get; set; }
        public virtual ICollection<RoomTypeAmenity> RoomTypeAmenities { get; set; }
        public virtual ICollection<Booking> Bookings { get; set; }
    }
}