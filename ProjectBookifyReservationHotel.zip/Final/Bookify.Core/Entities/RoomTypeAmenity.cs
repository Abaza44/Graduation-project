﻿
namespace Bookify.Core.Entities
{
    public class RoomTypeAmenity
    {
        public int RoomTypeId { get; set; }
        public int AmenityId { get; set; }

        // Navigation Properties
        public virtual RoomType RoomType { get; set; }
        public virtual Amenity Amenity { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}