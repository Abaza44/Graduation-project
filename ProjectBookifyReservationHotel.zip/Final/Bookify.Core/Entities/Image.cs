﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Bookify.Core.Entities
{
    public class Image
    {
        public int Id { get; set; }

        [Required]
        public int RoomTypeId { get; set; }

        [Required]
        [MaxLength(500)]
        public string ImageUrl { get; set; }    

        [MaxLength(200)]
        public string AltText { get; set; }

        public bool IsPrimary { get; set; } = false;

        public DateTime UploadDate { get; set; } = DateTime.UtcNow;

        // Navigation Properties
        public virtual RoomType RoomType { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.Now;

    }
}