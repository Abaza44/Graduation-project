﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Bookify.Core.Entities
{
    public class Room
    {
        public int Id { get; set; }

        [Required]
        public int RoomTypeId { get; set; }

        [Required]
        [MaxLength(20)]
        public string RoomNumber { get; set; }

        [MaxLength(10)]
        public string Floor { get; set; }

        [MaxLength(50)]
        public string View { get; set; } // Sea View, City View, Garden View

        [Required]
        [MaxLength(20)]
        public string Status { get; set; } = "Available"; // Available, Occupied, Maintenance, Cleaning

        [MaxLength(500)]
        public string AdditionalNotes { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;
        public DateTime? LastMaintenanceDate { get; set; }

        // Navigation Properties
        public virtual RoomType RoomType { get; set; }
        public virtual ICollection<Booking> Bookings { get; set; }
    }
}