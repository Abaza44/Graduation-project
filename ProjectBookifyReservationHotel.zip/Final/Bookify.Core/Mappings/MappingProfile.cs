﻿using AutoMapper;
using Bookify.Core.DTOs;
using Bookify.Core.Entities;

namespace Bookify.Infrastructure.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // Amenity mappings
            CreateMap<Amenity, AmenityDto>();
            CreateMap<CreateAmenityDto, Amenity>();
            CreateMap<UpdateAmenityDto, Amenity>();

            // RoomType mappings
            CreateMap<RoomType, RoomTypeDto>()
               .ForMember(dest => dest.ImageUrls, opt => opt.MapFrom(src =>
        src.Images.Select(i => i.ImageUrl)))
    .ForMember(dest => dest.Amenities, opt => opt.MapFrom(src =>
        src.RoomTypeAmenities.Select(rta => rta.Amenity.Name)))
    .ForMember(dest => dest.PricePerNight, opt => opt.MapFrom(src => src.PricePerNight)) // ✅ هنا
    .ForMember(dest => dest.AverageRating, opt => opt.Ignore())
    .ForMember(dest => dest.TotalReviews, opt => opt.Ignore())
    .ForMember(dest => dest.AvailableRooms, opt => opt.Ignore())
    .ForMember(dest => dest.TotalRooms, opt => opt.Ignore())
    .ForMember(dest => dest.TotalBookings, opt => opt.Ignore())
    .ForMember(dest => dest.AmenityIds, opt => opt.Ignore());

            CreateMap<CreateRoomTypeDto, RoomType>();
            CreateMap<UpdateRoomTypeDto, RoomType>();

            // Room mappings
            CreateMap<Room, RoomDto>()
                .ForMember(dest => dest.RoomTypeName, opt => opt.MapFrom(src =>
                    src.RoomType.Name));

            CreateMap<Room, RoomWithDetailsDto>()
                .ForMember(dest => dest.RoomTypeName, opt => opt.MapFrom(src =>
                    src.RoomType.Name));

            CreateMap<CreateRoomDto, Room>();
            CreateMap<UpdateRoomDto, Room>();

            // Booking mappings
            CreateMap<Booking, BookingDto>()
                .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => src.User.UserName))
                .ForMember(dest => dest.UserEmail, opt => opt.MapFrom(src => src.User.Email))

                .ForMember(dest => dest.RoomNumber, opt => opt.MapFrom(src => src.Room.RoomNumber))
                .ForMember(dest => dest.RoomTypeName, opt => opt.MapFrom(src => src.RoomType.Name))
                .ForMember(dest => dest.TotalNights, opt => opt.MapFrom(src =>
                    (src.CheckOutDate - src.CheckInDate).Days));

            CreateMap<CreateBookingDto, Booking>();
            CreateMap<UpdateBookingDto, Booking>();

            // Payment mappings
            CreateMap<Payment, PaymentDto>()
                .ForMember(dest => dest.BookingConfirmationCode, opt => opt.MapFrom(src =>
                    src.Booking.ConfirmationCode));

            CreateMap<CreatePaymentDto, Payment>();

            // Review mappings
            CreateMap<Review, ReviewDto>()
                .ForMember(dest => dest.RoomTypeName, opt => opt.MapFrom(src => src.RoomType.Name))
                .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => src.User.UserName));

            CreateMap<CreateReviewDto, Review>();
            CreateMap<UpdateReviewDto, Review>();
        }
    }
}