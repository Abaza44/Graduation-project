﻿namespace Bookify.Core
{
    public class Class1
    {

    }
}
