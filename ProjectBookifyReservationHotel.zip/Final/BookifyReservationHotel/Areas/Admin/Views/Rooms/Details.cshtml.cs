using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Areas.Admin.Views.Rooms
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
