using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Areas.Admin.Views.Reviews
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
