﻿// Areas/Admin/Controllers/ReviewsController.cs
using Bookify.Core.DTOs;
using Bookify.Core.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookifyReservationHotel.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class ReviewsController : Controller
    {
        private readonly IReviewService _reviewService;
        private readonly IRoomTypeService _roomTypeService;
        private readonly ILogger<ReviewsController> _logger;

        public ReviewsController(
            IReviewService reviewService,
            IRoomTypeService roomTypeService,
            ILogger<ReviewsController> logger)
        {
            _reviewService = reviewService;
            _roomTypeService = roomTypeService;
            _logger = logger;
        }

        public async Task<IActionResult> Index(string? search, string? status, int? roomTypeId)
        {
            try
            {
                var reviews = await _reviewService.GetAllReviewsAsync();

                // Apply filters
                if (!string.IsNullOrEmpty(search))
                {
                    reviews = reviews.Where(r =>
                        r.UserName.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                        r.Comment.Contains(search, StringComparison.OrdinalIgnoreCase)
                    ).ToList();
                }

                if (!string.IsNullOrEmpty(status))
                {
                    reviews = reviews.Where(r => r.Status == status).ToList();
                }

                if (roomTypeId.HasValue)
                {
                    reviews = reviews.Where(r => r.RoomTypeId == roomTypeId.Value).ToList();
                }

                ViewBag.SearchTerm = search;
                ViewBag.SelectedStatus = status;
                ViewBag.SelectedRoomTypeId = roomTypeId;
                ViewBag.RoomTypes = await _roomTypeService.GetAllRoomTypesAsync();

                return View(reviews);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving reviews");
                TempData["Error"] = "An error occurred while retrieving reviews.";
                return View(new List<ReviewDto>());
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Approve(int id)
        {
            try
            {
                var result = await _reviewService.UpdateReviewStatusAsync(id, "Approved");
                if (result)
                {
                    TempData["Success"] = "Review approved successfully!";
                }
                else
                {
                    TempData["Error"] = "Review not found or cannot be approved.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error approving review {id}");
                TempData["Error"] = "An error occurred while approving the review.";
            }

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Reject(int id)
        {
            try
            {
                var result = await _reviewService.UpdateReviewStatusAsync(id, "Rejected");
                if (result)
                {
                    TempData["Success"] = "Review rejected successfully!";
                }
                else
                {
                    TempData["Error"] = "Review not found or cannot be rejected.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error rejecting review {id}");
                TempData["Error"] = "An error occurred while rejecting the review.";
            }

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var result = await _reviewService.DeleteReviewAsync(id);
                if (result)
                {
                    TempData["Success"] = "Review deleted successfully!";
                }
                else
                {
                    TempData["Error"] = "Review not found or cannot be deleted.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting review {id}");
                TempData["Error"] = "An error occurred while deleting the review.";
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var review = await _reviewService.GetReviewByIdAsync(id);
                if (review == null)
                {
                    return NotFound();
                }

                return View(review);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving review details for ID: {id}");
                TempData["Error"] = "An error occurred while retrieving review details.";
                return RedirectToAction(nameof(Index));
            }
        }
    }
}