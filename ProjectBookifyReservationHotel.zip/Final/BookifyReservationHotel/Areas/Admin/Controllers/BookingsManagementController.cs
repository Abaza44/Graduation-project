﻿// Areas/Admin/Controllers/BookingsManagementController.cs
using Bookify.Core.DTOs;
using Bookify.Core.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookifyReservationHotel.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin,Manager")]
    public class BookingsManagementController : Controller
    {
        private readonly IBookingService _bookingService;
        private readonly ILogger<BookingsManagementController> _logger;

        public BookingsManagementController(
            IBookingService bookingService,
            ILogger<BookingsManagementController> logger)
        {
            _bookingService = bookingService;
            _logger = logger;
        }

        public async Task<IActionResult> Index(string? confirmationCode, string? status, DateTime? fromDate, DateTime? toDate)
        {
            try
            {
                var filter = new BookingFilterDto
                {
                    ConfirmationCode = confirmationCode ?? string.Empty,
                    BookingStatus = status ?? string.Empty,
                    CheckInDateFrom = fromDate,
                    CheckInDateTo = toDate
                };

                var bookings = await _bookingService.FilterBookingsAsync(filter);
                return View(bookings);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving bookings");
                TempData["Error"] = "An error occurred while retrieving bookings.";

                // بيانات تجريبية في حالة الخطأ
                var demoBookings = GetDemoBookings();
                return View(demoBookings);
            }
        }

        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var booking = await _bookingService.GetBookingByIdAsync(id);
                if (booking == null)
                {
                    TempData["Error"] = "Booking not found.";
                    return RedirectToAction(nameof(Index));
                }
                return View(booking);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving booking {id}");
                TempData["Error"] = "An error occurred while retrieving booking details.";
                return RedirectToAction(nameof(Index));
            }
        }

        // إصلاح جميع الـ Actions لتُرجع إلى Index بدلاً من Details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Confirm(int id)
        {
            try
            {
                var result = await _bookingService.ConfirmBookingAsync(id);
                if (result)
                {
                    TempData["Success"] = "Booking confirmed successfully!";
                }
                else
                {
                    TempData["Error"] = "Booking not found or cannot be confirmed.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error confirming booking {id}");
                TempData["Error"] = "An error occurred while confirming the booking.";
            }

            return RedirectToAction(nameof(Index)); // إصلاح: الرجوع إلى Index
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CheckIn(int id)
        {
            try
            {
                var result = await _bookingService.CheckInAsync(id);
                if (result)
                {
                    TempData["Success"] = "Guest checked in successfully!";
                }
                else
                {
                    TempData["Error"] = "Booking not found or cannot be checked in.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error checking in booking {id}");
                TempData["Error"] = "An error occurred while checking in the guest.";
            }

            return RedirectToAction(nameof(Index)); // إصلاح: الرجوع إلى Index
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CheckOut(int id)
        {
            try
            {
                var result = await _bookingService.CheckOutAsync(id);
                if (result)
                {
                    TempData["Success"] = "Guest checked out successfully!";
                }
                else
                {
                    TempData["Error"] = "Booking not found or cannot be checked out.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error checking out booking {id}");
                TempData["Error"] = "An error occurred while checking out the guest.";
            }

            return RedirectToAction(nameof(Index)); // إصلاح: الرجوع إلى Index
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
       
        public async Task<IActionResult> Cancel(int id, string reason)
        {
            try
            {
                Console.WriteLine($"=== CANCEL BOOKING CALLED ===");
                Console.WriteLine($"Booking ID: {id}");
                Console.WriteLine($"Reason: {reason}");

                // Input validation
                if (id <= 0)
                {
                    TempData["Error"] = "Invalid booking ID.";
                    return RedirectToAction(nameof(Index));
                }

                if (string.IsNullOrWhiteSpace(reason))
                {
                    TempData["Error"] = "Cancellation reason is required.";
                    return RedirectToAction(nameof(Index));
                }

                var result = await _bookingService.CancelBookingAsync(id, reason);

                if (result)
                {
                    TempData["Success"] = "Booking cancelled successfully!";
                    _logger.LogInformation($"Booking {id} cancelled successfully. Reason: {reason}");
                }
                else
                {
                    TempData["Error"] = "Booking not found or cannot be cancelled.";
                    _logger.LogWarning($"Failed to cancel booking {id}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error cancelling booking {id}");
                TempData["Error"] = $"An error occurred while cancelling the booking: {ex.Message}";
            }

            // إصلاح: الرجوع إلى Index بدلاً من Details
            return RedirectToAction(nameof(Index));
        }

        // بيانات تجريبية
        private List<BookingDto> GetDemoBookings()
        {
            return new List<BookingDto>
            {
                new BookingDto
                {
                    Id = 1,
                    UserId = "user1",
                    UserName = "John Doe",
                    UserEmail = "john@example.com",
                    RoomId = 101,
                    RoomNumber = "101",
                    RoomTypeId = 1,
                    RoomTypeName = "Standard Room",
                    CheckInDate = DateTime.Now.AddDays(-2),
                    CheckOutDate = DateTime.Now.AddDays(2),
                    NumberOfGuests = 2,
                    TotalAmount = 450,
                    BookingStatus = "Confirmed",
                    ConfirmationCode = "BK001",
                    BookingDate = DateTime.Now.AddDays(-5),
                    SpecialRequests = "Early check-in requested",
                    TotalNights = 4,
                    CreatedDate = DateTime.Now.AddDays(-5),
                    UpdatedDate = DateTime.Now.AddDays(-2)
                },
                new BookingDto
                {
                    Id = 2,
                    UserId = "user2",
                    UserName = "Jane Smith",
                    UserEmail = "jane@example.com",
                    RoomId = 205,
                    RoomNumber = "205",
                    RoomTypeId = 2,
                    RoomTypeName = "Deluxe Room",
                    CheckInDate = DateTime.Now.AddDays(-1),
                    CheckOutDate = DateTime.Now.AddDays(3),
                    NumberOfGuests = 3,
                    TotalAmount = 600,
                    BookingStatus = "Pending",
                    ConfirmationCode = "BK002",
                    BookingDate = DateTime.Now.AddDays(-3),
                    SpecialRequests = "Need extra bed",
                    TotalNights = 4,
                    CreatedDate = DateTime.Now.AddDays(-3),
                    UpdatedDate = DateTime.Now.AddDays(-1)
                },
                new BookingDto
                {
                    Id = 3,
                    UserId = "user3",
                    UserName = "Bob Johnson",
                    UserEmail = "bob@example.com",
                    RoomId = 301,
                    RoomNumber = "301",
                    RoomTypeId = 3,
                    RoomTypeName = "Executive Suite",
                    CheckInDate = DateTime.Now,
                    CheckOutDate = DateTime.Now.AddDays(4),
                    NumberOfGuests = 2,
                    TotalAmount = 900,
                    BookingStatus = "Confirmed",
                    ConfirmationCode = "BK003",
                    BookingDate = DateTime.Now.AddDays(-2),
                    SpecialRequests = "Anniversary celebration",
                    TotalNights = 4,
                    CreatedDate = DateTime.Now.AddDays(-2),
                    UpdatedDate = DateTime.Now
                }
            };
        }
    }
}