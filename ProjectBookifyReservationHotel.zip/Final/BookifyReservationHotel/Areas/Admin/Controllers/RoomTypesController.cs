﻿using Bookify.Core.DTOs;
using Bookify.Core.Interfaces.Services;
using BookifyReservationHotel.Models.ViewModels.Admin;
using BookifyReservationHotel.Models.ViewModels.Shared;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BookifyReservationHotel.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class RoomTypesController : Controller
    {
        private readonly IRoomTypeService _roomTypeService;
        private readonly IAmenityService _amenityService;
        private readonly ILogger<RoomTypesController> _logger;

        public RoomTypesController(
            IRoomTypeService roomTypeService,
            IAmenityService amenityService,
            ILogger<RoomTypesController> logger)
        {
            _roomTypeService = roomTypeService;
            _amenityService = amenityService;
            _logger = logger;
        }

        // GET: Admin/RoomTypes
        // GET: Admin/RoomTypes
        public async Task<IActionResult> Index()
        {
            try
            {
                var roomTypes = await _roomTypeService.GetAllRoomTypesAsync();

                // إرجاع RoomTypeDto مباشرة بدون تحويل
                return View(roomTypes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving room types list");
                TempData["Error"] = "An error occurred while retrieving room types.";
                return View(new List<Bookify.Core.DTOs.RoomTypeDto>());
            }
        }

        // GET: Admin/RoomTypes/Details/5
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var roomType = await _roomTypeService.GetRoomTypeByIdAsync(id);
                if (roomType == null)
                {
                    return NotFound();
                }

                var amenities = roomType.Amenities?.Select(a => new AdminAmenityViewModel
                {
                    Name = a,
                    IconClass = GetAmenityIcon(a)
                }).ToList() ?? new List<AdminAmenityViewModel>();

                var viewModel = new RoomTypeDetailViewModel
                {
                    Id = roomType.Id,
                    Name = roomType.Name,
                    Description = roomType.Description,
                    PricePerNight = roomType.PricePerNight,
                    Capacity = roomType.Capacity,
                    SizeInSqFt = roomType.SizeInSqFt,
                    IsActive = roomType.IsActive,
                    ImageUrls = roomType.ImageUrls ?? new List<string>(),
                    Amenities = amenities,
                    TotalRooms = roomType.TotalRooms,
                    AvailableRooms = roomType.AvailableRooms,
                    AverageRating = roomType.AverageRating,
                    TotalReviews = roomType.TotalReviews,
                    TotalBookings = roomType.TotalBookings,
                    TotalRevenue = roomType.TotalBookings * roomType.PricePerNight,
                    CreatedDate = roomType.CreatedDate,
                    UpdatedDate = roomType.UpdatedDate
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving room type details for ID: {id}");
                TempData["Error"] = "An error occurred while retrieving room type details.";
                return RedirectToAction(nameof(Index));
            }
        }

        // GET: Admin/RoomTypes/Create
        public async Task<IActionResult> Create()
        {
            var model = new RoomTypeFormViewModel
            {
                IsActive = true,
                AvailableAmenities = await GetAmenitiesSelectList(),
                ExistingImages = new List<AdminImageViewModel>(),
                ImageUrls = new List<string>()
            };

            return View(model);
        }

        // POST: Admin/RoomTypes/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(RoomTypeFormViewModel model)
        {
            if (!ModelState.IsValid)
            {
                model.AvailableAmenities = await GetAmenitiesSelectList();
                return View(model);
            }

            try
            {
                var createDto = new CreateRoomTypeDto
                {
                    Name = model.Name,
                    Description = model.Description,
                    PricePerNight = model.PricePerNight,
                    Capacity = model.Capacity,
                    SizeInSqFt = model.SizeInSqFt,
                    AmenityIds = model.SelectedAmenityIds
                };

                var result = await _roomTypeService.CreateRoomTypeAsync(createDto);

                if (result != null)
                {
                    TempData["Success"] = "Room type created successfully!";
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    ModelState.AddModelError("", "Failed to create room type. Please try again.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating room type");
                ModelState.AddModelError("", "An error occurred while creating the room type. Please try again.");
            }

            model.AvailableAmenities = await GetAmenitiesSelectList();
            return View(model);
        }

        // GET: Admin/RoomTypes/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            try
            {
                var roomType = await _roomTypeService.GetRoomTypeByIdAsync(id);
                if (roomType == null)
                {
                    return NotFound();
                }

                var existingImages = roomType.ImageUrls?.Select(url => new AdminImageViewModel
                {
                    ImageUrl = url,
                    AltText = roomType.Name,
                    IsPrimary = url == roomType.ImageUrls?.FirstOrDefault()
                }).ToList() ?? new List<AdminImageViewModel>();

                var model = new RoomTypeFormViewModel
                {
                    Id = roomType.Id,
                    Name = roomType.Name,
                    Description = roomType.Description,
                    PricePerNight = roomType.PricePerNight,
                    Capacity = roomType.Capacity,
                    SizeInSqFt = roomType.SizeInSqFt,
                    IsActive = roomType.IsActive,
                    ExistingImages = existingImages,
                    ImageUrls = roomType.ImageUrls ?? new List<string>(),
                    SelectedAmenityIds = roomType.AmenityIds ?? new List<int>(),
                    AvailableAmenities = await GetAmenitiesSelectList(),
                    TotalRooms = roomType.TotalRooms,
                    AvailableRooms = roomType.AvailableRooms,
                    AverageRating = roomType.AverageRating,
                    TotalBookings = roomType.TotalBookings,
                    CreatedDate = roomType.CreatedDate,
                    UpdatedDate = roomType.UpdatedDate
                };

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving room type for edit with ID: {id}");
                TempData["Error"] = "An error occurred while retrieving the room type for editing.";
                return RedirectToAction(nameof(Index));
            }
        }

        // POST: Admin/RoomTypes/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, RoomTypeFormViewModel model)
        {
            if (id != model.Id)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                model.AvailableAmenities = await GetAmenitiesSelectList();
                return View(model);
            }

            try
            {
                var updateDto = new UpdateRoomTypeDto
                {
                    Id = model.Id,
                    Name = model.Name,
                    Description = model.Description,
                    PricePerNight = model.PricePerNight,
                    Capacity = model.Capacity,
                    SizeInSqFt = model.SizeInSqFt,
                    IsActive = model.IsActive,
                    AmenityIds = model.SelectedAmenityIds
                };

                var result = await _roomTypeService.UpdateRoomTypeAsync(updateDto);

                if (result != null)
                {
                    TempData["Success"] = "Room type updated successfully!";
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    ModelState.AddModelError("", "Failed to update room type. Please try again.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating room type with ID: {id}");
                ModelState.AddModelError("", "An error occurred while updating the room type. Please try again.");
            }

            model.AvailableAmenities = await GetAmenitiesSelectList();
            return View(model);
        }

        // POST: Admin/RoomTypes/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var result = await _roomTypeService.DeleteRoomTypeAsync(id);

                if (result)
                {
                    TempData["Success"] = "Room type deleted successfully!";
                }
                else
                {
                    TempData["Error"] = "Room type not found or cannot be deleted.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting room type with ID: {id}");
                TempData["Error"] = "An error occurred while deleting the room type.";
            }

            return RedirectToAction(nameof(Index));
        }

        // POST: Admin/RoomTypes/ToggleStatus/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ToggleStatus(int id)
        {
            try
            {
                var result = await _roomTypeService.ToggleRoomTypeStatusAsync(id);

                if (result)
                {
                    TempData["Success"] = "Room type status updated successfully!";
                }
                else
                {
                    TempData["Error"] = "Room type not found or status cannot be updated.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error toggling room type status for ID: {id}");
                TempData["Error"] = "An error occurred while updating the room type status.";
            }

            return RedirectToAction(nameof(Index));
        }

        // Helper Methods
        private async Task<List<SelectListItem>> GetAmenitiesSelectList()
        {
            try
            {
                var amenities = await _amenityService.GetAllAmenitiesAsync();
                return amenities.Select(a => new SelectListItem
                {
                    Value = a.Id.ToString(),
                    Text = a.Name
                }).ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving amenities for select list");
                return new List<SelectListItem>();
            }
        }

        private string GetAmenityIcon(string amenityName)
        {
            return amenityName.ToLower() switch
            {
                "wifi" or "free wifi" => "fas fa-wifi",
                "tv" => "fas fa-tv",
                "air conditioning" => "fas fa-snowflake",
                "mini bar" => "fas fa-glass-whiskey",
                "safe" => "fas fa-lock",
                "hair dryer" => "fas fa-wind",
                "coffee maker" => "fas fa-coffee",
                "breakfast" => "fas fa-utensils",
                "pool" or "swimming pool" => "fas fa-swimming-pool",
                "gym" or "gym access" => "fas fa-dumbbell",
                "spa" => "fas fa-spa",
                "work desk" => "fas fa-desktop",
                "sitting area" => "fas fa-couch",
                "executive lounge access" => "fas fa-star",
                _ => "fas fa-check"
            };
        }
    }
}