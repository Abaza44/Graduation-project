﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Bookify.Core.Interfaces.Services;
using Bookify.Core.DTOs;
using System.Threading.Tasks;

namespace BookifyReservationHotel.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin,Manager")]
    public class DashboardController : Controller
    {
        private readonly IDashboardService _dashboardService;

        public DashboardController(IDashboardService dashboardService)
        {
            _dashboardService = dashboardService;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var dashboardData = await _dashboardService.GetDashboardStatsAsync();
                return View(dashboardData);
            }
            catch (System.Exception ex)
            {
                TempData["Error"] = $"Failed to load dashboard: {ex.Message}";

                return View(new DashboardStatsDto
                {
                    TotalBookingsToday = 0,
                    TotalBookingsThisMonth = 0,
                    RevenueToday = 0,
                    RevenueThisMonth = 0,
                    OccupancyRate = 0,
                    TotalRooms = 0,
                    AvailableRooms = 0,
                    CheckInsToday = 0,
                    CheckOutsToday = 0,
                    PendingBookings = 0
                });
            }
        }

        [HttpGet]
        public async Task<IActionResult> RevenueReport()
        {
            var startDate = System.DateTime.Today.AddDays(-30);
            var endDate = System.DateTime.Today;

            var revenueData = await _dashboardService.GetRevenueReportAsync(startDate, endDate);
            return View(revenueData);
        }

        [HttpGet]
        public async Task<IActionResult> OccupancyReport()
        {
            var startDate = System.DateTime.Today.AddDays(-30);
            var endDate = System.DateTime.Today;

            var occupancyData = await _dashboardService.GetOccupancyReportAsync(startDate, endDate);
            return View(occupancyData);
        }

        [HttpGet]
        public async Task<IActionResult> PopularRoomTypes()
        {
            var popularRooms = await _dashboardService.GetPopularRoomTypesAsync(5);
            return View(popularRooms);
        }
    }
}