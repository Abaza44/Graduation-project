﻿using Bookify.Core.DTOs;
using Bookify.Core.Interfaces.Services;
using BookifyReservationHotel.Models.ViewModels.Admin;
using BookifyReservationHotel.Models.ViewModels.Shared;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace BookifyReservationHotel.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class RoomsController : Controller
    {
        private readonly IRoomTypeService _roomTypeService;
        private readonly IBookingService _bookingService;
        private readonly ILogger<RoomsController> _logger;

        public RoomsController(
            IRoomTypeService roomTypeService,
            IBookingService bookingService,
            ILogger<RoomsController> logger)
        {
            _roomTypeService = roomTypeService;
            _bookingService = bookingService;
            _logger = logger;
        }

        // GET: Admin/Rooms
        public async Task<IActionResult> Index()
        {
            try
            {
                var rooms = await _roomTypeService.GetAllRoomsWithDetailsAsync();
                var viewModel = rooms.Select(room => new RoomManagementViewModel
                {
                    Id = room.Id,
                    RoomNumber = room.RoomNumber,
                    RoomTypeId = room.RoomTypeId,
                    RoomTypeName = room.RoomTypeName,
                    Floor = room.Floor,
                    View = room.View,
                    Status = room.Status,
                    AdditionalNotes = room.AdditionalNotes,
                    LastMaintenanceDate = room.LastMaintenanceDate,
                    CreatedDate = room.CreatedDate,
                    UpdatedDate = room.UpdatedDate,
                    TotalBookings = room.TotalBookings,
                    ActiveBookings = room.ActiveBookings
                }).ToList();

                return View(viewModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving rooms list");
                TempData["Error"] = "An error occurred while retrieving rooms.";
                return View(new List<RoomManagementViewModel>());
            }
        }

        // GET: Admin/Rooms/Details/5
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var room = await _roomTypeService.GetRoomByIdAsync(id);
                if (room == null)
                {
                    return NotFound();
                }

                var viewModel = new RoomManagementViewModel
                {
                    Id = room.Id,
                    RoomNumber = room.RoomNumber,
                    RoomTypeId = room.RoomTypeId,
                    RoomTypeName = room.RoomTypeName,
                    Floor = room.Floor,
                    View = room.View,
                    Status = room.Status,
                    AdditionalNotes = room.AdditionalNotes,
                    LastMaintenanceDate = room.LastMaintenanceDate,
                    CreatedDate = room.CreatedDate,
                    UpdatedDate = room.UpdatedDate,
                    TotalBookings = room.TotalBookings,
                    ActiveBookings = room.ActiveBookings
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving room details for ID: {id}");
                TempData["Error"] = "An error occurred while retrieving room details.";
                return RedirectToAction(nameof(Index));
            }
        }

        // GET: Admin/Rooms/Create
        public async Task<IActionResult> Create()
        {
            try
            {
                var roomTypes = await _roomTypeService.GetAllRoomTypesAsync();

                var model = new RoomFormViewModel
                {
                    RoomTypes = roomTypes.Select(rt => new RoomTypeDropdownViewModel
                    {
                        Id = rt.Id,
                        Name = rt.Name,
                        Description = rt.Description,
                        Price = rt.PricePerNight,
                        Capacity = rt.Capacity,
                        IconClass = "fas fa-bed"
                    }).ToList(),

                    StatusOptions = new List<string>
                    {
                        "Available",
                        "Occupied",
                        "Maintenance",
                        "Cleaning"
                    },

                    ViewOptions = new List<string>
                    {
                        "City View",
                        "Sea View",
                        "Ocean View",
                        "Garden View",
                        "Pool View"
                    }
                };

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error preparing room creation form");
                TempData["Error"] = "An error occurred while preparing the room creation form.";
                return RedirectToAction(nameof(Index));
            }
        }

        // POST: Admin/Rooms/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(RoomFormViewModel model)
        {
            if (!ModelState.IsValid)
            {
                try
                {
                    // Repopulate dropdowns if model is invalid
                    var roomTypes = await _roomTypeService.GetAllRoomTypesAsync();
                    model.RoomTypes = roomTypes.Select(rt => new RoomTypeDropdownViewModel
                    {
                        Id = rt.Id,
                        Name = rt.Name,
                        Description = rt.Description,
                        Price = rt.PricePerNight,
                        Capacity = rt.Capacity,
                        IconClass = "fas fa-bed"
                    }).ToList();

                    model.StatusOptions = new List<string> { "Available", "Occupied", "Maintenance", "Cleaning" };
                    model.ViewOptions = new List<string> { "City View", "Sea View", "Ocean View", "Garden View", "Pool View" };
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error repopulating room form dropdowns");
                }

                return View(model);
            }

            try
            {
                var createDto = new CreateRoomDto
                {
                    RoomTypeId = model.RoomTypeId,
                    RoomNumber = model.RoomNumber,
                    Floor = model.Floor,
                    View = model.View,
                    Status = model.Status,
                    AdditionalNotes = model.AdditionalNotes,
                    LastMaintenanceDate = model.LastMaintenanceDate
                };

                var result = await _roomTypeService.CreateRoomAsync(createDto);

                if (result)
                {
                    TempData["Success"] = "Room created successfully!";
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    ModelState.AddModelError("", "Failed to create room. Please try again.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating room");
                ModelState.AddModelError("", "An error occurred while creating the room. Please try again.");
            }

            // Repopulate dropdowns on error
            try
            {
                var roomTypes = await _roomTypeService.GetAllRoomTypesAsync();
                model.RoomTypes = roomTypes.Select(rt => new RoomTypeDropdownViewModel
                {
                    Id = rt.Id,
                    Name = rt.Name,
                    Description = rt.Description,
                    Price = rt.PricePerNight,
                    Capacity = rt.Capacity,
                    IconClass = "fas fa-bed"
                }).ToList();

                model.StatusOptions = new List<string> { "Available", "Occupied", "Maintenance", "Cleaning" };
                model.ViewOptions = new List<string> { "City View", "Sea View", "Ocean View", "Garden View", "Pool View" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error repopulating room form dropdowns after creation failure");
            }

            return View(model);
        }

        // GET: Admin/Rooms/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            try
            {
                var room = await _roomTypeService.GetRoomByIdAsync(id);
                if (room == null)
                {
                    return NotFound();
                }

                var roomTypes = await _roomTypeService.GetAllRoomTypesAsync();

                var model = new RoomFormViewModel
                {
                    Id = room.Id,
                    RoomTypeId = room.RoomTypeId,
                    RoomNumber = room.RoomNumber,
                    Floor = room.Floor,
                    View = room.View,
                    Status = room.Status,
                    AdditionalNotes = room.AdditionalNotes,
                    LastMaintenanceDate = room.LastMaintenanceDate,

                    RoomTypes = roomTypes.Select(rt => new RoomTypeDropdownViewModel
                    {
                        Id = rt.Id,
                        Name = rt.Name,
                        Description = rt.Description,
                        Price = rt.PricePerNight,
                        Capacity = rt.Capacity,
                        IconClass = "fas fa-bed"
                    }).ToList(),

                    StatusOptions = new List<string>
                    {
                        "Available",
                        "Occupied",
                        "Maintenance",
                        "Cleaning"
                    },

                    ViewOptions = new List<string>
                    {
                        "City View",
                        "Sea View",
                        "Ocean View",
                        "Garden View",
                        "Pool View"
                    }
                };

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving room for edit with ID: {id}");
                TempData["Error"] = "An error occurred while retrieving the room for editing.";
                return RedirectToAction(nameof(Index));
            }
        }

        // POST: Admin/Rooms/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, RoomFormViewModel model)
        {
            if (id != model.Id)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                try
                {
                    // Repopulate dropdowns if model is invalid
                    var roomTypes = await _roomTypeService.GetAllRoomTypesAsync();
                    model.RoomTypes = roomTypes.Select(rt => new RoomTypeDropdownViewModel
                    {
                        Id = rt.Id,
                        Name = rt.Name,
                        Description = rt.Description,
                        Price = rt.PricePerNight,
                        Capacity = rt.Capacity,
                        IconClass = "fas fa-bed"
                    }).ToList();

                    model.StatusOptions = new List<string> { "Available", "Occupied", "Maintenance", "Cleaning" };
                    model.ViewOptions = new List<string> { "City View", "Sea View", "Ocean View", "Garden View", "Pool View" };
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error repopulating room form dropdowns during edit");
                }

                return View(model);
            }

            try
            {
                var updateDto = new UpdateRoomDto
                {
                    Id = model.Id,
                    RoomTypeId = model.RoomTypeId,
                    RoomNumber = model.RoomNumber,
                    Floor = model.Floor,
                    View = model.View,
                    Status = model.Status,
                    AdditionalNotes = model.AdditionalNotes,
                    LastMaintenanceDate = model.LastMaintenanceDate
                };

                var result = await _roomTypeService.UpdateRoomAsync(updateDto);

                if (result)
                {
                    TempData["Success"] = "Room updated successfully!";
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    ModelState.AddModelError("", "Failed to update room. Please try again.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating room with ID: {id}");
                ModelState.AddModelError("", "An error occurred while updating the room. Please try again.");
            }

            // Repopulate dropdowns on error
            try
            {
                var roomTypes = await _roomTypeService.GetAllRoomTypesAsync();
                model.RoomTypes = roomTypes.Select(rt => new RoomTypeDropdownViewModel
                {
                    Id = rt.Id,
                    Name = rt.Name,
                    Description = rt.Description,
                    Price = rt.PricePerNight,
                    Capacity = rt.Capacity,
                    IconClass = "fas fa-bed"
                }).ToList();

                model.StatusOptions = new List<string> { "Available", "Occupied", "Maintenance", "Cleaning" };
                model.ViewOptions = new List<string> { "City View", "Sea View", "Ocean View", "Garden View", "Pool View" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error repopulating room form dropdowns after update failure");
            }

            return View(model);
        }

        // POST: Admin/Rooms/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var result = await _roomTypeService.DeleteRoomAsync(id);

                if (result)
                {
                    TempData["Success"] = "Room deleted successfully!";
                }
                else
                {
                    TempData["Error"] = "Room not found or cannot be deleted.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting room with ID: {id}");
                TempData["Error"] = "An error occurred while deleting the room.";
            }

            return RedirectToAction(nameof(Index));
        }

        // POST: Admin/Rooms/UpdateStatus/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateStatus(int id, string status)
        {
            try
            {
                var validStatuses = new[] { "Available", "Occupied", "Maintenance", "Cleaning" };
                if (!validStatuses.Contains(status))
                {
                    TempData["Error"] = "Invalid status provided.";
                    return RedirectToAction(nameof(Index));
                }

                var result = await _roomTypeService.UpdateRoomStatusAsync(id, status);

                if (result)
                {
                    TempData["Success"] = $"Room status updated to {status} successfully!";
                }
                else
                {
                    TempData["Error"] = "Room not found or status cannot be updated.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating room status for ID: {id}");
                TempData["Error"] = "An error occurred while updating the room status.";
            }

            return RedirectToAction(nameof(Index));
        }

        // AJAX: Check if room number exists
        [HttpPost]
        public async Task<JsonResult> CheckRoomNumberExists(string roomNumber, int? id = null)
        {
            try
            {
                var exists = await _roomTypeService.RoomNumberExistsAsync(roomNumber, id);
                return Json(new { exists = exists });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking room number existence");
                return Json(new { exists = false });
            }
        }
    }
}