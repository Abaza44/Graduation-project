﻿using Bookify.Core.DTOs;
using Bookify.Core.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace BookifyReservationHotel.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class PaymentsController : Controller
    {
        private readonly IPaymentService _paymentService;
        private readonly ILogger<PaymentsController> _logger;

        public PaymentsController(IPaymentService paymentService, ILogger<PaymentsController> logger)
        {
            _paymentService = paymentService;
            _logger = logger;
        }

        public async Task<IActionResult> Index(PaymentFilterDto filter)
        {
            try
            {
                var payments = await _paymentService.FilterPaymentsAsync(filter);
                ViewBag.Filter = filter;
                return View(payments);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving payments");
                TempData["Error"] = "An error occurred while retrieving payments.";
                return View(new List<PaymentDto>());
            }
        }

        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var payment = await _paymentService.GetPaymentByIdAsync(id);
                return View(payment);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving payment {id}");
                TempData["Error"] = "Payment not found.";
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProcessPayment(int id)
        {
            try
            {
                var payment = await _paymentService.GetPaymentByIdAsync(id);

                // Simulate payment processing
                var processDto = new ProcessPaymentDto
                {
                    PaymentId = id,
                    TransactionId = $"TXN{DateTime.UtcNow:yyyyMMddHHmmss}",
                    PaymentStatus = "Completed",
                    PaymentResponse = "{\"status\":\"approved\",\"code\":\"00\"}"
                };

                var result = await _paymentService.ProcessPaymentAsync(processDto);

                TempData["Success"] = "Payment processed successfully!";
                return RedirectToAction(nameof(Details), new { id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error processing payment {id}");
                TempData["Error"] = ex.Message;
                return RedirectToAction(nameof(Details), new { id });
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Refund(int id, string reason)
        {
            try
            {
                var refundDto = new RefundPaymentDto
                {
                    PaymentId = id,
                    RefundReason = reason
                };

                var result = await _paymentService.RefundPaymentAsync(refundDto);

                if (result)
                {
                    TempData["Success"] = "Refund processed successfully!";
                }
                else
                {
                    TempData["Error"] = "Failed to process refund.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error refunding payment {id}");
                TempData["Error"] = ex.Message;
            }

            return RedirectToAction(nameof(Details), new { id });
        }

        public async Task<IActionResult> Summary()
        {
            try
            {
                var summary = await _paymentService.GetPaymentSummaryAsync();
                return View(summary);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving payment summary");
                TempData["Error"] = "An error occurred while retrieving payment summary.";
                return View(new PaymentSummaryDto());
            }
        }
    }
}