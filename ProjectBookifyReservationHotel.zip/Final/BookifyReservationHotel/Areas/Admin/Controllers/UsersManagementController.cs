﻿using Bookify.Core.Entities;
using BookifyReservationHotel.Models.ViewModels.Admin;
using BookifyReservationHotel.Models.ViewModels.Admin;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BookifyReservationHotel.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class UsersManagementController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly ILogger<UsersManagementController> _logger;

        public UsersManagementController(
            UserManager<ApplicationUser> userManager,
            RoleManager<IdentityRole> roleManager,
            ILogger<UsersManagementController> logger)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _logger = logger;
        }

        public async Task<IActionResult> Index(string? searchTerm, string? role)
        {
            try
            {
                var users = _userManager.Users.AsQueryable();

                if (!string.IsNullOrEmpty(searchTerm))
                {
                    users = users.Where(u =>
                        u.FirstName.Contains(searchTerm) ||
                        u.LastName.Contains(searchTerm) ||
                        u.Email.Contains(searchTerm) ||
                        u.PhoneNumber.Contains(searchTerm));
                }

                var userViewModels = new List<UserManagementViewModel>();

                foreach (var user in await users.ToListAsync())
                {
                    var roles = await _userManager.GetRolesAsync(user);
                    userViewModels.Add(new UserManagementViewModel
                    {
                        Id = user.Id,
                        FirstName = user.FirstName,
                        LastName = user.LastName,
                        Email = user.Email,
                        PhoneNumber = user.PhoneNumber,
                        Role = roles.FirstOrDefault() ?? "Customer",
                        CreatedDate = user.CreatedDate,
                        LastLoginDate = null, // You would track this separately
                        IsActive = user.LockoutEnd == null || user.LockoutEnd < DateTime.Now
                    });
                }

                if (!string.IsNullOrEmpty(role))
                {
                    userViewModels = userViewModels.Where(u => u.Role == role).ToList();
                }

                ViewBag.SearchTerm = searchTerm;
                ViewBag.SelectedRole = role;
                ViewBag.AvailableRoles = await _roleManager.Roles.Select(r => r.Name).ToListAsync();

                return View(userViewModels);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving users");
                TempData["Error"] = "An error occurred while retrieving users.";
                return View(new List<UserManagementViewModel>());
            }
        }

        public async Task<IActionResult> Details(string id)
        {
            try
            {
                var user = await _userManager.FindByIdAsync(id);
                if (user == null)
                {
                    return NotFound();
                }

                var roles = await _userManager.GetRolesAsync(user);

                var model = new UserManagementViewModel
                {
                    Id = user.Id,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email,
                    PhoneNumber = user.PhoneNumber,
                    Role = roles.FirstOrDefault() ?? "Customer",
                    CreatedDate = user.CreatedDate,
                    IsActive = user.LockoutEnd == null || user.LockoutEnd < DateTime.Now,
                    AvailableRoles = await _roleManager.Roles.Select(r => r.Name).ToListAsync(),
                    SelectedRoles = roles.ToList()
                };

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving user {id}");
                TempData["Error"] = "An error occurred while retrieving user details.";
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateRoles(string id, List<string> selectedRoles)
        {
            try
            {
                var user = await _userManager.FindByIdAsync(id);
                if (user == null)
                {
                    return NotFound();
                }

                var currentRoles = await _userManager.GetRolesAsync(user);
                await _userManager.RemoveFromRolesAsync(user, currentRoles);

                if (selectedRoles != null && selectedRoles.Any())
                {
                    await _userManager.AddToRolesAsync(user, selectedRoles);
                }

                TempData["Success"] = "User roles updated successfully!";
                return RedirectToAction(nameof(Details), new { id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating roles for user {id}");
                TempData["Error"] = "An error occurred while updating user roles.";
                return RedirectToAction(nameof(Details), new { id });
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ToggleStatus(string id)
        {
            try
            {
                var user = await _userManager.FindByIdAsync(id);
                if (user == null)
                {
                    return NotFound();
                }

                if (user.LockoutEnd == null || user.LockoutEnd < DateTime.Now)
                {
                    // Lock the user
                    await _userManager.SetLockoutEndDateAsync(user, DateTimeOffset.MaxValue);
                    TempData["Success"] = "User account has been disabled.";
                }
                else
                {
                    // Unlock the user
                    await _userManager.SetLockoutEndDateAsync(user, null);
                    TempData["Success"] = "User account has been enabled.";
                }

                return RedirectToAction(nameof(Details), new { id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error toggling status for user {id}");
                TempData["Error"] = "An error occurred while updating user status.";
                return RedirectToAction(nameof(Details), new { id });
            }
        }
    }
}