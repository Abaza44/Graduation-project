﻿namespace BookifyReservationHotel.Areas.Admin
{
    public class ReviewsController
    {
    }
}
