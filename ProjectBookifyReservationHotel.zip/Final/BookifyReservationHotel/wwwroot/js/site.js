﻿// ============================================
// Bookify.Web/wwwroot/js/site.js
// ============================================

// Initialize all functionality when DOM is ready
// ============================================
// Bookify.Web/wwwroot/js/site.js - IMPROVED VERSION

// ============================================

// Initialize all functionality when DOM is ready
document.addEventListener('DOMContentLoaded', function () {
    initializeDateValidation();
    initializePriceCalculator();
    initializeImagePreview();
    initializeFormValidation();
    initializeTooltips();
    initializeConfirmDialogs();
    autoHideAlerts();
    initializeSearchFilters();
    initializeStarRating();
    initializeLazyLoading();
    initializeBackToTop();
});

// ... rest of your JavaScript code remains the same ...

// ============================================
// Date Validation
// ============================================
function initializeDateValidation() {
    const checkInInputs = document.querySelectorAll('input[name="CheckInDate"], input[name="checkIn"]');
    const checkOutInputs = document.querySelectorAll('input[name="CheckOutDate"], input[name="checkOut"]');

    const today = new Date().toISOString().split('T')[0];

    checkInInputs.forEach(input => {
        input.min = today;

        input.addEventListener('change', function () {
            const checkInDate = new Date(this.value);
            const nextDay = new Date(checkInDate);
            nextDay.setDate(nextDay.getDate() + 1);

            checkOutInputs.forEach(output => {
                output.min = nextDay.toISOString().split('T')[0];

                if (output.value && new Date(output.value) <= checkInDate) {
                    output.value = nextDay.toISOString().split('T')[0];
                }
            });
        });
    });
}

// ============================================
// Price Calculator
// ============================================
function initializePriceCalculator() {
    const pricePerNightElements = document.querySelectorAll('[data-price-per-night]');

    pricePerNightElements.forEach(element => {
        const pricePerNight = parseFloat(element.dataset.pricePerNight);
        const checkInInput = document.querySelector('input[name="CheckInDate"], input[name="checkIn"]');
        const checkOutInput = document.querySelector('input[name="CheckOutDate"], input[name="checkOut"]');
        const totalDisplay = document.getElementById('totalPrice');

        if (checkInInput && checkOutInput && totalDisplay) {
            const calculateTotal = () => {
                const checkIn = new Date(checkInInput.value);
                const checkOut = new Date(checkOutInput.value);

                if (checkIn && checkOut && checkOut > checkIn) {
                    const nights = Math.ceil((checkOut - checkIn) / (1000 * 60 * 60 * 24));
                    const total = pricePerNight * nights;
                    const serviceFee = total * 0.1;
                    const taxes = total * 0.14;
                    const grandTotal = total + serviceFee + taxes;

                    totalDisplay.innerHTML = `
                        <div class="mb-2">
                            <span>${pricePerNight.toFixed(2)} EGP × ${nights} night${nights > 1 ? 's' : ''}</span>
                            <strong>${total.toFixed(2)} EGP</strong>
                        </div>
                        <div class="mb-2">
                            <span>Service Fee</span>
                            <strong>${serviceFee.toFixed(2)} EGP</strong>
                        </div>
                        <div class="mb-2">
                            <span>Taxes</span>
                            <strong>${taxes.toFixed(2)} EGP</strong>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <h5>Total</h5>
                            <h5 class="text-primary">${grandTotal.toFixed(2)} EGP</h5>
                        </div>
                    `;
                }
            };

            checkInInput.addEventListener('change', calculateTotal);
            checkOutInput.addEventListener('change', calculateTotal);

            // Calculate on page load if dates are present
            if (checkInInput.value && checkOutInput.value) {
                calculateTotal();
            }
        }
    });
}

// ============================================
// Image Preview for File Upload
// ============================================
function initializeImagePreview() {
    const imageInputs = document.querySelectorAll('input[type="file"][accept*="image"]');

    imageInputs.forEach(input => {
        input.addEventListener('change', function (e) {
            const files = e.target.files;
            const previewContainer = document.getElementById('imagePreview');

            if (previewContainer && files.length > 0) {
                previewContainer.innerHTML = '';

                Array.from(files).forEach(file => {
                    const reader = new FileReader();

                    reader.onload = function (e) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.classList.add('img-thumbnail', 'm-2');
                        img.style.maxWidth = '200px';
                        img.style.maxHeight = '200px';
                        previewContainer.appendChild(img);
                    };

                    reader.readAsDataURL(file);
                });
            }
        });
    });
}

// ============================================
// Form Validation
// ============================================
function initializeFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');

    Array.from(forms).forEach(form => {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }

            form.classList.add('was-validated');
        }, false);
    });
}

// ============================================
// Initialize Bootstrap Tooltips
// ============================================
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// ============================================
// Confirm Dialogs
// ============================================
function initializeConfirmDialogs() {
    const confirmButtons = document.querySelectorAll('[data-confirm]');

    confirmButtons.forEach(button => {
        button.addEventListener('click', function (e) {
            const message = this.dataset.confirm || 'Are you sure?';

            if (!confirm(message)) {
                e.preventDefault();
                return false;
            }
        });
    });
}

// ============================================
// Auto Hide Alerts
// ============================================
function autoHideAlerts() {
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');

    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
}

// ============================================
// Search Filters
// ============================================
function initializeSearchFilters() {
    const filterForm = document.getElementById('filterForm');

    if (filterForm) {
        const inputs = filterForm.querySelectorAll('input, select');

        inputs.forEach(input => {
            input.addEventListener('change', function () {
                // Auto-submit on change (optional)
                // filterForm.submit();
            });
        });
    }
}

// ============================================
// Loading Spinner
// ============================================
function showLoading() {
    const loadingOverlay = document.createElement('div');
    loadingOverlay.id = 'loadingOverlay';
    loadingOverlay.className = 'position-fixed top-0 start-0 w-100 h-100 d-flex justify-content-center align-items-center';
    loadingOverlay.style.backgroundColor = 'rgba(0,0,0,0.5)';
    loadingOverlay.style.zIndex = '9999';
    loadingOverlay.innerHTML = `
        <div class="spinner-border text-light" role="status" style="width: 3rem; height: 3rem;">
            <span class="visually-hidden">Loading...</span>
        </div>
    `;
    document.body.appendChild(loadingOverlay);
}

function hideLoading() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
        loadingOverlay.remove();
    }
}

// ============================================
// Smooth Scroll to Element
// ============================================
function smoothScrollTo(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// ============================================
// Format Currency
// ============================================
function formatCurrency(amount, currency = 'EGP') {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency
    }).format(amount);
}

// ============================================
// Calculate Nights Between Dates
// ============================================
function calculateNights(checkIn, checkOut) {
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const diffTime = Math.abs(end - start);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
}

// ============================================
// Copy to Clipboard
// ============================================
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showNotification('Copied to clipboard!', 'success');
    }).catch(err => {
        showNotification('Failed to copy!', 'error');
    });
}

// ============================================
// Show Notification
// ============================================
function showNotification(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alertDiv.style.zIndex = '9999';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    document.body.appendChild(alertDiv);

    setTimeout(() => {
        alertDiv.remove();
    }, 3000);
}

// ============================================
// Print Page
// ============================================
function printPage() {
    window.print();
}

// ============================================
// Export to PDF (requires library like jsPDF)
// ============================================
function exportToPDF() {
    // This would require jsPDF library
    showNotification('PDF export feature coming soon!', 'info');
}

// ============================================
// Filter Table
// ============================================
function filterTable(inputId, tableId) {
    const input = document.getElementById(inputId);
    const table = document.getElementById(tableId);

    if (input && table) {
        input.addEventListener('keyup', function () {
            const filter = this.value.toUpperCase();
            const rows = table.getElementsByTagName('tr');

            for (let i = 1; i < rows.length; i++) {
                const row = rows[i];
                const cells = row.getElementsByTagName('td');
                let found = false;

                for (let j = 0; j < cells.length; j++) {
                    const cell = cells[j];
                    if (cell) {
                        const textValue = cell.textContent || cell.innerText;
                        if (textValue.toUpperCase().indexOf(filter) > -1) {
                            found = true;
                            break;
                        }
                    }
                }

                row.style.display = found ? '' : 'none';
            }
        });
    }
}

// ============================================
// Star Rating Component
// ============================================
function initializeStarRating() {
    const ratingContainers = document.querySelectorAll('.star-rating-input');

    ratingContainers.forEach(container => {
        const stars = container.querySelectorAll('.star');
        const input = container.querySelector('input[type="hidden"]');

        stars.forEach((star, index) => {
            star.addEventListener('click', () => {
                const rating = index + 1;
                input.value = rating;

                stars.forEach((s, i) => {
                    if (i < rating) {
                        s.classList.add('active');
                        s.innerHTML = '<i class="fas fa-star"></i>';
                    } else {
                        s.classList.remove('active');
                        s.innerHTML = '<i class="far fa-star"></i>';
                    }
                });
            });

            star.addEventListener('mouseenter', () => {
                stars.forEach((s, i) => {
                    if (i <= index) {
                        s.innerHTML = '<i class="fas fa-star"></i>';
                    } else {
                        s.innerHTML = '<i class="far fa-star"></i>';
                    }
                });
            });
        });

        container.addEventListener('mouseleave', () => {
            const currentRating = parseInt(input.value) || 0;
            stars.forEach((s, i) => {
                if (i < currentRating) {
                    s.innerHTML = '<i class="fas fa-star"></i>';
                } else {
                    s.innerHTML = '<i class="far fa-star"></i>';
                }
            });
        });
    });
}

// ============================================
// Lazy Loading Images
// ============================================
function initializeLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');

    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                observer.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
}

// ============================================
// Back to Top Button
// ============================================
function initializeBackToTop() {
    const backToTopButton = document.getElementById('backToTop');

    if (backToTopButton) {
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTopButton.style.display = 'block';
            } else {
                backToTopButton.style.display = 'none';
            }
        });

        backToTopButton.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
}

// ============================================
// Export Functions for Global Use
// ============================================
window.bookify = {
    showLoading,
    hideLoading,
    smoothScrollTo,
    formatCurrency,
    calculateNights,
    copyToClipboard,
    showNotification,
    printPage,
    exportToPDF,
    filterTable
};
