﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using BookifyReservationHotel.Models.ViewModels.Shared;

namespace BookifyReservationHotel.Models.ViewModels.Admin
{
    // Booking ViewModels
    public class BookingDetailsViewModel
    {
        public int Id { get; set; }

        [Display(Name = "Confirmation Code")]
        public string ConfirmationCode { get; set; } = string.Empty;

        [Display(Name = "Guest Name")]
        public string UserName { get; set; } = string.Empty;

        [Display(Name = "Email")]
        public string UserEmail { get; set; } = string.Empty;

        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; } = string.Empty;

        [Display(Name = "Room Number")]
        public string RoomNumber { get; set; } = string.Empty;

        [Display(Name = "Room Type")]
        public string RoomTypeName { get; set; } = string.Empty;

        [Display(Name = "Floor")]
        public string Floor { get; set; } = string.Empty;

        [Display(Name = "View")]
        public string View { get; set; } = string.Empty;

        [Display(Name = "Check-In Date")]
        [DataType(DataType.Date)]
        public DateTime CheckInDate { get; set; }

        [Display(Name = "Check-Out Date")]
        [DataType(DataType.Date)]
        public DateTime CheckOutDate { get; set; }

        [Display(Name = "Number of Guests")]
        public int NumberOfGuests { get; set; }

        [Display(Name = "Total Nights")]
        public int TotalNights { get; set; }

        [Display(Name = "Price Per Night")]
        [DataType(DataType.Currency)]
        public decimal PricePerNight { get; set; }

        [Display(Name = "Total Amount")]
        [DataType(DataType.Currency)]
        public decimal TotalAmount { get; set; }

        [Display(Name = "Booking Status")]
        public string BookingStatus { get; set; } = string.Empty;

        [Display(Name = "Payment Status")]
        public string PaymentStatus { get; set; } = string.Empty;

        [Display(Name = "Booking Date")]
        public DateTime BookingDate { get; set; }

        [Display(Name = "Special Requests")]
        public string SpecialRequests { get; set; } = string.Empty;

        [Display(Name = "Cancellation Reason")]
        public string CancellationReason { get; set; } = string.Empty;

        [Display(Name = "Cancellation Date")]
        public DateTime? CancellationDate { get; set; }

        public List<string> RoomImages { get; set; } = new List<string>();

        public bool CanCancel => BookingStatus == "Pending" || BookingStatus == "Confirmed";
        public bool CanCheckIn => BookingStatus == "Confirmed";
        public bool CanCheckOut => BookingStatus == "CheckedIn";
    }

    public class BookingManagementViewModel
    {
        public int Id { get; set; }

        [Display(Name = "Confirmation Code")]
        public string ConfirmationCode { get; set; } = string.Empty;

        [Display(Name = "Guest Name")]
        public string GuestName { get; set; } = string.Empty;

        [Display(Name = "Guest Email")]
        public string GuestEmail { get; set; } = string.Empty;

        [Display(Name = "Room Type")]
        public string RoomTypeName { get; set; } = string.Empty;

        [Display(Name = "Room Number")]
        public string RoomNumber { get; set; } = string.Empty;

        [Display(Name = "Check-in")]
        [DataType(DataType.Date)]
        public DateTime CheckInDate { get; set; }

        [Display(Name = "Check-out")]
        [DataType(DataType.Date)]
        public DateTime CheckOutDate { get; set; }

        [Display(Name = "Total Amount")]
        public decimal TotalAmount { get; set; }

        [Display(Name = "Status")]
        public string BookingStatus { get; set; } = string.Empty;

        [Display(Name = "Booking Date")]
        public DateTime BookingDate { get; set; }

        [Display(Name = "Nights")]
        public int TotalNights { get; set; }

        [Display(Name = "Guests")]
        public int NumberOfGuests { get; set; }
    }

    // RoomType ViewModels
    public class CreateRoomTypeViewModel
    {
        [Required(ErrorMessage = "Room type name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
        [Display(Name = "Room Type Name")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Description is required")]
        [StringLength(1000, ErrorMessage = "Description cannot exceed 1000 characters")]
        [Display(Name = "Description")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Price per night is required")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than 0")]
        [Display(Name = "Price Per Night")]
        public decimal PricePerNight { get; set; }

        [Required(ErrorMessage = "Capacity is required")]
        [Range(1, 10, ErrorMessage = "Capacity must be between 1 and 10")]
        [Display(Name = "Capacity (Guests)")]
        public int Capacity { get; set; }

        [Range(0, 1000, ErrorMessage = "Size must be between 0 and 1000")]
        [Display(Name = "Size (Square Feet)")]
        public decimal SizeInSqFt { get; set; }

        [Display(Name = "Amenities")]
        public List<int> AmenityIds { get; set; } = new List<int>();

        [Display(Name = "Upload Images")]
        public List<IFormFile> Images { get; set; } = new List<IFormFile>();

        [Display(Name = "Is Active")]
        public bool IsActive { get; set; } = true;
    }

    public class RoomTypeListViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal PricePerNight { get; set; }
        public int Capacity { get; set; }
        public decimal SizeInSqFt { get; set; }
        public bool IsActive { get; set; }
        public int TotalRooms { get; set; }
        public int AvailableRooms { get; set; }
        public double AverageRating { get; set; }
        public int TotalBookings { get; set; }
        public List<string> Amenities { get; set; } = new();
        public string MainImage { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
    }

    public class RoomTypeDetailViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal PricePerNight { get; set; }
        public int Capacity { get; set; }
        public decimal SizeInSqFt { get; set; }
        public bool IsActive { get; set; }
        public List<string> ImageUrls { get; set; } = new();
        public List<AdminAmenityViewModel> Amenities { get; set; } = new();
        public int TotalRooms { get; set; }
        public int AvailableRooms { get; set; }
        public double AverageRating { get; set; }
        public int TotalReviews { get; set; }
        public int TotalBookings { get; set; }
        public decimal TotalRevenue { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
    }

    public class RoomTypeFormViewModel
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } = string.Empty;

        [Required]
        public string Description { get; set; } = string.Empty;

        [Required]
        [Range(0.01, 10000)]
        public decimal PricePerNight { get; set; }

        [Required]
        [Range(1, 20)]
        public int Capacity { get; set; }

        [Required]
        [Range(1, 5000)]
        public decimal SizeInSqFt { get; set; }

        public bool IsActive { get; set; } = true;
        public List<int> SelectedAmenityIds { get; set; } = new();
        public List<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem> AvailableAmenities { get; set; } = new();
        public List<AdminImageViewModel> ExistingImages { get; set; } = new();
        public List<string> ImageUrls { get; set; } = new();

        // Statistics (for edit view)
        public int TotalRooms { get; set; }
        public int AvailableRooms { get; set; }
        public double AverageRating { get; set; }
        public int TotalBookings { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
    }

    // Room ViewModels
    public class RoomManagementViewModel
    {
        public int Id { get; set; }

        [Display(Name = "Room Number")]
        public string RoomNumber { get; set; } = string.Empty;

        [Display(Name = "Room Type ID")]
        public int RoomTypeId { get; set; }

        [Display(Name = "Room Type")]
        public string RoomTypeName { get; set; } = string.Empty;

        [Display(Name = "Floor")]
        public string Floor { get; set; } = string.Empty;

        [Display(Name = "View")]
        public string View { get; set; } = string.Empty;

        [Display(Name = "Status")]
        public string Status { get; set; } = string.Empty;

        [Display(Name = "Additional Notes")]
        public string? AdditionalNotes { get; set; }

        [Display(Name = "Last Maintenance Date")]
        [DataType(DataType.Date)]
        public DateTime? LastMaintenanceDate { get; set; }

        [Display(Name = "Created Date")]
        public DateTime CreatedDate { get; set; }

        [Display(Name = "Updated Date")]
        public DateTime UpdatedDate { get; set; }

        // Additional info
        [Display(Name = "Total Bookings")]
        public int TotalBookings { get; set; }

        [Display(Name = "Active Bookings")]
        public int ActiveBookings { get; set; }
    }

    public class RoomFormViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Room type is required")]
        [Display(Name = "Room Type")]
        public int RoomTypeId { get; set; }

        [Required(ErrorMessage = "Room number is required")]
        [Display(Name = "Room Number")]
        [StringLength(10, ErrorMessage = "Room number cannot exceed 10 characters")]
        public string RoomNumber { get; set; } = string.Empty;

        [Required(ErrorMessage = "Floor is required")]
        [Display(Name = "Floor")]
        [StringLength(10, ErrorMessage = "Floor cannot exceed 10 characters")]
        public string Floor { get; set; } = string.Empty;

        [Required(ErrorMessage = "View is required")]
        [Display(Name = "View")]
        public string View { get; set; } = string.Empty;

        [Required(ErrorMessage = "Status is required")]
        [Display(Name = "Status")]
        public string Status { get; set; } = "Available";

        [Display(Name = "Additional Notes")]
        [StringLength(500, ErrorMessage = "Additional notes cannot exceed 500 characters")]
        public string? AdditionalNotes { get; set; }

        [Display(Name = "Last Maintenance Date")]
        [DataType(DataType.Date)]
        public DateTime? LastMaintenanceDate { get; set; }

        // Use RoomTypeDropdownViewModel from Shared
        public List<RoomTypeDropdownViewModel> RoomTypes { get; set; } = new();
        public List<string> StatusOptions { get; set; } = new();
        public List<string> ViewOptions { get; set; } = new();
    }

    // Dashboard ViewModel
    public class DashboardStatsViewModel
    {
        public int TotalBookingsToday { get; set; }
        public int TotalBookingsThisMonth { get; set; }
        public decimal RevenueToday { get; set; }
        public decimal RevenueThisMonth { get; set; }
        public int TotalRooms { get; set; }
        public int AvailableRooms { get; set; }
        public double OccupancyRate { get; set; }
        public int CheckInsToday { get; set; }
        public int CheckOutsToday { get; set; }
        public int PendingBookings { get; set; }
        public int TotalCustomers { get; set; }
        public int NewCustomersThisMonth { get; set; }

        // Chart Data
        public List<decimal> RevenueLast7Days { get; set; } = new();
        public List<int> BookingsLast7Days { get; set; } = new();
        public Dictionary<string, int> RoomStatusDistribution { get; set; } = new();
    }

    // User Management ViewModel
    public class UserManagementViewModel
    {
        public string Id { get; set; } = string.Empty;

        [Display(Name = "First Name")]
        public string FirstName { get; set; } = string.Empty;

        [Display(Name = "Last Name")]
        public string LastName { get; set; } = string.Empty;

        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Display(Name = "Phone Number")]
        public string? PhoneNumber { get; set; }

        [Display(Name = "Role")]
        public string Role { get; set; } = string.Empty;

        [Display(Name = "Member Since")]
        public DateTime CreatedDate { get; set; }

        [Display(Name = "Last Login")]
        public DateTime? LastLoginDate { get; set; }

        [Display(Name = "Status")]
        public bool IsActive { get; set; }

        [Display(Name = "Total Bookings")]
        public int TotalBookings { get; set; }

        [Display(Name = "Total Spent")]
        public decimal TotalSpent { get; set; }

        // For editing
        public List<string> AvailableRoles { get; set; } = new();
        public List<string> SelectedRoles { get; set; } = new();
    }

    // Admin-specific ViewModels with "Admin" prefix to avoid conflicts
    public class AdminAmenityViewModel
    {
        public string Name { get; set; } = string.Empty;
        public string IconClass { get; set; } = string.Empty;
    }

    public class AdminImageViewModel
    {
        public string ImageUrl { get; set; } = string.Empty;
        public string AltText { get; set; } = string.Empty;
        public bool IsPrimary { get; set; }
    }
}