﻿using BookifyReservationHotel.Models.ViewModels.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BookifyReservationHotel.Models.ViewModels.Rooms
{
    public class RoomSearchResultViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
        public decimal PricePerNight { get; set; }
        public int Capacity { get; set; }
        public decimal SizeInSqFt { get; set; }
        public int AvailableRoomsCount { get; set; }
        public List<string> ImageUrls { get; set; } = new();
        public double AverageRating { get; set; }
        public int TotalReviews { get; set; }

        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public int NumberOfGuests { get; set; }
        public int TotalNights { get; set; }
        public decimal TotalPrice { get; set; }
        [MaxLength(500)]
        public string? ImageUrl { get; set; }

    }

}
