﻿using System;
using System.Collections.Generic;
using BookifyReservationHotel.Models.ViewModels.Shared;

namespace BookifyReservationHotel.Models.ViewModels.Rooms
{
    public class RoomDetailsViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal PricePerNight { get; set; }
        public int Capacity { get; set; }
        public decimal SizeInSqFt { get; set; }
        public int AvailableRoomsCount { get; set; }
        public List<string> ImageUrls { get; set; } = new List<string>();
        public List<AmenityViewModel> Amenities { get; set; } = new List<AmenityViewModel>();
        public double AverageRating { get; set; }
        public int TotalReviews { get; set; }
        public string BedType { get; set; } = string.Empty;
        public string View { get; set; } = string.Empty;
        public bool IsSmokingAllowed { get; set; }
        public bool ArePetsAllowed { get; set; }
        public bool HasWifi { get; set; }
        public bool HasAirConditioning { get; set; }
        public bool HasTV { get; set; }
        public bool HasMiniBar { get; set; }
        public bool HasRoomService { get; set; }
    }
}
