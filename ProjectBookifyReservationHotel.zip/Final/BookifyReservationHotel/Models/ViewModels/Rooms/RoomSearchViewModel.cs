﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BookifyReservationHotel.Models.ViewModels.Rooms
{
    public class RoomSearchViewModel
    {
        [Required]
        [DataType(DataType.Date)]
        public DateTime CheckInDate { get; set; } = DateTime.Today.AddDays(1);
        public string? RoomName { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime CheckOutDate { get; set; } = DateTime.Today.AddDays(2);

        [Required]
        [Range(1, 10)]
        public int Guests { get; set; } = 2;
     
        // النتائج بعد البحث
        public List<RoomSearchResultViewModel> Results { get; set; } = new List<RoomSearchResultViewModel>();

        // الفلاتر الإضافية
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public int? MinCapacity { get; set; }
        public int? MaxCapacity { get; set; }
        public int? RoomTypeId { get; set; }

        // لو محتاج تختار من قائمة أنواع الغرف
        public List<SelectListItem>? RoomTypes { get; set; }

        public List<int> SelectedAmenityIds { get; set; } = new List<int>();
        public List<Shared.AmenityViewModel> AvailableAmenities { get; set; } = new List<Shared.AmenityViewModel>();

        // Sorting
        public string SortBy { get; set; } = "name"; // name, price, rating
        public string SortOrder { get; set; } = "asc"; // asc, desc

        // Helpers
        public bool HasFilters => MinPrice.HasValue || MaxPrice.HasValue || MinCapacity.HasValue || MaxCapacity.HasValue || (SelectedAmenityIds?.Count > 0);
    }
}
