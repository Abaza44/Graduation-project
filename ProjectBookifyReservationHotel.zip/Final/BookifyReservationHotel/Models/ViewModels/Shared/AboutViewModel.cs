﻿// Models/ViewModels/Shared/AboutViewModel.cs
public class AboutViewModel
{
    public string Title { get; set; }
    public string Description { get; set; }
    public List<FeatureViewModel> Features { get; set; }
    public List<StatViewModel> Stats { get; set; }
}

public class FeatureViewModel
{
    public string Title { get; set; }
    public string Description { get; set; }
    public string Icon { get; set; }
}

public class StatViewModel
{
    public string Number { get; set; }
    public string Label { get; set; }
}

// Models/ViewModels/Shared/ServicesViewModel.cs
public class ServicesViewModel
{
    public List<ServiceViewModel> Services { get; set; }
}

public class ServiceViewModel
{
    public string Title { get; set; }
    public string Description { get; set; }
    public string Icon { get; set; }
    public List<string> Features { get; set; }
}

// Models/ViewModels/Shared/GalleryViewModel.cs
public class GalleryViewModel
{
    public List<GalleryImageViewModel> Images { get; set; }
}

public class GalleryImageViewModel
{
    public string Url { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
}

// Models/ViewModels/Shared/TestimonialsViewModel.cs
public class TestimonialsViewModel
{
    public List<TestimonialViewModel> Testimonials { get; set; }
}

public class TestimonialViewModel
{
    public string CustomerName { get; set; }
    public string Position { get; set; }
    public string Content { get; set; }
    public int Rating { get; set; }
    public string ImageUrl { get; set; }
}

// Models/ViewModels/Shared/PrivacyViewModel.cs
public class PrivacyViewModel
{
    public DateTime LastUpdated { get; set; }
    public List<PolicySectionViewModel> PolicySections { get; set; }
}

public class PolicySectionViewModel
{
    public string Title { get; set; }
    public string Content { get; set; }
}