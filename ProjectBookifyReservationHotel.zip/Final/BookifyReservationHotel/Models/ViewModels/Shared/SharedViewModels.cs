﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BookifyReservationHotel.Models.ViewModels.Shared
{
    // RoomType Dropdown ViewModel
    public class RoomTypeDropdownViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public decimal Price { get; set; }
        public int Capacity { get; set; }
        public string IconClass { get; set; } = string.Empty;
        public string DisplayText => $"{Name} - ${Price}/night (Max {Capacity} guests)";
    }

    // Pagination ViewModels
    public class PagedResultViewModel<T>
    {
        public List<T> Items { get; set; } = new();
        public int TotalCount { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
        public int TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
        public bool HasPrevious => PageNumber > 1;
        public bool HasNext => PageNumber < TotalPages;

        public PagedResultViewModel()
        {
        }

        public PagedResultViewModel(List<T> items, int totalCount, int pageNumber, int pageSize)
        {
            Items = items;
            TotalCount = totalCount;
            PageNumber = pageNumber;
            PageSize = pageSize;
        }
    }

    public class PaginationInfoViewModel
    {
        public int PageNumber { get; set; }
        public int TotalPages { get; set; }
        public bool HasPrevious { get; set; }
        public bool HasNext { get; set; }
        public string? BaseUrl { get; set; }
        public Dictionary<string, string> QueryParameters { get; set; } = new();
    }

    // Notification and Alert ViewModels
    public class NotificationViewModel
    {
        public string Type { get; set; } = "info"; // success, error, warning, info
        public string Title { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public bool IsDismissible { get; set; } = true;
        public int? AutoHideDelay { get; set; } = 5000; // milliseconds

        public static NotificationViewModel Success(string message, string title = "Success")
        {
            return new NotificationViewModel { Type = "success", Title = title, Message = message };
        }

        public static NotificationViewModel Error(string message, string title = "Error")
        {
            return new NotificationViewModel { Type = "error", Title = title, Message = message };
        }

        public static NotificationViewModel Warning(string message, string title = "Warning")
        {
            return new NotificationViewModel { Type = "warning", Title = title, Message = message };
        }

        public static NotificationViewModel Info(string message, string title = "Information")
        {
            return new NotificationViewModel { Type = "info", Title = title, Message = message };
        }
    }

    public class AlertViewModel
    {
        public string AlertType { get; set; } = "alert-info";
        public string IconClass { get; set; } = "fas fa-info-circle";
        public string Title { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public bool Dismissible { get; set; } = true;

        public AlertViewModel(string alertType, string iconClass, string title, string message, bool dismissible = true)
        {
            AlertType = alertType;
            IconClass = iconClass;
            Title = title;
            Message = message;
            Dismissible = dismissible;
        }

        public static AlertViewModel Success(string message, string title = "Success", bool dismissible = true)
        {
            return new AlertViewModel("alert-success", "fas fa-check-circle", title, message, dismissible);
        }

        public static AlertViewModel Error(string message, string title = "Error", bool dismissible = true)
        {
            return new AlertViewModel("alert-danger", "fas fa-exclamation-triangle", title, message, dismissible);
        }

        public static AlertViewModel Warning(string message, string title = "Warning", bool dismissible = true)
        {
            return new AlertViewModel("alert-warning", "fas fa-exclamation-circle", title, message, dismissible);
        }

        public static AlertViewModel Info(string message, string title = "Information", bool dismissible = true)
        {
            return new AlertViewModel("alert-info", "fas fa-info-circle", title, message, dismissible);
        }
    }

    // Image ViewModel
    public class ImageViewModel
    {
        public string ImageUrl { get; set; } = string.Empty;
        public string AltText { get; set; } = string.Empty;
        public bool IsPrimary { get; set; }
    }

    // Error ViewModel
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
        public string? ErrorMessage { get; set; }
        public int? StatusCode { get; set; }
        public string? StackTrace { get; set; }
    }

    // Contact ViewModel
    public class ContactViewModel
    {
        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Subject is required")]
        [StringLength(200, ErrorMessage = "Subject cannot exceed 200 characters")]
        public string Subject { get; set; } = string.Empty;

        [Required(ErrorMessage = "Message is required")]
        [StringLength(1000, ErrorMessage = "Message cannot exceed 1000 characters")]
        public string Message { get; set; } = string.Empty;

        [Display(Name = "Phone Number")]
        public string? PhoneNumber { get; set; }
    }

    // Amenity ViewModel
    public class AmenityViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string IconClass { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
    }
}