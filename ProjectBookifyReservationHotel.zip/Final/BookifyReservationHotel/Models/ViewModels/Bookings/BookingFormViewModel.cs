﻿using System.ComponentModel.DataAnnotations;

namespace BookifyReservationHotel.Models.ViewModels.Bookings
{
    public class BookingFormViewModel
    {
        public string? ImageUrl { get; set; }

        public int Id { get; set; }

        [Required(ErrorMessage = "Room type is required")]
        public int RoomTypeId { get; set; }

        [Required(ErrorMessage = "Check-in date is required")]
        [Display(Name = "Check-in Date")]
        [DataType(DataType.Date)]
        public DateTime CheckInDate { get; set; }

        [Required(ErrorMessage = "Check-out date is required")]
        [Display(Name = "Check-out Date")]
        [DataType(DataType.Date)]
        public DateTime CheckOutDate { get; set; }

        [Required(ErrorMessage = "Number of guests is required")]
        [Display(Name = "Number of Guests")]
        [Range(1, 10, ErrorMessage = "Number of guests must be between 1 and 10")]
        public int NumberOfGuests { get; set; }

        [Display(Name = "Special Requests")]
        [StringLength(500, ErrorMessage = "Special requests cannot exceed 500 characters")]
        public string? SpecialRequests { get; set; }

        // Financial properties
        [Display(Name = "Sub Total")]
        [DataType(DataType.Currency)]
        public decimal SubTotal { get; set; }

        [Display(Name = "Service Fee")]
        [DataType(DataType.Currency)]
        public decimal ServiceFee { get; set; }

        [Display(Name = "Taxes")]
        [DataType(DataType.Currency)]
        public decimal Taxes { get; set; }

        // This is the property your view expects
        [Display(Name = "Total Amount")]
        [DataType(DataType.Currency)]
        public decimal TotalAmount => SubTotal + ServiceFee + Taxes;

        // Alias for TotalAmount for backward compatibility
        [Display(Name = "Grand Total")]
        [DataType(DataType.Currency)]
        public decimal GrandTotal => TotalAmount;

        public int TotalNights { get; set; }

        [Display(Name = "Price Per Night")]
        [DataType(DataType.Currency)]
        public decimal PricePerNight { get; set; }

        // Room type display properties
        public string RoomTypeName { get; set; } = string.Empty;
        public string RoomTypeDescription { get; set; } = string.Empty;
        public int RoomTypeCapacity { get; set; }

        public List<string> RoomTypeAmenities { get; set; } = new List<string>();
        public List<string> RoomTypeImages { get; set; } = new List<string>();
    }
}