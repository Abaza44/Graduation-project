﻿using System.ComponentModel.DataAnnotations;

namespace BookifyReservationHotel.Models.ViewModels.Bookings
{
    public class BookingDetailsViewModel
    {
        public int Id { get; set; }

        [Display(Name = "Confirmation Code")]
        public string ConfirmationCode { get; set; } = string.Empty;

        [Display(Name = "Booking Date")]
        public DateTime BookingDate { get; set; }

        [Display(Name = "Status")]
        public string BookingStatus { get; set; } = string.Empty;

        // Guest Information
        [Display(Name = "Guest Name")]
        public string GuestName { get; set; } = string.Empty;

        [Display(Name = "Guest Email")]
        public string GuestEmail { get; set; } = string.Empty;

        [Display(Name = "Guest Phone")]
        public string GuestPhone { get; set; } = string.Empty;

        // Room Information
        [Display(Name = "Room Type")]
        public string RoomTypeName { get; set; } = string.Empty;

        [Display(Name = "Room Number")]
        public string RoomNumber { get; set; } = string.Empty;

        [Display(Name = "Room Description")]
        public string RoomDescription { get; set; } = string.Empty;

        // Dates
        [Display(Name = "Check-in Date")]
        public DateTime CheckInDate { get; set; }

        [Display(Name = "Check-out Date")]
        public DateTime CheckOutDate { get; set; }

        [Display(Name = "Total Nights")]
        public int TotalNights { get; set; }

        [Display(Name = "Number of Guests")]
        public int NumberOfGuests { get; set; }

        // Pricing
        [Display(Name = "Price Per Night")]
        public decimal PricePerNight { get; set; }

        [Display(Name = "Room Total")]
        public decimal RoomTotal { get; set; }

        [Display(Name = "Tax Amount")]
        public decimal TaxAmount { get; set; }

        [Display(Name = "Total Amount")]
        public decimal TotalAmount { get; set; }

        [Display(Name = "Payment Method")]
        public string PaymentMethod { get; set; } = string.Empty;

        [Display(Name = "Payment Status")]
        public string PaymentStatus { get; set; } = string.Empty;

        // Additional Information
        [Display(Name = "Special Requests")]
        public string? SpecialRequests { get; set; }

        [Display(Name = "Cancellation Reason")]
        public string? CancellationReason { get; set; }

        [Display(Name = "Cancellation Date")]
        public DateTime? CancellationDate { get; set; }

        // Actions
        public bool CanCancel { get; set; }
        public bool CanModify { get; set; }
        public bool CanCheckIn { get; set; }
        public bool CanCheckOut { get; set; }
    }
}