﻿using BookifyReservationHotel.Models.ViewModels.Admin;
using BookifyReservationHotel.Models.ViewModels.Shared;
using System.ComponentModel.DataAnnotations;

namespace BookifyReservationHotel.Models.ViewModels.Bookings
{
    public class BookingSearchViewModel
    {
        [Display(Name = "Confirmation Code")]
        public string? ConfirmationCode { get; set; }

        [Display(Name = "Guest Name")]
        public string? GuestName { get; set; }

        [Display(Name = "Guest Email")]
        public string? GuestEmail { get; set; }

        [Display(Name = "Room Type")]
        public int? RoomTypeId { get; set; }

        [Display(Name = "Status")]
        public string? Status { get; set; }

        [Display(Name = "Check-in From")]
        [DataType(DataType.Date)]
        public DateTime? CheckInFrom { get; set; }

        [Display(Name = "Check-in To")]
        [DataType(DataType.Date)]
        public DateTime? CheckInTo { get; set; }

        [Display(Name = "Booking Date From")]
        [DataType(DataType.Date)]
        public DateTime? BookingDateFrom { get; set; }

        [Display(Name = "Booking Date To")]
        [DataType(DataType.Date)]
        public DateTime? BookingDateTo { get; set; }

        // Results
        public List<BookingManagementViewModel> Results { get; set; } = new();

        // Dropdown options
        public List<RoomTypeDropdownViewModel> RoomTypes { get; set; } = new();
        public List<string> StatusOptions { get; set; } = new();
    }
}