﻿using Bookify.Core.DTOs;
using Bookify.Core.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookifyReservationHotel.Controllers
{
    public class ReviewsController : Controller
    {
        private readonly IReviewService _reviewService;
        private readonly IRoomTypeService _roomTypeService;
        private readonly ILogger<ReviewsController> _logger;

        public ReviewsController(
            IReviewService reviewService,
            IRoomTypeService roomTypeService,
            ILogger<ReviewsController> logger)
        {
            _reviewService = reviewService;
            _roomTypeService = roomTypeService;
            _logger = logger;
        }

        // ---------------------- INDEX ----------------------
        public async Task<IActionResult> Index(int roomTypeId)
        {
            try
            {
                var reviews = await _reviewService.GetReviewsByRoomTypeAsync(roomTypeId);
                var roomType = await _roomTypeService.GetRoomTypeByIdAsync(roomTypeId);

                ViewBag.RoomTypeName = roomType?.Name ?? "Room";
                ViewBag.RoomTypeId = roomTypeId;

                return View(reviews);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving reviews for room type {roomTypeId}");
                TempData["Error"] = "An error occurred while retrieving reviews.";
                return View(new List<ReviewDto>());
            }
        }

        // ---------------------- CREATE (GET) ----------------------
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Create(int roomTypeId)
        {
            try
            {
                var roomType = await _roomTypeService.GetRoomTypeByIdAsync(roomTypeId);
                if (roomType == null)
                {
                    TempData["Error"] = "Room type not found.";
                    return RedirectToAction("Index", "Rooms");
                }

                ViewBag.RoomTypeName = roomType.Name;
                ViewBag.RoomTypeId = roomTypeId;

                return View();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error preparing review form for room type {roomTypeId}");
                TempData["Error"] = "An error occurred while preparing the review form.";
                return RedirectToAction("Details", "Rooms", new { id = roomTypeId });
            }
        }

        // ---------------------- CREATE (POST) ----------------------
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(int roomTypeId, CreateReviewDto model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var roomType = await _roomTypeService.GetRoomTypeByIdAsync(roomTypeId);
                    ViewBag.RoomTypeName = roomType?.Name ?? "Room";
                    ViewBag.RoomTypeId = roomTypeId;
                    return View(model);
                }

                model.UserId = User.Identity?.Name ?? "default-user"; // Replace with actual user ID from claims
                model.RoomTypeId = roomTypeId;

                var review = await _reviewService.CreateReviewAsync(model);

                if (review != null)
                {
                    TempData["Success"] = "Review added successfully!";
                    return RedirectToAction(nameof(Index), new { roomTypeId });
                }

                TempData["Error"] = "Failed to add the review. Please try again.";
                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error creating review for room type {roomTypeId}");
                TempData["Error"] = "An error occurred while creating the review.";
                return View(model);
            }
        }

        // ---------------------- DELETE ----------------------
        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, int roomTypeId)
        {
            try
            {
                var deleted = await _reviewService.DeleteReviewAsync(id);

                if (deleted)
                {
                    TempData["Success"] = "Review deleted successfully.";
                }
                else
                {
                    TempData["Error"] = "Failed to delete the review.";
                }

                return RedirectToAction(nameof(Index), new { roomTypeId });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting review {id}");
                TempData["Error"] = "An error occurred while deleting the review.";
                return RedirectToAction(nameof(Index), new { roomTypeId });
            }
        }
    }
}
