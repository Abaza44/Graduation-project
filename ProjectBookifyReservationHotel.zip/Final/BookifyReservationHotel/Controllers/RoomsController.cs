﻿using BookifyReservationHotel.Models.ViewModels.Rooms;
using BookifyReservationHotel.Models.ViewModels.Shared;
using Bookify.Core.Interfaces.Services;
using Microsoft.AspNetCore.Mvc;

namespace BookifyReservationHotel.Controllers
{
    public class RoomsController : Controller
    {
        private readonly IRoomTypeService _roomTypeService;

        public RoomsController(IRoomTypeService roomTypeService)
        {
            _roomTypeService = roomTypeService;
        }

        // GET: /Rooms/
        public async Task<IActionResult> Index()
        {
            var roomTypes = await _roomTypeService.GetAllRoomTypesAsync();

            var model = new RoomSearchViewModel
            {
                Results = roomTypes.Select(r => new RoomSearchResultViewModel
                {
                    Id = r.Id,
                    Name = r.Name,
                    Description = r.Description,
                    PricePerNight = r.PricePerNight,
                    Capacity = r.Capacity,
                    ImageUrls = r.ImageUrls ?? new List<string>()
                }).ToList()
            };

            return View(model);
        }

        // GET: /Rooms/Details/1
        public async Task<IActionResult> Details(int id)
        {
            var roomType = await _roomTypeService.GetRoomTypeByIdAsync(id);
            if (roomType == null)
                return NotFound();

            var room = new RoomDetailsViewModel
            {
                Id = roomType.Id,
                Name = roomType.Name,
                Description = roomType.Description,
                PricePerNight = roomType.PricePerNight,
                Capacity = roomType.Capacity,
                SizeInSqFt = roomType.SizeInSqFt,
                AvailableRoomsCount = roomType.AvailableRooms,
                ImageUrls = roomType.ImageUrls ?? new List<string>(),
                AverageRating = roomType.AverageRating,
                TotalReviews = roomType.TotalReviews
            };

            return View(room);
        }

        // GET: /Rooms/Search
        [HttpGet]
        public async Task<IActionResult> Search(RoomSearchViewModel model)
        {
            if (!ModelState.IsValid)
                return View("Index", model);

            if (model.CheckInDate < DateTime.Today)
            {
                ModelState.AddModelError("CheckInDate", "Check-in date cannot be in the past.");
                return View("Index", model);
            }

            if (model.CheckOutDate <= model.CheckInDate)
            {
                ModelState.AddModelError("CheckOutDate", "Check-out date must be after check-in date.");
                return View("Index", model);
            }
            var roomTypes = await _roomTypeService.GetAllRoomTypesAsync();

            if (!string.IsNullOrWhiteSpace(model.RoomName))
            {
                roomTypes = roomTypes.Where(r => r.Name.Contains(model.RoomName, StringComparison.OrdinalIgnoreCase)).ToList();
            }


            var results = roomTypes.Select(r => new RoomSearchResultViewModel
            {
                Id = r.Id,
                Name = r.Name,
                Description = r.Description,
                PricePerNight = r.PricePerNight,
                Capacity = r.Capacity,
                SizeInSqFt = r.SizeInSqFt,
                AvailableRoomsCount = r.AvailableRooms,
                ImageUrls = r.ImageUrls ?? new List<string>(),
                AverageRating = r.AverageRating,
                TotalReviews = r.TotalReviews,
                CheckInDate = model.CheckInDate,
                CheckOutDate = model.CheckOutDate,
                NumberOfGuests = model.Guests,
                TotalNights = (int)(model.CheckOutDate - model.CheckInDate).TotalDays,
                TotalPrice = r.PricePerNight * (int)(model.CheckOutDate - model.CheckInDate).TotalDays
            }).ToList();

            // Apply filters
            if (model.MinPrice.HasValue)
                results = results.Where(r => r.PricePerNight >= model.MinPrice.Value).ToList();

            if (model.MaxPrice.HasValue)
                results = results.Where(r => r.PricePerNight <= model.MaxPrice.Value).ToList();

            results = results.Where(r => r.Capacity >= model.Guests).ToList();

            model.Results = results;
            return View("Index", model);
        }
    }
}
