﻿using Bookify.Core.DTOs;
using Bookify.Core.Interfaces.Services;
using Bookify.Infrastructure.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;


namespace BookifyReservationHotel.Controllers
{
    [Authorize]
    public class PaymentController : Controller
    {
        private readonly IPaymentService _paymentService;
        private readonly IBookingService _bookingService;
        private readonly ILogger<PaymentController> _logger;
        private readonly IRoomTypeService _roomTypeService;


        public PaymentController(
            IPaymentService paymentService,
            IBookingService bookingService,
            ILogger<PaymentController> logger)
        {
            _paymentService = paymentService;
            _bookingService = bookingService;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> Create(int bookingId)
        {
            try
            {
                var booking = await _bookingService.GetBookingByIdAsync(bookingId);
                if (booking == null)
                {
                    TempData["Error"] = "Booking not found.";
                    return RedirectToAction("Index", "Bookings");
                }
                var roomType = await _roomTypeService.GetRoomTypeByIdAsync(booking.RoomTypeId);
                decimal pricePerNight = roomType.PricePerNight;


                var model = new CreatePaymentDto
                {
                    BookingId = bookingId,
                    Amount = booking.TotalAmount,
                    Description = $"Payment for booking {booking.ConfirmationCode}"
                };

                ViewBag.Booking = booking;
                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error preparing payment for booking {bookingId}");
                TempData["Error"] = "An error occurred while preparing the payment.";
                return RedirectToAction("Index", "Bookings");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreatePaymentDto model)
        {
            if (!ModelState.IsValid)
            {
                try
                {
                    var booking = await _bookingService.GetBookingByIdAsync(model.BookingId);
                    ViewBag.Booking = booking;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error repopulating booking data");
                }
                return View(model);
            }

            try
            {

                var isValid = await _paymentService.ValidatePaymentAsync(model);
                if (!isValid)
                {
                    ModelState.AddModelError("", "Invalid payment information.");
                    var booking = await _bookingService.GetBookingByIdAsync(model.BookingId);
                    ViewBag.Booking = booking;
                    return View(model);
                }

                var simulationResult = await _paymentService.SimulatePaymentAsync(model);

                if (simulationResult.Success)
                {
                    var payment = await _paymentService.CreatePaymentAsync(model);

                    var processDto = new ProcessPaymentDto
                    {
                        PaymentId = payment.Id,
                        TransactionId = simulationResult.TransactionId,
                        PaymentStatus = "Completed",
                        PaymentResponse = simulationResult.GatewayResponse
                    };

                    var processedPayment = await _paymentService.ProcessPaymentAsync(processDto);

                    TempData["Success"] = $"Payment processed successfully! Transaction ID: {simulationResult.TransactionId}";
                    return RedirectToAction("Details", "Bookings", new { id = model.BookingId });
                }
                else
                {
                    ModelState.AddModelError("", $"Payment failed: {simulationResult.Message}");
                    var booking = await _bookingService.GetBookingByIdAsync(model.BookingId);
                    ViewBag.Booking = booking;
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing payment");
                ModelState.AddModelError("", "An error occurred while processing your payment. Please try again.");

                try
                {
                    var booking = await _bookingService.GetBookingByIdAsync(model.BookingId);
                    ViewBag.Booking = booking;
                }
                catch (Exception innerEx)
                {
                    _logger.LogError(innerEx, "Error repopulating booking data");
                }

                return View(model);
            }
        }

        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var payment = await _paymentService.GetPaymentByIdAsync(id);


                return View(payment);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving payment {id}");
                TempData["Error"] = "Payment not found.";
                return RedirectToAction("Index", "Bookings");
            }
        }

        [HttpPost]
        public async Task<JsonResult> ValidateCard([FromBody] CreatePaymentDto model)
        {
            try
            {
                var isValid = await _paymentService.ValidatePaymentAsync(model);
                return Json(new { valid = isValid });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating card");
                return Json(new { valid = false, error = "Error validating card information" });
            }
        }
    }
}