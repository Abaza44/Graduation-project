﻿using Bookify.Core.DTOs;
using Bookify.Core.Entities;
using Bookify.Core.Interfaces.Services;
using BookifyReservationHotel.Models.ViewModels.Bookings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Stripe;
using Stripe.Checkout;

namespace BookifyReservationHotel.Controllers
{
    [Authorize]
    public class BookingsController : Controller
    {
        private readonly IBookingService _bookingService;
        private readonly IRoomTypeService _roomTypeService;
        private readonly IConfiguration _configuration;
        private readonly ILogger<BookingsController> _logger;
        private readonly UserManager<ApplicationUser> _userManager;

        public BookingsController(
            IBookingService bookingService,
            IRoomTypeService roomTypeService,
            IConfiguration configuration,
            ILogger<BookingsController> logger,
            UserManager<ApplicationUser> userManager)
        {
            _bookingService = bookingService;
            _roomTypeService = roomTypeService;
            _logger = logger;
            _configuration = configuration;
            _userManager = userManager;
        }

        // ✅ عرض كل الحجوزات
        public async Task<IActionResult> Index()
        {
            try
            {
                var userId = _userManager.GetUserId(User); // ده الصحيح

                if (string.IsNullOrEmpty(userId))
                {
                    TempData["Error"] = "User not authenticated.";
                    return View(new List<BookingDto>());
                }

                var bookings = await _bookingService.GetBookingsByUserAsync(userId);
                return View(bookings);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving bookings");
                TempData["Error"] = "An error occurred while retrieving your bookings.";
                return View(new List<BookingDto>());
            }
        }

        // ✅ GET: Create Booking
        [HttpGet]
        public async Task<IActionResult> Create(int roomTypeId, DateTime? checkIn, DateTime? checkOut, int guests = 1)
        {
            try
            {
                // ✅ تحديد التواريخ الافتراضية
                DateTime validCheckIn = checkIn ?? DateTime.Today.AddDays(1);
                DateTime validCheckOut = checkOut ?? validCheckIn.AddDays(1);
                if (validCheckOut <= validCheckIn)
                    validCheckOut = validCheckIn.AddDays(1);

                int totalNights = (int)(validCheckOut - validCheckIn).TotalDays;
                if (totalNights <= 0) totalNights = 1;

                // ✅ الحصول على بيانات الغرفة
                var roomType = await _roomTypeService.GetRoomTypeByIdAsync(roomTypeId);
                if (roomType == null)
                {
                    TempData["Error"] = "Couldn't load room details. Please try again later.";
                    return RedirectToAction("Index", "Rooms");
                }

                // DEBUG log
                _logger.LogInformation("Create GET: RoomTypeId={Id}, Name={Name}, PricePerNight={Price}",
                    roomTypeId, roomType.Name, roomType.PricePerNight);

                // ✅ التأكد من التوفر
                var isAvailable = await _bookingService.IsRoomAvailableAsync(roomTypeId, validCheckIn, validCheckOut);
                if (!isAvailable)
                {
                    TempData["Error"] = "This room is not available for the selected dates.";
                    return RedirectToAction("Index", "Rooms");
                }

                // ✅ السعر الأساسي
                decimal basePrice = roomType.PricePerNight;

                // ✅ حساب زيادة السعر بعدد الضيوف
                decimal guestExtraPerNight = (guests > 1) ? (guests - 1) * (basePrice * 0.25m) : 0m;
                decimal pricePerNightWithGuests = basePrice + guestExtraPerNight;

                // ✅ الحساب النهائي
                decimal subTotal = pricePerNightWithGuests * totalNights;
                decimal serviceFee = Math.Round(subTotal * 0.05m, 2);
                decimal taxes = Math.Round(subTotal * 0.10m, 2);

                var model = new BookingFormViewModel
                {
                    RoomTypeId = roomTypeId,
                    RoomTypeName = roomType.Name,
                    RoomTypeDescription = roomType.Description,
                    RoomTypeCapacity = roomType.Capacity,
                    RoomTypeImages = roomType.ImageUrls ?? new List<string>(),

                    CheckInDate = validCheckIn,
                    CheckOutDate = validCheckOut,
                    NumberOfGuests = guests,
                    TotalNights = totalNights,

                    PricePerNight = basePrice,
                    SubTotal = subTotal,
                    ServiceFee = serviceFee,
                    Taxes = taxes
                };

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error while preparing booking form");
                TempData["Error"] = "An error occurred while preparing your booking form.";
                return RedirectToAction("Index", "Rooms");
            }
        }

        // 🧩 دالة مؤقتة لتحميل بيانات الغرف
        private async Task<RoomTypeDto?> SafeGetRoomTypeAsync(int id)
        {
            try
            {
                return await _roomTypeService.GetRoomTypeByIdAsync(id);
            }
            catch
            {
                var mockRooms = new List<RoomTypeDto>
                {
                    new() { Id = 1, Name = "Standard Room", Description = "Comfortable and affordable room.", PricePerNight = 99, Capacity = 2 },
                    new() { Id = 2, Name = "Deluxe Room", Description = "Spacious deluxe room with premium amenities.", PricePerNight = 159, Capacity = 3 },
                    new() { Id = 3, Name = "Executive Suite", Description = "Luxurious suite with living area and ocean view.", PricePerNight = 299, Capacity = 4 }
                };

                return await Task.FromResult(mockRooms.FirstOrDefault(r => r.Id == id));
            }
        }

        // ✅ POST: Confirm Booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(BookingFormViewModel model)
        {
            _logger.LogInformation("=== Booking Creation Started ===");

            try
            {
                ModelState.Clear();

                // التحقق من التواريخ
                if (model.CheckOutDate <= model.CheckInDate)
                {
                    TempData["Error"] = "Invalid date range.";
                    return RedirectToAction("Index", "Rooms");
                }

                // جلب بيانات الغرفة
                var roomType = await _roomTypeService.GetRoomTypeByIdAsync(model.RoomTypeId);
                if (roomType == null)
                {
                    TempData["Error"] = "Room not found.";
                    return RedirectToAction("Index", "Rooms");
                }

                // حساب السعر
                var totalNights = Math.Max(1, (int)(model.CheckOutDate - model.CheckInDate).TotalDays);
                decimal basePrice = roomType.PricePerNight;
                decimal guestExtraPerNight = (model.NumberOfGuests > 1)
                    ? (model.NumberOfGuests - 1) * (basePrice * 0.25m)
                    : 0m;

                decimal pricePerNightWithGuests = basePrice + guestExtraPerNight;
                decimal subTotal = pricePerNightWithGuests * totalNights;
                decimal serviceFee = Math.Round(subTotal * 0.05m, 2);
                decimal taxes = Math.Round(subTotal * 0.10m, 2);
                decimal totalAmount = subTotal + serviceFee + taxes;

                // إنشاء الحجز
                var userId = _userManager.GetUserId(User);

                var createDto = new CreateBookingDto
                {
                    UserId = userId ?? "guest-user",
                    RoomTypeId = model.RoomTypeId,
                    CheckInDate = model.CheckInDate,
                    CheckOutDate = model.CheckOutDate,
                    NumberOfGuests = model.NumberOfGuests,
                    SpecialRequests = model.SpecialRequests ?? string.Empty,
                    TotalAmount = totalAmount
                };

                var booking = await _bookingService.CreateBookingAsync(createDto);

                if (booking == null)
                {
                    TempData["Error"] = "Failed to create booking.";
                    return RedirectToAction("Index", "Rooms");
                }

                _logger.LogInformation("✅ Booking created with ID: {BookingId}", booking.Id);

                TempData["Success"] = "Booking created! Please complete your payment.";
                return RedirectToAction(nameof(Payment), new { id = booking.Id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating booking");
                TempData["Error"] = $"Error: {ex.Message}";
                return RedirectToAction("Index", "Rooms");
            }
        }

        // ✅ تفاصيل الحجز
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var booking = await _bookingService.GetBookingByIdAsync(id);
                if (booking == null)
                {
                    _logger.LogWarning("Booking not found: {BookingId}", id);
                    return NotFound();
                }

                // جلب بيانات الغرفة
                var roomType = await _roomTypeService.GetRoomTypeByIdAsync(booking.RoomTypeId);

                // حساب الأسعار بنفس منطق Create
                int totalNights = booking.TotalNights > 0 ? booking.TotalNights : 1;
                decimal basePrice = roomType?.PricePerNight ?? 0;

                decimal guestExtraPerNight = (booking.NumberOfGuests > 1)
                    ? (booking.NumberOfGuests - 1) * (basePrice * 0.25m)
                    : 0m;

                decimal pricePerNightWithGuests = basePrice + guestExtraPerNight;
                decimal subTotal = pricePerNightWithGuests * totalNights;
                decimal serviceFee = Math.Round(subTotal * 0.05m, 2);
                decimal taxes = Math.Round(subTotal * 0.10m, 2);

                var viewModel = new BookingFormViewModel
                {
                    Id = booking.Id,
                    RoomTypeId = booking.RoomTypeId,
                    RoomTypeName = booking.RoomTypeName,
                    RoomTypeDescription = roomType?.Description ?? "",
                    RoomTypeCapacity = roomType?.Capacity ?? 0,
                    CheckInDate = booking.CheckInDate,
                    CheckOutDate = booking.CheckOutDate,
                    NumberOfGuests = booking.NumberOfGuests,
                    SpecialRequests = booking.SpecialRequests,
                    TotalNights = totalNights,
                    PricePerNight = basePrice,
                    SubTotal = subTotal,
                    ServiceFee = serviceFee,
                    Taxes = taxes
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving booking {BookingId}", id);
                TempData["Error"] = "Couldn't load booking details.";
                return RedirectToAction(nameof(Index));
            }
        }

        // ✅ صفحة الدفع - GET (معدّلة لتشمل Stripe)
        [HttpGet]
        public async Task<IActionResult> Payment(int id)
        {
            _logger.LogInformation("Loading Payment page for booking: {BookingId}", id);

            try
            {
                var booking = await _bookingService.GetBookingByIdAsync(id);

                if (booking == null)
                {
                    _logger.LogWarning("Booking not found: {BookingId}", id);
                    TempData["Error"] = "Booking not found.";
                    return RedirectToAction(nameof(Index));
                }

                // ✅ تمرير PayPal و Stripe Keys
                ViewBag.PayPalClientId = _configuration["PayPal:ClientId"] ?? "";
                ViewBag.StripePublishableKey = _configuration["Stripe:PublishableKey"] ?? "";

                _logger.LogInformation("Payment page loaded for booking: {BookingId}", id);

                return View(booking);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading payment page");
                TempData["Error"] = "Couldn't load payment page.";
                return RedirectToAction(nameof(Index));
            }
        }

        // ✅ NEW: Create Stripe Checkout Session
        [HttpPost]
        public async Task<IActionResult> CreateStripeCheckout(int bookingId)
        {
            try
            {
                var booking = await _bookingService.GetBookingByIdAsync(bookingId);
                if (booking == null)
                {
                    return Json(new { success = false, error = "Booking not found" });
                }

                // Configure Stripe
                StripeConfiguration.ApiKey = _configuration["Stripe:SecretKey"];

                var options = new SessionCreateOptions
                {
                    PaymentMethodTypes = new List<string> { "card" },
                    LineItems = new List<SessionLineItemOptions>
                    {
                        new SessionLineItemOptions
                        {
                            PriceData = new SessionLineItemPriceDataOptions
                            {
                                Currency = "usd",
                                ProductData = new SessionLineItemPriceDataProductDataOptions
                                {
                                    Name = $"Hotel Booking: {booking.RoomTypeName}",
                                    Description = $"Check-in: {booking.CheckInDate:MMM dd, yyyy} | Check-out: {booking.CheckOutDate:MMM dd, yyyy} | Guests: {booking.NumberOfGuests}",
                                    Images = new List<string>
                                    {
                                        "https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=300"
                                    }
                                },
                                UnitAmount = (long)(booking.TotalAmount * 100), // Convert to cents
                            },
                            Quantity = 1,
                        }
                    },
                    Mode = "payment",
                    SuccessUrl = $"{Request.Scheme}://{Request.Host}/Bookings/StripeSuccess?session_id={{CHECKOUT_SESSION_ID}}&booking_id={bookingId}",
                    CancelUrl = $"{Request.Scheme}://{Request.Host}/Bookings/Payment/{bookingId}?cancelled=true",
                    Metadata = new Dictionary<string, string>
                    {
                        { "booking_id", bookingId.ToString() },
                        { "room_type", booking.RoomTypeName }
                    }
                };

                var service = new SessionService();
                var session = await service.CreateAsync(options);

                _logger.LogInformation("Stripe checkout session created: {SessionId}", session.Id);

                return Json(new
                {
                    success = true,
                    sessionId = session.Id,
                    url = session.Url
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating Stripe checkout session");
                return Json(new { success = false, error = ex.Message });
            }
        }

        // ✅ NEW: Stripe Success Callback
        [HttpGet]
        public async Task<IActionResult> StripeSuccess(string session_id, int booking_id)
        {
            _logger.LogInformation("Stripe payment success - Session: {SessionId}, Booking: {BookingId}",
                session_id, booking_id);

            try
            {
                // Verify the session with Stripe
                StripeConfiguration.ApiKey = _configuration["Stripe:SecretKey"];

                var service = new SessionService();
                var session = await service.GetAsync(session_id);

                if (session.PaymentStatus != "paid")
                {
                    TempData["Error"] = "Payment was not completed.";
                    return RedirectToAction(nameof(Payment), new { id = booking_id });
                }

                // Get booking
                var booking = await _bookingService.GetBookingByIdAsync(booking_id);
                if (booking == null)
                {
                    TempData["Error"] = "Booking not found.";
                    return RedirectToAction(nameof(Index));
                }

                // Confirm booking
                await _bookingService.ConfirmBookingAsync(booking_id);

                TempData["Success"] = "💳 Payment successful via Stripe!";
                TempData["TransactionId"] = session.PaymentIntentId;
                TempData["PaymentMethod"] = "Credit Card (Stripe)";

                _logger.LogInformation("✅ Stripe payment confirmed: {PaymentIntentId}", session.PaymentIntentId);

                return RedirectToAction(nameof(Confirmation), new { id = booking_id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing Stripe success callback");
                TempData["Error"] = "Payment verification failed.";
                return RedirectToAction(nameof(Payment), new { id = booking_id });
            }
        }

        // ✅ NEW: PayPal Success Callback (Optional)
        [HttpGet]
        public async Task<IActionResult> PayPalSuccess(string orderId, int bookingId)
        {
            _logger.LogInformation("PayPal payment success - Order: {OrderId}, Booking: {BookingId}",
                orderId, bookingId);

            try
            {
                var booking = await _bookingService.GetBookingByIdAsync(bookingId);
                if (booking == null)
                {
                    TempData["Error"] = "Booking not found.";
                    return RedirectToAction(nameof(Index));
                }

                // Confirm booking
                await _bookingService.ConfirmBookingAsync(bookingId);

                TempData["Success"] = "💰 Payment successful via PayPal!";
                TempData["TransactionId"] = orderId;
                TempData["PaymentMethod"] = "PayPal";

                _logger.LogInformation("✅ PayPal payment confirmed: {OrderId}", orderId);

                return RedirectToAction(nameof(Confirmation), new { id = bookingId });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing PayPal success callback");
                TempData["Error"] = "Payment processing failed.";
                return RedirectToAction(nameof(Payment), new { id = bookingId });
            }
        }

        // ✅ تأكيد الدفع - POST (محدّثة لتشمل Stripe)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PaymentConfirmed(int id, PaymentConfirmationDto paymentDto)
        {
            try
            {
                _logger.LogInformation("Processing payment for booking: {BookingId}", id);
                _logger.LogInformation("Payment Method: {Method}", paymentDto.PaymentMethod);

                var booking = await _bookingService.GetBookingByIdAsync(id);
                if (booking == null)
                {
                    TempData["Error"] = "Booking not found.";
                    return RedirectToAction(nameof(Index));
                }

                string transactionId = "";

                switch (paymentDto.PaymentMethod)
                {
                    case "Stripe":
                        if (string.IsNullOrEmpty(paymentDto.StripePaymentIntentId))
                        {
                            TempData["Error"] = "Stripe payment was not completed.";
                            return RedirectToAction(nameof(Payment), new { id });
                        }
                        transactionId = paymentDto.StripePaymentIntentId;
                        _logger.LogInformation("Stripe Payment Intent: {Id}", transactionId);
                        break;

                    case "PayPal":
                        if (string.IsNullOrEmpty(paymentDto.PayPalOrderId))
                        {
                            TempData["Error"] = "PayPal payment was not completed.";
                            return RedirectToAction(nameof(Payment), new { id });
                        }
                        transactionId = paymentDto.PayPalOrderId;
                        _logger.LogInformation("PayPal Order ID: {OrderId}", transactionId);
                        break;

                    case "CreditCard":
                        transactionId = $"CC_{Guid.NewGuid():N}"[..20];
                        _logger.LogInformation("Credit Card Transaction: {TransactionId}", transactionId);
                        break;

                    case "Wallet":
                        transactionId = $"WL_{Guid.NewGuid():N}"[..20];
                        _logger.LogInformation("Wallet Transaction: {TransactionId}", transactionId);
                        break;

                    default:
                        TempData["Error"] = "Invalid payment method.";
                        return RedirectToAction(nameof(Payment), new { id });
                }

                // ✅ تأكيد الحجز
                await _bookingService.ConfirmBookingAsync(id);

                _logger.LogInformation("✅ Payment successful! Transaction: {TransactionId}", transactionId);

                TempData["Success"] = $"Payment successful! Transaction ID: {transactionId}";
                TempData["TransactionId"] = transactionId;
                TempData["PaymentMethod"] = paymentDto.PaymentMethod;

                return RedirectToAction(nameof(Confirmation), new { id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing payment");
                TempData["Error"] = "Payment failed. Please try again.";
                return RedirectToAction(nameof(Payment), new { id });
            }
        }

        // ✅ صفحة التأكيد
        [HttpGet]
        public async Task<IActionResult> Confirmation(int id)
        {
            try
            {
                var booking = await _bookingService.GetBookingByIdAsync(id);
                if (booking == null)
                {
                    TempData["Error"] = "Booking not found.";
                    return RedirectToAction(nameof(Index));
                }

                ViewBag.TransactionId = TempData["TransactionId"];
                ViewBag.PaymentMethod = TempData["PaymentMethod"];

                return View(booking);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading confirmation page");
                return RedirectToAction(nameof(Index));
            }
        }

        // ✅ إلغاء الحجز
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cancel(int id, string reason)
        {
            try
            {
                var result = await _bookingService.CancelBookingAsync(id, reason);
                TempData[result ? "Success" : "Error"] = result
                    ? "Booking cancelled successfully."
                    : "Booking not found or cannot be cancelled.";

                return RedirectToAction(nameof(Details), new { id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error cancelling booking {BookingId}", id);
                TempData["Error"] = "An error occurred while cancelling the booking.";
                return RedirectToAction(nameof(Details), new { id });
            }
        }
    }
}