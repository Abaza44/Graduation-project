﻿using BookifyReservationHotel.Models.ViewModels.Rooms;
using BookifyReservationHotel.Models.ViewModels.Shared;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Bookify.Core.Interfaces.Services;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BookifyReservationHotel.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IRoomTypeService _roomTypeService;
        private readonly IAmenityService _amenityService;

        public HomeController(
            ILogger<HomeController> logger,
            IRoomTypeService roomTypeService,
            IAmenityService amenityService)
        {
            _logger = logger;
            _roomTypeService = roomTypeService;
            _amenityService = amenityService;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                // إنشاء النموذج أولاً بقيم افتراضية
                var model = new RoomSearchViewModel
                {
                    CheckInDate = DateTime.Today.AddDays(1),
                    CheckOutDate = DateTime.Today.AddDays(2),
                    Guests = 2,
                    RoomTypes = new List<SelectListItem>(),
                    AvailableAmenities = new List<AmenityViewModel>()
                };

                // محاولة جلب البيانات من الخدمات
                try
                {
                    // جلب أنواع الغرف
                    var roomTypes = await _roomTypeService.GetAllRoomTypesAsync();
                    if (roomTypes != null && roomTypes.Any())
                    {
                        model.RoomTypes = roomTypes.Select(rt => new SelectListItem
                        {
                            Value = rt.Id.ToString(),
                            Text = rt.Name
                        }).ToList();
                    }
                    else
                    {
                        model.RoomTypes = GetDefaultRoomTypes();
                    }

                    // جلب المرافق
                    var amenities = await _amenityService.GetAllAmenitiesAsync();
                    if (amenities != null && amenities.Any())
                    {
                        model.AvailableAmenities = amenities.Select(a => new AmenityViewModel
                        {
                            Id = a.Id,
                            Name = a.Name,
                            IconClass = a.IconClass,
                            Description = a.Description
                        }).ToList();
                    }
                    else
                    {
                        model.AvailableAmenities = GetDefaultAmenities();
                    }
                }
                catch (Exception serviceEx)
                {
                    _logger.LogWarning(serviceEx, "Services not available, using default data");
                    model.RoomTypes = GetDefaultRoomTypes();
                    model.AvailableAmenities = GetDefaultAmenities();
                }

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Critical error in Home/Index");

                // نموذج افتراضي آمن
                var safeModel = new RoomSearchViewModel
                {
                    CheckInDate = DateTime.Today.AddDays(1),
                    CheckOutDate = DateTime.Today.AddDays(2),
                    Guests = 2,
                    RoomTypes = GetDefaultRoomTypes(),
                    AvailableAmenities = GetDefaultAmenities()
                };

                return View(safeModel);
            }
        }

        // باقي الـ Actions بنفس النمط الآمن
        public IActionResult About()
        {
            var model = new AboutViewModel
            {
                Title = "About Bookify Hotel",
                Description = "Welcome to Bookify Hotel, where luxury meets comfort.",
                Features = new List<FeatureViewModel>
                {
                    new() { Title = "Luxury Accommodation", Description = "Spacious rooms", Icon = "fas fa-bed" },
                    new() { Title = "Fine Dining", Description = "Exquisite cuisine", Icon = "fas fa-utensils" }
                },
                Stats = new List<StatViewModel>
                {
                    new() { Number = "50+", Label = "Rooms & Suites" },
                    new() { Number = "20+", Label = "Years Experience" }
                }
            };

            return View(model);
        }

        public IActionResult Contact()
        {
            var model = new ContactViewModel();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Contact(ContactViewModel model)
        {
            if (ModelState.IsValid)
            {
                TempData["Success"] = "Thank you for your message! We'll get back to you soon.";
                return RedirectToAction(nameof(Contact));
            }
            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Services()
        {
            return View();
        }

        public IActionResult Gallery()
        {
            return View();
        }

        public IActionResult Testimonials()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        // Methods for default data
        private List<SelectListItem> GetDefaultRoomTypes()
        {
            return new List<SelectListItem>
            {
                new SelectListItem { Value = "1", Text = "Standard Room" },
                new SelectListItem { Value = "2", Text = "Deluxe Room" },
                new SelectListItem { Value = "3", Text = "Executive Suite" },
                new SelectListItem { Value = "4", Text = "Presidential Suite" }
            };
        }

        private List<AmenityViewModel> GetDefaultAmenities()
        {
            return new List<AmenityViewModel>
            {
                new() { Id = 1, Name = "Free WiFi", IconClass = "fas fa-wifi", Description = "High-speed internet" },
                new() { Id = 2, Name = "Air Conditioning", IconClass = "fas fa-snowflake", Description = "Climate control" },
                new() { Id = 3, Name = "TV", IconClass = "fas fa-tv", Description = "Cable channels" },
                new() { Id = 4, Name = "Swimming Pool", IconClass = "fas fa-swimming-pool", Description = "Pool access" }
            };
        }
    }
}