﻿using Bookify.Core.DTOs;
using Bookify.Core.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace BookifyReservationHotel.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class AmenitiesController : Controller
    {
        private readonly IAmenityService _amenityService;
        private readonly ILogger<AmenitiesController> _logger;

        public AmenitiesController(IAmenityService amenityService, ILogger<AmenitiesController> logger)
        {
            _amenityService = amenityService;
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            var amenities = await _amenityService.GetAllAmenitiesAsync();
            return View(amenities);
        }

        public async Task<IActionResult> Details(int id)
        {
            var amenity = await _amenityService.GetAmenityByIdAsync(id);
            if (amenity == null)
            {
                return NotFound();
            }
            return View(amenity);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateAmenityDto dto)
        {
            if (!ModelState.IsValid)
            {
                return View(dto);
            }

            try
            {
                var result = await _amenityService.CreateAmenityAsync(dto);
                TempData["Success"] = "Amenity created successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating amenity");
                ModelState.AddModelError("", ex.Message);
                return View(dto);
            }
        }

        public async Task<IActionResult> Edit(int id)
        {
            var amenity = await _amenityService.GetAmenityByIdAsync(id);
            if (amenity == null)
            {
                return NotFound();
            }

            var updateDto = new UpdateAmenityDto
            {
                Id = amenity.Id,
                Name = amenity.Name,
                Description = amenity.Description,
                IconClass = amenity.IconClass,
                IsActive = amenity.IsActive
            };

            return View(updateDto);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, UpdateAmenityDto dto)
        {
            if (id != dto.Id)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                return View(dto);
            }

            try
            {
                var result = await _amenityService.UpdateAmenityAsync(dto);
                TempData["Success"] = "Amenity updated successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating amenity with ID: {id}");
                ModelState.AddModelError("", ex.Message);
                return View(dto);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var result = await _amenityService.DeleteAmenityAsync(id);
                if (result)
                {
                    TempData["Success"] = "Amenity deleted successfully!";
                }
                else
                {
                    TempData["Error"] = "Amenity not found.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting amenity with ID: {id}");
                TempData["Error"] = ex.Message;
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> UsageStats()
        {
            var stats = await _amenityService.GetAmenityUsageStatsAsync();
            return View(stats);
        }
    }
}