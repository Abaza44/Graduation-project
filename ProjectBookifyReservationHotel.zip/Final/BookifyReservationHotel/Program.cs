﻿using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Core.Interfaces.Services;
using Bookify.Infrastructure.Data;
using Bookify.Infrastructure.Repositories;
using Bookify.Infrastructure.Services;
using Bookify.Infrastructure.UnitOfWork;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Bookify.Infrastructure.Mapping;

using Stripe;

var builder = WebApplication.CreateBuilder(args);

StripeConfiguration.ApiKey = builder.Configuration["Stripe:SecretKey"];
// Add services to the container.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// Database Configuration
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

// Identity Configuration
builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    // Password settings
    options.Password.RequireDigit = true;
    options.Password.RequireLowercase = true;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequireUppercase = true;
    options.Password.RequiredLength = 6;
    options.Password.RequiredUniqueChars = 1;

    // Lockout settings
    options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(30);
    options.Lockout.MaxFailedAccessAttempts = 5;
    options.Lockout.AllowedForNewUsers = true;

    // User settings
    options.User.AllowedUserNameCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._@+";
    options.User.RequireUniqueEmail = true;

    options.SignIn.RequireConfirmedEmail = false;
})
.AddEntityFrameworkStores<ApplicationDbContext>()
.AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.Cookie.HttpOnly = true;
    options.ExpireTimeSpan = TimeSpan.FromDays(30);
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
    options.SlidingExpiration = true;
});

builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

builder.Services.AddControllersWithViews();

builder.Services.AddRazorPages();

builder.Services.AddAutoMapper(typeof(Bookify.Infrastructure.Mapping.MappingProfile));

var stripeSecretKey = builder.Configuration.GetSection("Stripe")["SecretKey"];
if (!string.IsNullOrEmpty(stripeSecretKey))
{
    StripeConfiguration.ApiKey = stripeSecretKey;
}
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();

// Repository Services
builder.Services.AddScoped<IRoomTypeRepository, RoomTypeRepository>();
builder.Services.AddScoped<IRoomRepository, RoomRepository>();
builder.Services.AddScoped<IBookingRepository, BookingRepository>();
builder.Services.AddScoped<IPaymentRepository, PaymentRepository>();
builder.Services.AddScoped<IAmenityRepository, AmenityRepository>();
builder.Services.AddScoped<IReviewRepository, ReviewRepository>();
builder.Services.AddScoped<IImageRepository, ImageRepository>();

// Business Services
builder.Services.AddScoped<IRoomTypeService, RoomTypeService>();
builder.Services.AddScoped<IAmenityService, AmenityService>();
builder.Services.AddScoped<IBookingService, BookingService>();
builder.Services.AddScoped<IPaymentService, PaymentService>();
builder.Services.AddScoped<IReviewService, Bookify.Infrastructure.Services.ReviewService>();
builder.Services.AddScoped<IDashboardService, DashboardService>();

// Payment Gateway (Simulated for development)
builder.Services.AddScoped<IPaymentGateway, SimulatedPaymentGateway>();

// Email Service Configuration
builder.Services.AddScoped<IEmailService>(provider =>
{
    var config = provider.GetRequiredService<IConfiguration>();
    var smtpServer = config["EmailSettings:SmtpServer"] ?? "smtp.gmail.com";
    var smtpPort = int.Parse(config["EmailSettings:SmtpPort"] ?? "587");
    var fromEmail = config["EmailSettings:FromEmail"] ?? "noreply@bookify.com";
    var fromPassword = config["EmailSettings:FromPassword"] ?? "password";

    return new EmailService(smtpServer, smtpPort, fromEmail, fromPassword);
});

// HTTP Context Accessor
builder.Services.AddHttpContextAccessor();

// Logging Configuration
builder.Services.AddLogging(logging =>
{
    logging.ClearProviders();
    logging.AddConsole();
    logging.AddDebug();
    logging.AddConfiguration(builder.Configuration.GetSection("Logging"));
});

// Add Distributed Memory Cache for session and temp data
builder.Services.AddDistributedMemoryCache();

var app = builder.Build();

// ========== CONFIGURE HTTP REQUEST PIPELINE ==========

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseStatusCodePagesWithReExecute("/Home/Error/{0}");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.UseSession();

// ========== AREA ROUTES CONFIGURATION ==========

app.MapAreaControllerRoute(
    name: "Admin",
    areaName: "Admin",
    pattern: "Admin/{controller=Dashboard}/{action=Index}/{id?}");

// ========== REGULAR ROUTES CONFIGURATION ==========

app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapRazorPages();

// ========== DATABASE SEEDING ==========

await SeedDatabaseAsync(app);

app.Run();

// ========== DATABASE SEEDING METHOD ==========

async Task SeedDatabaseAsync(WebApplication app)
{
    using var scope = app.Services.CreateScope();
    var services = scope.ServiceProvider;

    try
    {
        var context = services.GetRequiredService<ApplicationDbContext>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();

        // Apply pending migrations
        await context.Database.MigrateAsync();

        // ========== SEED ROLES ==========
        var roles = new[] { "Admin", "Manager", "Customer" };
        foreach (var role in roles)
        {
            if (!await roleManager.RoleExistsAsync(role))
            {
                await roleManager.CreateAsync(new IdentityRole(role));
            }
        }

        // ========== SEED ADMIN USER ==========
        var adminEmail = "admin@bookify.com";
        var adminUser = await userManager.FindByEmailAsync(adminEmail);
        if (adminUser == null)
        {
            adminUser = new ApplicationUser
            {
                UserName = adminEmail,
                Email = adminEmail,
                FirstName = "System",
                LastName = "Admin",
                PhoneNumber = "+1234567890",
                EmailConfirmed = true
            };

            var result = await userManager.CreateAsync(adminUser, "Admin@123");
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(adminUser, "Admin");
            }
        }

        // ========== SEED MANAGER USER ==========
        var managerEmail = "manager@bookify.com";
        var managerUser = await userManager.FindByEmailAsync(managerEmail);
        if (managerUser == null)
        {
            managerUser = new ApplicationUser
            {
                UserName = managerEmail,
                Email = managerEmail,
                FirstName = "Hotel",
                LastName = "Manager",
                PhoneNumber = "+1234567891",
                EmailConfirmed = true
            };

            var result = await userManager.CreateAsync(managerUser, "Manager@123");
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(managerUser, "Manager");
            }
        }

        // ========== SEED ROOM TYPES ==========
        if (!context.RoomTypes.Any())
        {
            var roomTypes = new[]
            {
                new RoomType
                {
                    Name = "Standard Room",
                    Description = "Comfortable and affordable accommodation with all essential amenities. Perfect for business travelers and short stays.",
                    PricePerNight = 99.00m,
                    Capacity = 2,
                    SizeInSqFt = 300,
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                },
                new RoomType
                {
                    Name = "Deluxe Room",
                    Description = "Spacious room with premium amenities and separate seating area. Ideal for families and extended stays.",
                    PricePerNight = 159.00m,
                    Capacity = 3,
                    SizeInSqFt = 450,
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                },
                new RoomType
                {
                    Name = "Executive Suite",
                    Description = "Luxurious suite with separate bedroom and living area. Features premium furnishings and exclusive services.",
                    PricePerNight = 299.00m,
                    Capacity = 4,
                    SizeInSqFt = 650,
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                },
                new RoomType
                {
                    Name = "Presidential Suite",
                    Description = "The ultimate luxury experience with panoramic views, private balcony, and premium services.",
                    PricePerNight = 599.00m,
                    Capacity = 6,
                    SizeInSqFt = 1200,
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                }
            };

            await context.RoomTypes.AddRangeAsync(roomTypes);
            await context.SaveChangesAsync();
        }

        // ========== SEED ROOMS ==========
        if (!context.Rooms.Any())
        {
            var rooms = new List<Room>();

            // Standard Rooms (101-110)
            for (int i = 1; i <= 10; i++)
            {
                rooms.Add(new Room
                {
                    RoomTypeId = 1, // Standard
                    RoomNumber = $"10{i}",
                    Floor = "1",
                    View = i <= 5 ? "City View" : "Garden View",
                    Status = "Available",
                    AdditionalNotes = "Standard room with basic amenities",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                });
            }

            // Deluxe Rooms (201-208)
            for (int i = 1; i <= 8; i++)
            {
                rooms.Add(new Room
                {
                    RoomTypeId = 2, // Deluxe
                    RoomNumber = $"20{i}",
                    Floor = "2",
                    View = i <= 4 ? "Sea View" : "City View",
                    Status = "Available",
                    AdditionalNotes = "Deluxe room with premium amenities",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                });
            }

            // Executive Suites (301-305)
            for (int i = 1; i <= 5; i++)
            {
                rooms.Add(new Room
                {
                    RoomTypeId = 3, // Executive
                    RoomNumber = $"30{i}",
                    Floor = "3",
                    View = "Ocean View",
                    Status = "Available",
                    AdditionalNotes = "Executive suite with luxury services",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                });
            }

            // Presidential Suites (401-402)
            for (int i = 1; i <= 2; i++)
            {
                rooms.Add(new Room
                {
                    RoomTypeId = 4, // Presidential
                    RoomNumber = $"40{i}",
                    Floor = "4",
                    View = "Panoramic View",
                    Status = "Available",
                    AdditionalNotes = "Presidential suite with exclusive services",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                });
            }

            await context.Rooms.AddRangeAsync(rooms);
            await context.SaveChangesAsync();
        }

        // ========== SEED AMENITIES ==========
        if (!context.Amenities.Any())
        {
            var amenities = new[]
            {
                new Amenity
                {
                    Name = "Free WiFi",
                    Description = "High-speed internet access",
                    IconClass = "fas fa-wifi",
                    CreatedDate = DateTime.UtcNow
                },
                new Amenity
                {
                    Name = "Air Conditioning",
                    Description = "Climate control system",
                    IconClass = "fas fa-snowflake",
                    CreatedDate = DateTime.UtcNow
                },
                new Amenity
                {
                    Name = "TV",
                    Description = "Flat-screen television with cable channels",
                    IconClass = "fas fa-tv",
                    CreatedDate = DateTime.UtcNow
                },
                new Amenity
                {
                    Name = "Mini Bar",
                    Description = "Stocked mini refrigerator",
                    IconClass = "fas fa-glass-whiskey",
                    CreatedDate = DateTime.UtcNow
                },
                new Amenity
                {
                    Name = "Safe",
                    Description = "In-room safety deposit box",
                    IconClass = "fas fa-lock",
                    CreatedDate = DateTime.UtcNow
                },
                new Amenity
                {
                    Name = "Hair Dryer",
                    Description = "Professional hair dryer",
                    IconClass = "fas fa-wind",
                    CreatedDate = DateTime.UtcNow
                },
                new Amenity
                {
                    Name = "Coffee Maker",
                    Description = "In-room coffee and tea facilities",
                    IconClass = "fas fa-coffee",
                    CreatedDate = DateTime.UtcNow
                },
                new Amenity
                {
                    Name = "Room Service",
                    Description = "24-hour room service available",
                    IconClass = "fas fa-concierge-bell",
                    CreatedDate = DateTime.UtcNow
                },
                new Amenity
                {
                    Name = "Swimming Pool",
                    Description = "Access to swimming pool",
                    IconClass = "fas fa-swimming-pool",
                    CreatedDate = DateTime.UtcNow
                },
                new Amenity
                {
                    Name = "Fitness Center",
                    Description = "Access to fitness facility",
                    IconClass = "fas fa-dumbbell",
                    CreatedDate = DateTime.UtcNow
                }
            };

            await context.Amenities.AddRangeAsync(amenities);
            await context.SaveChangesAsync();
        }

        // ========== SEED ROOM TYPE AMENITIES ==========
        if (!context.RoomTypeAmenities.Any())
        {
            var roomTypeAmenities = new List<RoomTypeAmenity>();

            // Standard Room Amenities
            roomTypeAmenities.AddRange(new[]
            {
                new RoomTypeAmenity { RoomTypeId = 1, AmenityId = 1, CreatedDate = DateTime.UtcNow }, // WiFi
                new RoomTypeAmenity { RoomTypeId = 1, AmenityId = 2, CreatedDate = DateTime.UtcNow }, // AC
                new RoomTypeAmenity { RoomTypeId = 1, AmenityId = 3, CreatedDate = DateTime.UtcNow }, // TV
                new RoomTypeAmenity { RoomTypeId = 1, AmenityId = 6, CreatedDate = DateTime.UtcNow }, // Hair Dryer
                new RoomTypeAmenity { RoomTypeId = 1, AmenityId = 7, CreatedDate = DateTime.UtcNow }, // Coffee Maker
            });

            // Deluxe Room Amenities (includes all Standard amenities plus more)
            roomTypeAmenities.AddRange(new[]
            {
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 1, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 2, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 3, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 4, CreatedDate = DateTime.UtcNow }, // Mini Bar
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 5, CreatedDate = DateTime.UtcNow }, // Safe
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 6, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 7, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 8, CreatedDate = DateTime.UtcNow }, // Room Service
            });

            // Executive Suite Amenities (includes all Deluxe amenities plus more)
            roomTypeAmenities.AddRange(new[]
            {
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 1, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 2, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 3, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 4, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 5, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 6, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 7, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 8, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 9, CreatedDate = DateTime.UtcNow }, // Pool
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 10, CreatedDate = DateTime.UtcNow }, // Fitness
            });

            // Presidential Suite Amenities (all amenities)
            roomTypeAmenities.AddRange(new[]
            {
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 1, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 2, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 3, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 4, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 5, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 6, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 7, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 8, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 9, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 10, CreatedDate = DateTime.UtcNow },
            });

            await context.RoomTypeAmenities.AddRangeAsync(roomTypeAmenities);
            await context.SaveChangesAsync();
        }

        Console.WriteLine("Database seeding completed successfully.");
    }
    catch (Exception ex)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "An error occurred while seeding the database.");
    }
}