using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Home
{
    public class ErrorModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
