using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Home
{
    public class ServicesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
