using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Rooms
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
