using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Rooms
{
    public class SearchModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
