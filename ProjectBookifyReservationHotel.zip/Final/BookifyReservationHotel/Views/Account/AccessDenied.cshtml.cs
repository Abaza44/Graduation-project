using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Account
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
