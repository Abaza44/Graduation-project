using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Account
{
    public class ForgotPasswordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
