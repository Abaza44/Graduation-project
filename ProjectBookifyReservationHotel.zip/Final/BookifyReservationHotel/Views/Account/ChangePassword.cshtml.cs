using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Account
{
    public class ChangePasswordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
