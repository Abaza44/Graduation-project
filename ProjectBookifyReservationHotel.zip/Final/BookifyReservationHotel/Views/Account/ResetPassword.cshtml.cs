using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Account
{
    public class ResetPasswordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
