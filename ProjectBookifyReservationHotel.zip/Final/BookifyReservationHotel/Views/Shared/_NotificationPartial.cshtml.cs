using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Shared
{
    public class _NotificationPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
