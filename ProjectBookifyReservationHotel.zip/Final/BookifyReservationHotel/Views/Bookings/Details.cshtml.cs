using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Bookings
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
