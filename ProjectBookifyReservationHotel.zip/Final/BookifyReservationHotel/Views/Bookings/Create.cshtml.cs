using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Bookings
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
