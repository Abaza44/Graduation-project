using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookifyReservationHotel.Views.Bookings
{
    public class PaymentModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
