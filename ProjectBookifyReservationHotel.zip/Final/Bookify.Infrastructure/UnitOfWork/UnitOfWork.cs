﻿using Bookify.Core.Interfaces;
using Bookify.Infrastructure.Data;
using Bookify.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDbContext _context;
        private IDbContextTransaction _transaction;

        // Repository instances
        private IRoomTypeRepository _roomTypes;
        private IRoomRepository _rooms;
        private IBookingRepository _bookings;
        private IPaymentRepository _payments;
        private IReviewRepository _reviews;
        private IAmenityRepository _amenities;
        private IImageRepository _images;

        public UnitOfWork(ApplicationDbContext context)
        {
            _context = context;
        }

        // Lazy-loaded repositories
        public IRoomTypeRepository RoomTypes =>
            _roomTypes ??= new RoomTypeRepository(_context);

        public IRoomRepository Rooms =>
            _rooms ??= new RoomRepository(_context);

        public IBookingRepository Bookings =>
            _bookings ??= new BookingRepository(_context);

        public IPaymentRepository Payments =>
            _payments ??= new PaymentRepository(_context);

        public IReviewRepository Reviews =>
            _reviews ??= new ReviewRepository(_context);

        public IAmenityRepository Amenities =>
            _amenities ??= new AmenityRepository(_context);

        public IImageRepository Images =>
            _images ??= new ImageRepository(_context);

        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public async Task BeginTransactionAsync()
        {
            _transaction = await _context.Database.BeginTransactionAsync();
        }

        public async Task CommitTransactionAsync()
        {
            try
            {
                await _context.SaveChangesAsync();
                await _transaction?.CommitAsync();
            }
            catch
            {
                await RollbackTransactionAsync();
                throw;
            }
            finally
            {
                if (_transaction != null)
                {
                    await _transaction.DisposeAsync();
                    _transaction = null;
                }
            }
        }

        public async Task RollbackTransactionAsync()
        {
            if (_transaction != null)
            {
                await _transaction.RollbackAsync();
                await _transaction.DisposeAsync();
                _transaction = null;
            }
        }

        public void Dispose()
        {
            _transaction?.Dispose();
            _context?.Dispose();

            // Dispose repositories if needed
            _roomTypes = null;
            _rooms = null;
            _bookings = null;
            _payments = null;
            _reviews = null;
            _amenities = null;
            _images = null;
        }
    }
}