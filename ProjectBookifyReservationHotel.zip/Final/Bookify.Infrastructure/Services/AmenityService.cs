﻿using AutoMapper;
using Bookify.Core.DTOs;
using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Core.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Services
{
    public class AmenityService : IAmenityService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public AmenityService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<IEnumerable<AmenityDto>> GetAllAmenitiesAsync()
        {
            var amenities = await _unitOfWork.Amenities.GetAllAsync();
            return _mapper.Map<IEnumerable<AmenityDto>>(amenities);
        }

        public async Task<AmenityDto> GetAmenityByIdAsync(int id)
        {
            var amenity = await _unitOfWork.Amenities.GetByIdAsync(id);
            return _mapper.Map<AmenityDto>(amenity);
        }

        public async Task<AmenityDto> CreateAmenityAsync(CreateAmenityDto dto)
        {
            // Check if amenity already exists
            var existingAmenity = await _unitOfWork.Amenities.FindAsync(a =>
                a.Name.ToLower() == dto.Name.ToLower());

            if (existingAmenity.Any())
            {
                throw new InvalidOperationException($"Amenity with name '{dto.Name}' already exists.");
            }

            var amenity = _mapper.Map<Amenity>(dto);
            amenity.CreatedDate = DateTime.UtcNow;

            await _unitOfWork.Amenities.AddAsync(amenity);
            await _unitOfWork.SaveChangesAsync();

            return _mapper.Map<AmenityDto>(amenity);
        }

        public async Task<AmenityDto> UpdateAmenityAsync(UpdateAmenityDto dto)
        {
            var amenity = await _unitOfWork.Amenities.GetByIdAsync(dto.Id);
            if (amenity == null)
                throw new Exception("Amenity not found");

            // Check if name already exists (excluding current amenity)
            var existingAmenity = await _unitOfWork.Amenities.FindAsync(a =>
                a.Name.ToLower() == dto.Name.ToLower() && a.Id != dto.Id);

            if (existingAmenity.Any())
            {
                throw new InvalidOperationException($"Amenity with name '{dto.Name}' already exists.");
            }

            _mapper.Map(dto, amenity);
            amenity.UpdatedDate = DateTime.UtcNow;

            await _unitOfWork.Amenities.UpdateAsync(amenity);
            await _unitOfWork.SaveChangesAsync();

            return _mapper.Map<AmenityDto>(amenity);
        }

        public async Task<bool> DeleteAmenityAsync(int id)
        {
            var amenity = await _unitOfWork.Amenities.GetByIdAsync(id);
            if (amenity == null)
                return false;

            // Check if amenity is used by any room types
            var isUsed = await _unitOfWork.RoomTypes.IsAmenityUsedAsync(id);
            if (isUsed)
            {
                throw new InvalidOperationException("Cannot delete amenity that is currently used by room types.");
            }

            await _unitOfWork.Amenities.DeleteAsync(amenity);
            await _unitOfWork.SaveChangesAsync();

            return true;
        }

        public async Task<bool> AmenityExistsAsync(string name, int? id = null)
        {
            var amenities = await _unitOfWork.Amenities.FindAsync(a =>
                a.Name.ToLower() == name.ToLower() && (id == null || a.Id != id));
            return amenities.Any();
        }

        public async Task<IEnumerable<AmenityUsageDto>> GetAmenityUsageStatsAsync()
        {
            var amenities = await _unitOfWork.Amenities.GetAllAsync();
            var roomTypes = await _unitOfWork.RoomTypes.GetAllRoomTypesWithAmenitiesAsync();

            var usageStats = amenities.Select(amenity => new AmenityUsageDto
            {
                AmenityId = amenity.Id,
                AmenityName = amenity.Name,
                RoomTypeCount = roomTypes.Count(rt =>
                    rt.RoomTypeAmenities?.Any(rta => rta.AmenityId == amenity.Id) == true),
                TotalUsage = roomTypes.Sum(rt =>
                    rt.RoomTypeAmenities?.Count(rta => rta.AmenityId == amenity.Id) ?? 0)
            });

            return usageStats;
        }
    }
}