﻿using Bookify.Core.DTOs;
using Bookify.Core.Interfaces;
using Bookify.Core.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Services
{
    public class DashboardService : IDashboardService
    {
        private readonly IUnitOfWork _unitOfWork;

        public DashboardService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<DashboardStatsDto> GetDashboardStatsAsync()
        {
            var today = DateTime.Today;
            var startOfMonth = new DateTime(today.Year, today.Month, 1);
            var endOfDay = today.AddDays(1);

            try
            {
                var totalBookingsToday = await _unitOfWork.Bookings.GetTotalBookingsCountAsync(today);
                var totalBookingsThisMonth = await _unitOfWork.Bookings.GetTotalBookingsCountAsync();

                var revenueToday = await _unitOfWork.Bookings.GetTotalRevenueAsync(today, endOfDay);
                var revenueThisMonth = await _unitOfWork.Bookings.GetTotalRevenueAsync(startOfMonth, DateTime.Now);

                var allRooms = await _unitOfWork.Rooms.GetAllAsync();
                var availableRooms = allRooms.Count(r => r.Status == "Available");
                var totalRooms = allRooms.Count();

                var pendingBookings = await _unitOfWork.Bookings.GetBookingCountByStatusAsync("Pending");
                var checkInsToday = (await _unitOfWork.Bookings.GetTodayCheckInsAsync()).Count();
                var checkOutsToday = (await _unitOfWork.Bookings.GetTodayCheckOutsAsync()).Count();

                var occupancyRate = totalRooms > 0
                    ? ((double)(totalRooms - availableRooms) / totalRooms) * 100
                    : 0;

                return new DashboardStatsDto
                {
                    TotalBookingsToday = totalBookingsToday,
                    TotalBookingsThisMonth = totalBookingsThisMonth,
                    RevenueToday = revenueToday,
                    RevenueThisMonth = revenueThisMonth,
                    AvailableRooms = availableRooms,
                    TotalRooms = totalRooms,
                    OccupancyRate = Math.Round(occupancyRate, 2),
                    PendingBookings = pendingBookings,
                    CheckInsToday = checkInsToday,
                    CheckOutsToday = checkOutsToday
                };
            }
            catch (Exception ex)
            {
                throw new Exception($"Error loading dashboard statistics: {ex.Message}");
            }
        }

        public async Task<IEnumerable<RevenueReportDto>> GetRevenueReportAsync(DateTime startDate, DateTime endDate)
        {
            var bookings = await _unitOfWork.Bookings.GetBookingsByDateRangeAsync(startDate, endDate);

            var revenueReport = bookings
                .Where(b => b.BookingStatus != "Cancelled")
                .GroupBy(b => b.BookingDate.Date)
                .Select(g => new RevenueReportDto
                {
                    Date = g.Key,
                    Revenue = g.Sum(b => b.TotalAmount),
                    BookingsCount = g.Count()
                })
                .OrderBy(r => r.Date)
                .ToList();

            return revenueReport;
        }

        public async Task<IEnumerable<OccupancyReportDto>> GetOccupancyReportAsync(DateTime startDate, DateTime endDate)
        {
            var allRooms = await _unitOfWork.Rooms.GetAllAsync();
            var totalRooms = allRooms.Count();

            var bookings = await _unitOfWork.Bookings.GetBookingsByDateRangeAsync(startDate, endDate);

            var occupancyReport = new List<OccupancyReportDto>();

            for (var date = startDate.Date; date <= endDate.Date; date = date.AddDays(1))
            {
                var occupiedRooms = bookings.Count(b =>
                    (b.BookingStatus == "CheckedIn" || b.BookingStatus == "Confirmed") &&
                    b.CheckInDate.Date <= date &&
                    b.CheckOutDate.Date > date
                );

                var occupancyRate = totalRooms > 0
                    ? ((double)occupiedRooms / totalRooms) * 100
                    : 0;

                occupancyReport.Add(new OccupancyReportDto
                {
                    Date = date,
                    OccupiedRooms = occupiedRooms,
                    TotalRooms = totalRooms,
                    OccupancyRate = Math.Round(occupancyRate, 2)
                });
            }

            return occupancyReport;
        }

        public async Task<IEnumerable<PopularRoomTypeDto>> GetPopularRoomTypesAsync(int topCount = 5)
        {
            var bookings = await _unitOfWork.Bookings.GetBookingsByDateRangeAsync(
                DateTime.Today.AddDays(-30),
                DateTime.Today
            );

            var popularRoomTypes = bookings
                .Where(b => b.BookingStatus != "Cancelled")
                .GroupBy(b => b.RoomType.Name)
                .Select(g => new PopularRoomTypeDto
                {
                    RoomTypeName = g.Key,
                    BookingsCount = g.Count(),
                    TotalRevenue = g.Sum(b => b.TotalAmount)
                })
                .OrderByDescending(p => p.BookingsCount)
                .Take(topCount)
                .ToList();

            return popularRoomTypes;
        }
    }
}