﻿using AutoMapper;
using Bookify.Core.DTOs;
using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Core.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReviewStatisticsDto = Bookify.Core.DTOs.ReviewStatisticsDto;

namespace Bookify.Infrastructure.Services
{
    public class ReviewService : IReviewService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public ReviewService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<ReviewDto> GetReviewByIdAsync(int id)
        {
            try
            {
                var review = await _unitOfWork.Reviews.GetByIdAsync(id);
                if (review == null) return null;

                return _mapper.Map<ReviewDto>(review);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving review: {ex.Message}", ex);
            }
        }

        public async Task<IEnumerable<ReviewDto>> GetReviewsByRoomTypeAsync(int roomTypeId)
        {
            try
            {
                var reviews = await _unitOfWork.Reviews.GetReviewsByRoomTypeAsync(roomTypeId);
                return _mapper.Map<IEnumerable<ReviewDto>>(reviews);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving reviews for room type {roomTypeId}: {ex.Message}", ex);
            }
        }

        public async Task<IEnumerable<ReviewDto>> GetReviewsByUserAsync(string userId)
        {
            try
            {
                var reviews = await _unitOfWork.Reviews.GetReviewsByUserAsync(userId);
                return _mapper.Map<IEnumerable<ReviewDto>>(reviews);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving reviews for user {userId}: {ex.Message}", ex);
            }
        }

        public async Task<IEnumerable<ReviewDto>> GetPendingReviewsAsync()
        {
            try
            {
                var reviews = await _unitOfWork.Reviews.GetPendingReviewsAsync();
                return _mapper.Map<IEnumerable<ReviewDto>>(reviews);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving pending reviews: {ex.Message}", ex);
            }
        }

        public async Task<ReviewDto> CreateReviewAsync(CreateReviewDto dto)
        {
            try
            {
                // التحقق من وجود تقييم سابق
                var existingReview = await _unitOfWork.Reviews.FindAsync(r =>
                    r.UserId == dto.UserId && r.RoomTypeId == dto.RoomTypeId);

                if (existingReview.Any())
                    throw new Exception("You have already reviewed this room type.");

                var review = _mapper.Map<Review>(dto);
                review.CreatedDate = DateTime.UtcNow;
                review.IsApproved = false; // يحتاج موافقة المسؤول

                await _unitOfWork.Reviews.AddAsync(review);
                await _unitOfWork.SaveChangesAsync();

                return _mapper.Map<ReviewDto>(review);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error creating review: {ex.Message}", ex);
            }
        }

        public async Task<bool> UpdateReviewAsync(UpdateReviewDto dto)
        {
            try
            {
                var review = await _unitOfWork.Reviews.GetByIdAsync(dto.Id);
                if (review == null) return false;

                _mapper.Map(dto, review);
                review.UpdatedDate = DateTime.UtcNow;
                review.IsApproved = false; // يحتاج إعادة موافقة بعد التعديل

                await _unitOfWork.Reviews.UpdateAsync(review);
                await _unitOfWork.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error updating review {dto.Id}: {ex.Message}", ex);
            }
        }

        public async Task<bool> DeleteReviewAsync(int id)
        {
            try
            {
                var review = await _unitOfWork.Reviews.GetByIdAsync(id);
                if (review == null) return false;

                await _unitOfWork.Reviews.DeleteAsync(review);
                await _unitOfWork.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error deleting review {id}: {ex.Message}", ex);
            }
        }

        public async Task<bool> ApproveReviewAsync(int id)
        {
            try
            {
                var review = await _unitOfWork.Reviews.GetByIdAsync(id);
                if (review == null) return false;

                review.IsApproved = true;
                review.UpdatedDate = DateTime.UtcNow;

                await _unitOfWork.Reviews.UpdateAsync(review);
                await _unitOfWork.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error approving review {id}: {ex.Message}", ex);
            }
        }

        public async Task<bool> RejectReviewAsync(int id)
        {
            try
            {
                var review = await _unitOfWork.Reviews.GetByIdAsync(id);
                if (review == null) return false;

                await _unitOfWork.Reviews.DeleteAsync(review);
                await _unitOfWork.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error rejecting review {id}: {ex.Message}", ex);
            }
        }

        public async Task<ReviewSummaryDto> GetReviewSummaryAsync(int roomTypeId)
        {
            try
            {
                var reviews = await _unitOfWork.Reviews.GetReviewsByRoomTypeAsync(roomTypeId);
                var approvedReviews = reviews.Where(r => r.IsApproved).ToList();

                if (!approvedReviews.Any())
                    return new ReviewSummaryDto();

                return new ReviewSummaryDto
                {
                    AverageRating = Math.Round(approvedReviews.Average(r => r.Rating), 1),
                    TotalReviews = approvedReviews.Count,
                    FiveStar = approvedReviews.Count(r => r.Rating == 5),
                    FourStar = approvedReviews.Count(r => r.Rating == 4),
                    ThreeStar = approvedReviews.Count(r => r.Rating == 3),
                    TwoStar = approvedReviews.Count(r => r.Rating == 2),
                    OneStar = approvedReviews.Count(r => r.Rating == 1)
                };
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting review summary for room type {roomTypeId}: {ex.Message}", ex);
            }
        }

        // 🆕 Methods الجديدة للـ Admin
        public async Task<IEnumerable<ReviewDto>> GetAllReviewsAsync()
        {
            try
            {
                var reviews = await _unitOfWork.Reviews.GetAllAsync();
                return _mapper.Map<IEnumerable<ReviewDto>>(reviews);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving all reviews: {ex.Message}", ex);
            }
        }

        public async Task<bool> UpdateReviewStatusAsync(int id, string status)
        {
            try
            {
                var review = await _unitOfWork.Reviews.GetByIdAsync(id);
                if (review == null) return false;

                review.IsApproved = status == "Approved";
                review.UpdatedDate = DateTime.UtcNow;

                await _unitOfWork.Reviews.UpdateAsync(review);
                await _unitOfWork.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error updating review status for {id}: {ex.Message}", ex);
            }
        }

        public async Task<IEnumerable<ReviewDto>> GetReviewsByStatusAsync(string status)
        {
            try
            {
                var allReviews = await _unitOfWork.Reviews.GetAllAsync();

                var filteredReviews = status?.ToLower() switch
                {
                    "pending" => allReviews.Where(r => !r.IsApproved),
                    "approved" => allReviews.Where(r => r.IsApproved),
                    "rejected" => allReviews.Where(r => !r.IsApproved), // يمكن تعديل المنطق حسب الحاجة
                    _ => allReviews
                };

                return _mapper.Map<IEnumerable<ReviewDto>>(filteredReviews);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving reviews by status {status}: {ex.Message}", ex);
            }
        }

        public async Task<Core.DTOs.ReviewStatisticsDto> GetReviewStatisticsAsync()
        {
            try
            {
                var reviews = await _unitOfWork.Reviews.GetAllAsync();
                var approvedReviews = reviews.Where(r => r.IsApproved).ToList();
                var pendingReviews = reviews.Where(r => !r.IsApproved).ToList();

                var recentReviews = reviews.Where(r => r.CreatedDate >= DateTime.UtcNow.AddDays(-30)).ToList();

                return new ReviewStatisticsDto
                {
                    TotalReviews = reviews.Count(),
                    ApprovedReviews = approvedReviews.Count,
                    PendingReviews = pendingReviews.Count,
                    AverageRating = approvedReviews.Any() ? Math.Round(approvedReviews.Average(r => r.Rating), 1) : 0,
                    TotalRoomTypes = reviews.Select(r => r.RoomTypeId).Distinct().Count(),
                    RecentReviews = recentReviews.Count,
                    FiveStarReviews = approvedReviews.Count(r => r.Rating == 5),
                    FourStarReviews = approvedReviews.Count(r => r.Rating == 4),
                    ThreeStarReviews = approvedReviews.Count(r => r.Rating == 3),
                    TwoStarReviews = approvedReviews.Count(r => r.Rating == 2),
                    OneStarReviews = approvedReviews.Count(r => r.Rating == 1)
                };
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving review statistics: {ex.Message}", ex);
            }
        }

        Task<Core.Interfaces.Services.ReviewStatisticsDto> IReviewService.GetReviewStatisticsAsync()
        {
            throw new NotImplementedException();
        }
    }
}