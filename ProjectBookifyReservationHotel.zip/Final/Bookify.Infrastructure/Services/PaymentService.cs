﻿using AutoMapper;
using Bookify.Core.DTOs;
using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Core.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IPaymentGateway _paymentGateway;

        public PaymentService(IUnitOfWork unitOfWork, IMapper mapper, IPaymentGateway paymentGateway)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _paymentGateway = paymentGateway;
        }

        public async Task<PaymentDto> GetPaymentByIdAsync(int id)
        {
            var payment = await _unitOfWork.Payments.GetPaymentWithDetailsAsync(id);
            return _mapper.Map<PaymentDto>(payment);
        }

        public async Task<PaymentDto> GetPaymentByTransactionIdAsync(string transactionId)
        {
            var payment = await _unitOfWork.Payments.GetPaymentByTransactionIdAsync(transactionId);
            return _mapper.Map<PaymentDto>(payment);
        }

        public async Task<IEnumerable<PaymentDto>> GetPaymentsByBookingAsync(int bookingId)
        {
            var payments = await _unitOfWork.Payments.GetPaymentsByBookingAsync(bookingId);
            return _mapper.Map<IEnumerable<PaymentDto>>(payments);
        }

        public async Task<IEnumerable<PaymentDto>> GetPaymentsByUserAsync(string userId)
        {
            var payments = await _unitOfWork.Payments.GetPaymentsByUserAsync(userId);
            return _mapper.Map<IEnumerable<PaymentDto>>(payments);
        }

        public async Task<IEnumerable<PaymentDto>> FilterPaymentsAsync(PaymentFilterDto filter)
        {
            var payments = await _unitOfWork.Payments.FilterPaymentsAsync(filter);
            return _mapper.Map<IEnumerable<PaymentDto>>(payments);
        }

        public async Task<PaymentDto> CreatePaymentAsync(CreatePaymentDto dto)
        {

            var booking = await _unitOfWork.Bookings.GetByIdAsync(dto.BookingId);
            if (booking == null)
                throw new Exception("Booking not found");

            if (booking.BookingStatus == "Cancelled")
                throw new Exception("Cannot process payment for cancelled booking");

            var existingPayments = await _unitOfWork.Payments.GetPaymentsByBookingAsync(dto.BookingId);
            if (existingPayments.Any(p => p.PaymentStatus == "Completed"))
                throw new Exception("Payment already completed for this booking");

            if (dto.Amount != booking.TotalAmount)
                throw new Exception($"Payment amount ({dto.Amount}) does not match booking total ({booking.TotalAmount})");

            var payment = new Payment
            {
                BookingId = dto.BookingId,
                PaymentMethod = dto.PaymentMethod,
                Amount = dto.Amount,
                Currency = "USD",
                PaymentStatus = "Pending",
                Description = dto.Description,
                PaymentDate = DateTime.UtcNow,
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow
            };

            if (dto.PaymentMethod == "CreditCard" && !string.IsNullOrEmpty(dto.CardNumber))
            {
                payment.LastFourDigits = dto.CardNumber.Length >= 4 ? dto.CardNumber.Substring(dto.CardNumber.Length - 4) : "";
                payment.CardType = GetCardType(dto.CardNumber);
            }

            await _unitOfWork.Payments.AddAsync(payment);
            await _unitOfWork.SaveChangesAsync();

            return _mapper.Map<PaymentDto>(payment);
        }

        public async Task<PaymentDto> ProcessPaymentAsync(ProcessPaymentDto dto)
        {
            var payment = await _unitOfWork.Payments.GetByIdAsync(dto.PaymentId);
            if (payment == null)
                throw new Exception("Payment not found");

            if (payment.PaymentStatus != "Pending")
                throw new Exception($"Payment already processed with status: {payment.PaymentStatus}");

            payment.TransactionId = dto.TransactionId;
            payment.PaymentStatus = dto.PaymentStatus;
            payment.PaymentResponse = dto.PaymentResponse;
            payment.UpdatedDate = DateTime.UtcNow;

            if (dto.PaymentStatus == "Completed")
            {
                payment.ProcessedDate = DateTime.UtcNow;

                var booking = await _unitOfWork.Bookings.GetByIdAsync(payment.BookingId);
                if (booking != null && booking.BookingStatus == "Pending")
                {
                    booking.BookingStatus = "Confirmed";
                    booking.UpdatedDate = DateTime.UtcNow;
                    await _unitOfWork.Bookings.UpdateAsync(booking);
                }
            }

            await _unitOfWork.Payments.UpdateAsync(payment);
            await _unitOfWork.SaveChangesAsync();

            return await GetPaymentByIdAsync(payment.Id);
        }

        public async Task<bool> RefundPaymentAsync(RefundPaymentDto dto)
        {
            var payment = await _unitOfWork.Payments.GetByIdAsync(dto.PaymentId);
            if (payment == null)
                throw new Exception("Payment not found");

            if (payment.PaymentStatus != "Completed")
                throw new Exception("Only completed payments can be refunded");

            var refundAmount = dto.RefundAmount ?? payment.Amount;

            if (refundAmount > payment.Amount)
                throw new Exception("Refund amount cannot exceed original payment amount");

            // Process refund through payment gateway
            var refundRequest = new RefundRequest
            {
                TransactionId = payment.TransactionId,
                Amount = refundAmount,
                Reason = dto.RefundReason
            };

            var refundResult = await _paymentGateway.ProcessRefundAsync(refundRequest);

            if (refundResult.Success)
            {
                payment.PaymentStatus = refundAmount == payment.Amount ? "Refunded" : "PartiallyRefunded";
                payment.RefundDate = DateTime.UtcNow;
                payment.UpdatedDate = DateTime.UtcNow;

                await _unitOfWork.Payments.UpdateAsync(payment);
                await _unitOfWork.SaveChangesAsync();

                return true;
            }

            throw new Exception($"Refund failed: {refundResult.Message}");
        }

        public async Task<bool> UpdatePaymentStatusAsync(int paymentId, string status)
        {
            var payment = await _unitOfWork.Payments.GetByIdAsync(paymentId);
            if (payment == null)
                return false;

            payment.PaymentStatus = status;
            payment.UpdatedDate = DateTime.UtcNow;

            await _unitOfWork.Payments.UpdateAsync(payment);
            await _unitOfWork.SaveChangesAsync();

            return true;
        }

        public async Task<PaymentSummaryDto> GetPaymentSummaryAsync(DateTime? startDate = null, DateTime? endDate = null)
        {
            var totalRevenue = await _unitOfWork.Payments.GetTotalRevenueAsync(startDate, endDate);
            var totalTransactions = await _unitOfWork.Payments.GetPaymentCountByStatusAsync("Completed");
            var successfulPayments = await _unitOfWork.Payments.GetPaymentCountByStatusAsync("Completed");
            var failedPayments = await _unitOfWork.Payments.GetPaymentCountByStatusAsync("Failed");
            var pendingPayments = await _unitOfWork.Payments.GetPaymentCountByStatusAsync("Pending");

            return new PaymentSummaryDto
            {
                TotalRevenue = totalRevenue,
                TotalTransactions = totalTransactions,
                SuccessfulPayments = successfulPayments,
                FailedPayments = failedPayments,
                PendingPayments = pendingPayments,
                AverageTransactionAmount = totalTransactions > 0 ? totalRevenue / totalTransactions : 0
            };
        }

        public async Task<PaymentSimulationResult> SimulatePaymentAsync(CreatePaymentDto dto)
        {
            var paymentRequest = new PaymentRequest
            {
                Amount = dto.Amount,
                PaymentMethod = dto.PaymentMethod,
                CardNumber = dto.CardNumber,
                ExpiryDate = dto.ExpiryDate,
                CVV = dto.CVV,
                CardHolderName = dto.CardHolderName,
                Description = dto.Description
            };

            var result = await _paymentGateway.ProcessPaymentAsync(paymentRequest);

            return new PaymentSimulationResult
            {
                Success = result.Success,
                TransactionId = result.TransactionId,
                Message = result.Message,
                GatewayResponse = result.GatewayResponse
            };
        }

        public async Task<bool> ValidatePaymentAsync(CreatePaymentDto dto)
        {
            var paymentRequest = new PaymentRequest
            {
                Amount = dto.Amount,
                PaymentMethod = dto.PaymentMethod,
                CardNumber = dto.CardNumber,
                ExpiryDate = dto.ExpiryDate,
                CVV = dto.CVV,
                CardHolderName = dto.CardHolderName
            };

            return await _paymentGateway.ValidatePaymentAsync(paymentRequest);
        }

        private string GetCardType(string cardNumber)
        {
            if (string.IsNullOrEmpty(cardNumber))
                return "Unknown";

            // Simple card type detection (in real app, use proper validation)
            if (cardNumber.StartsWith("4")) return "Visa";
            if (cardNumber.StartsWith("5")) return "MasterCard";
            if (cardNumber.StartsWith("34") || cardNumber.StartsWith("37")) return "American Express";
            if (cardNumber.StartsWith("6")) return "Discover";

            return "Unknown";
        }
    }
}