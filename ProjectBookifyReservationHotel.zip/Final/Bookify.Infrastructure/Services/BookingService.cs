﻿using AutoMapper;
using Bookify.Core.DTOs;
using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Core.Interfaces.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Services
{
    public class BookingService : IBookingService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public BookingService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<BookingDto> GetBookingByIdAsync(int id)
        {
            var booking = await _unitOfWork.Bookings.GetBookingWithDetailsAsync(id);
            return _mapper.Map<BookingDto>(booking);
        }

        public async Task<BookingDto> GetBookingByConfirmationCodeAsync(string confirmationCode)
        {
            var booking = await _unitOfWork.Bookings.GetBookingByConfirmationCodeAsync(confirmationCode);
            return _mapper.Map<BookingDto>(booking);
        }

        public async Task<IEnumerable<BookingDto>> GetBookingsByUserAsync(string userId)
        {
            var bookings = await _unitOfWork.Bookings.GetBookingsByUserAsync(userId);
            return _mapper.Map<IEnumerable<BookingDto>>(bookings);
        }

        public async Task<IEnumerable<BookingDto>> FilterBookingsAsync(BookingFilterDto filter)
        {
            var bookings = await _unitOfWork.Bookings.FilterBookingsAsync(filter);
            return _mapper.Map<IEnumerable<BookingDto>>(bookings);
        }

        public async Task<BookingDto> CreateBookingAsync(CreateBookingDto dto)
        {
            try
            {
                // ✅ Validate dates
                if (dto.CheckInDate < DateTime.Today)
                    throw new Exception("Check-in date cannot be in the past");

                if (dto.CheckOutDate <= dto.CheckInDate)
                    throw new Exception("Check-out date must be after check-in date");

                // ✅ Validate room type exists and is active
                var roomType = await _unitOfWork.RoomTypes.GetByIdAsync(dto.RoomTypeId);
                if (roomType == null || !roomType.IsActive)
                    throw new Exception("Room type not found or not active");

                // ✅ Validate guest count
                if (dto.NumberOfGuests > roomType.Capacity)
                    throw new Exception($"Maximum capacity for this room is {roomType.Capacity} guests");

                // ✅ Get available rooms
                var availableRooms = await GetAvailableRoomsByTypeAsync(dto.RoomTypeId, dto.CheckInDate, dto.CheckOutDate);
                if (!availableRooms.Any())
                    throw new Exception("No available rooms for the selected dates");

                var room = availableRooms.First();

                // ✅ Calculate total if not provided
                var totalAmount = dto.TotalAmount > 0 ? dto.TotalAmount :
                    await CalculateTotalAmountAsync(dto.RoomTypeId, dto.CheckInDate, dto.CheckOutDate);

                // ✅ تأكد إن عندك UserId، لو لسه بتجرب خليه مؤقت
                if (string.IsNullOrEmpty(dto.UserId))
                    dto.UserId = "test-user"; // مؤقت فقط أثناء التطوير

                // ✅ Create booking
                var booking = new Booking
                {
                    UserId = dto.UserId,
                    RoomId = room.Id,
                    RoomTypeId = dto.RoomTypeId,
                    CheckInDate = dto.CheckInDate,
                    CheckOutDate = dto.CheckOutDate,
                    NumberOfGuests = dto.NumberOfGuests,
                    TotalAmount = totalAmount,
                    BookingStatus = "Confirmed", // بدل Pending لتسهيل ظهورها في MyBookings أثناء التجريب
                    ConfirmationCode = GenerateConfirmationCode(),
                    SpecialRequests = dto.SpecialRequests ?? "",
                    BookingDate = DateTime.UtcNow,
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow,
                    CancellationReason = "" // ✅ أضف السطر ده
                };

                await _unitOfWork.Bookings.AddAsync(booking);
                await _unitOfWork.SaveChangesAsync();

                // ✅ Return booking with details
                return await GetBookingByIdAsync(booking.Id);
            }
            catch (DbUpdateException dbEx)
            {
                throw new Exception($"Database error: {dbEx.InnerException?.Message ?? dbEx.Message}");
            }
            catch (Exception ex)
            {
                throw new Exception($"Booking creation failed: {ex.Message}");
            }
        }

        public async Task<bool> CancelBookingAsync(int id, string reason)
        {
            var booking = await _unitOfWork.Bookings.GetByIdAsync(id);
            if (booking == null || booking.BookingStatus == "Cancelled")
                return false;

            // Only allow cancellation for pending and confirmed bookings
            if (booking.BookingStatus != "Pending" && booking.BookingStatus != "Confirmed")
                throw new Exception($"Cannot cancel booking with status: {booking.BookingStatus}");

            booking.BookingStatus = "Cancelled";
            booking.CancellationDate = DateTime.UtcNow;
            booking.CancellationReason = reason;
            booking.UpdatedDate = DateTime.UtcNow;

            // If room was occupied, make it available again
            if (booking.BookingStatus == "CheckedIn")
            {
                await _unitOfWork.Rooms.UpdateRoomStatusAsync(booking.RoomId, "Available");
            }

            await _unitOfWork.Bookings.UpdateAsync(booking);
            await _unitOfWork.SaveChangesAsync();

            return true;
        }

        public async Task<bool> ConfirmBookingAsync(int id)
        {
            var booking = await _unitOfWork.Bookings.GetByIdAsync(id);
            if (booking == null || booking.BookingStatus != "Pending")
                return false;

            // Check if room is still available
            var isAvailable = await IsRoomAvailableForBookingAsync(booking.RoomId, booking.CheckInDate, booking.CheckOutDate, booking.Id);
            if (!isAvailable)
                throw new Exception("Room is no longer available for the selected dates");

            booking.BookingStatus = "Confirmed";
            booking.UpdatedDate = DateTime.UtcNow;

            await _unitOfWork.Bookings.UpdateAsync(booking);
            await _unitOfWork.SaveChangesAsync();

            return true;
        }

        public async Task<bool> CheckInAsync(int id)
        {
            var booking = await _unitOfWork.Bookings.GetByIdAsync(id);
            if (booking == null || booking.BookingStatus != "Confirmed")
                return false;

            // Check if it's check-in day (allow check-in from 2 PM on check-in date)
            if (booking.CheckInDate.Date > DateTime.Today)
                throw new Exception("Check-in is only allowed on or after the scheduled check-in date");

            booking.BookingStatus = "CheckedIn";
            booking.ActualCheckInDate = DateTime.UtcNow;
            booking.UpdatedDate = DateTime.UtcNow;

            await _unitOfWork.Bookings.UpdateAsync(booking);
            await _unitOfWork.Rooms.UpdateRoomStatusAsync(booking.RoomId, "Occupied");
            await _unitOfWork.SaveChangesAsync();

            return true;
        }

        public async Task<bool> CheckOutAsync(int id)
        {
            var booking = await _unitOfWork.Bookings.GetByIdAsync(id);
            if (booking == null || booking.BookingStatus != "CheckedIn")
                return false;

            booking.BookingStatus = "Completed";
            booking.ActualCheckOutDate = DateTime.UtcNow;
            booking.UpdatedDate = DateTime.UtcNow;

            await _unitOfWork.Bookings.UpdateAsync(booking);
            await _unitOfWork.Rooms.UpdateRoomStatusAsync(booking.RoomId, "Cleaning");
            await _unitOfWork.SaveChangesAsync();

            return true;
        }

        public async Task<decimal> CalculateTotalAmountAsync(int roomTypeId, DateTime checkIn, DateTime checkOut)
        {
            var roomType = await _unitOfWork.RoomTypes.GetByIdAsync(roomTypeId);
            if (roomType == null)
                throw new Exception("Room type not found");

            var nights = (checkOut - checkIn).Days;
            if (nights <= 0)
                throw new Exception("Invalid date range");

            // Calculate base amount
            var baseAmount = roomType.PricePerNight * nights;

            // Add taxes and fees (example: 10% tax + 5% service fee)
            var tax = baseAmount * 0.10m;
            var serviceFee = baseAmount * 0.05m;

            return baseAmount + tax + serviceFee;
        }

        public async Task<bool> IsRoomAvailableAsync(int roomTypeId, DateTime checkIn, DateTime checkOut)
        {
            var availableRooms = await GetAvailableRoomsByTypeAsync(roomTypeId, checkIn, checkOut);
            return availableRooms.Any();
        }

        // Method to check availability for a specific room (for booking updates)
        private async Task<bool> IsRoomAvailableForBookingAsync(int roomId, DateTime checkIn, DateTime checkOut, int bookingId)
        {
            return await _unitOfWork.Bookings.HasOverlappingBookingAsync(roomId, checkIn, checkOut, bookingId);
        }

        // Get available rooms for a room type and date range
        // في BookingService.cs، استبدل طريقة GetAvailableRoomsByTypeAsync بهذا:

        // Get available rooms for a room type and date range
        private async Task<IEnumerable<Room>> GetAvailableRoomsByTypeAsync(int roomTypeId, DateTime checkIn, DateTime checkOut)
        {
            try
            {
                // استخدام الطريقة من RoomRepository بدلاً من BookingRepository
                var allRooms = await _unitOfWork.Rooms.GetRoomsByTypeAsync(roomTypeId);
                var availableRooms = new List<Room>();

                foreach (var room in allRooms.Where(r => r.Status == "Available"))
                {
                    var isAvailable = !await _unitOfWork.Bookings.HasOverlappingBookingAsync(
                        room.Id, checkIn, checkOut);

                    if (isAvailable)
                    {
                        availableRooms.Add(room);
                    }
                }

                return availableRooms;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error getting available rooms: {ex.Message}");
            }
        }

        // Additional helper methods
        public async Task<IEnumerable<BookingDto>> GetTodayCheckInsAsync()
        {
            var bookings = await _unitOfWork.Bookings.GetTodayCheckInsAsync();
            return _mapper.Map<IEnumerable<BookingDto>>(bookings);
        }

        public async Task<IEnumerable<BookingDto>> GetTodayCheckOutsAsync()
        {
            var bookings = await _unitOfWork.Bookings.GetTodayCheckOutsAsync();
            return _mapper.Map<IEnumerable<BookingDto>>(bookings);
        }

        public async Task<int> GetBookingCountByStatusAsync(string status)
        {
            return await _unitOfWork.Bookings.GetBookingCountByStatusAsync(status);
        }

        public async Task<decimal> GetTotalRevenueAsync(DateTime? startDate = null, DateTime? endDate = null)
        {
            return await _unitOfWork.Bookings.GetTotalRevenueAsync(startDate, endDate);
        }

        public async Task<BookingStatistics> GetBookingStatisticsAsync()
        {
            var totalBookings = await _unitOfWork.Bookings.GetTotalBookingsCountAsync();
            var pendingBookings = await GetBookingCountByStatusAsync("Pending");
            var confirmedBookings = await GetBookingCountByStatusAsync("Confirmed");
            var checkedInBookings = await GetBookingCountByStatusAsync("CheckedIn");
            var completedBookings = await GetBookingCountByStatusAsync("Completed");
            var cancelledBookings = await GetBookingCountByStatusAsync("Cancelled");
            var totalRevenue = await GetTotalRevenueAsync();

            return new BookingStatistics
            {
                TotalBookings = totalBookings,
                PendingBookings = pendingBookings,
                ConfirmedBookings = confirmedBookings,
                CheckedInBookings = checkedInBookings,
                CompletedBookings = completedBookings,
                CancelledBookings = cancelledBookings,
                TotalRevenue = totalRevenue
            };
        }

        private string GenerateConfirmationCode()
        {
            var timestamp = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
            var random = new Random().Next(1000, 9999);
            return $"BK{timestamp}{random}";
        }

        Task<Core.Interfaces.Services.BookingStatistics> IBookingService.GetBookingStatisticsAsync()
        {
            throw new NotImplementedException();
        }
    }

    public class BookingStatistics
    {
        public int TotalBookings { get; set; }
        public int PendingBookings { get; set; }
        public int ConfirmedBookings { get; set; }
        public int CheckedInBookings { get; set; }
        public int CompletedBookings { get; set; }
        public int CancelledBookings { get; set; }
        public decimal TotalRevenue { get; set; }
    }
}