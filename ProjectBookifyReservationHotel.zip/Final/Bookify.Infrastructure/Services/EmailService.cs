﻿using Bookify.Core.Interfaces.Services;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Services
{
    public class EmailService : IEmailService
    {
        private readonly string _smtpServer;
        private readonly int _smtpPort;
        private readonly string _fromEmail;
        private readonly string _fromPassword;

        public EmailService(string smtpServer, int smtpPort, string fromEmail, string fromPassword)
        {
            _smtpServer = smtpServer;
            _smtpPort = smtpPort;
            _fromEmail = fromEmail;
            _fromPassword = fromPassword;
        }

        public async Task SendBookingConfirmationAsync(string email, string userName, string confirmationCode, string bookingDetails)
        {
            var subject = $"Booking Confirmation - {confirmationCode}";
            var body = $@"
                <h2>Booking Confirmation</h2>
                <p>Dear {userName},</p>
                <p>Your booking has been confirmed!</p>
                <p><strong>Confirmation Code:</strong> {confirmationCode}</p>
                <p><strong>Booking Details:</strong></p>
                <p>{bookingDetails}</p>
                <p>Thank you for choosing our hotel!</p>
            ";

            await SendEmailAsync(email, subject, body);
        }

        public async Task SendBookingCancellationAsync(string email, string userName, string confirmationCode)
        {
            var subject = $"Booking Cancelled - {confirmationCode}";
            var body = $@"
                <h2>Booking Cancellation</h2>
                <p>Dear {userName},</p>
                <p>Your booking with confirmation code <strong>{confirmationCode}</strong> has been cancelled.</p>
                <p>If you have any questions, please contact us.</p>
            ";

            await SendEmailAsync(email, subject, body);
        }

        public async Task SendPaymentConfirmationAsync(string email, string userName, string transactionId, decimal amount)
        {
            var subject = "Payment Confirmation";
            var body = $@"
                <h2>Payment Received</h2>
                <p>Dear {userName},</p>
                <p>We have received your payment.</p>
                <p><strong>Transaction ID:</strong> {transactionId}</p>
                <p><strong>Amount:</strong> {amount:C}</p>
                <p>Thank you!</p>
            ";

            await SendEmailAsync(email, subject, body);
        }

        public async Task SendContactFormEmailAsync(string name, string email, string subject, string message)
        {
            var emailSubject = $"Contact Form: {subject}";
            var body = $@"
                <h2>New Contact Form Submission</h2>
                <p><strong>Name:</strong> {name}</p>
                <p><strong>Email:</strong> {email}</p>
                <p><strong>Subject:</strong> {subject}</p>
                <p><strong>Message:</strong></p>
                <p>{message}</p>
            ";

            await SendEmailAsync(_fromEmail, emailSubject, body);
        }

        private async Task SendEmailAsync(string toEmail, string subject, string body)
        {
            using var client = new SmtpClient(_smtpServer, _smtpPort)
            {
                EnableSsl = true,
                Credentials = new NetworkCredential(_fromEmail, _fromPassword)
            };

            var mailMessage = new MailMessage
            {
                From = new MailAddress(_fromEmail),
                Subject = subject,
                Body = body,
                IsBodyHtml = true
            };

            mailMessage.To.Add(toEmail);

            await client.SendMailAsync(mailMessage);
        }
    }
}