﻿using Bookify.Core.Interfaces.Services;
using System;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Services
{
    public class SimulatedPaymentGateway : IPaymentGateway
    {
        private readonly Random _random = new Random();

        public async Task<PaymentResult> ProcessPaymentAsync(PaymentRequest request)
        {
            // Simulate API call delay
            await Task.Delay(1000);

            // Simulate payment processing with 90% success rate
            var success = _random.Next(100) < 90;

            var transactionId = $"TXN{DateTime.UtcNow:yyyyMMddHHmmss}{_random.Next(1000, 9999)}";

            if (success)
            {
                return new PaymentResult
                {
                    Success = true,
                    TransactionId = transactionId,
                    Message = "Payment processed successfully",
                    GatewayResponse = "{\"status\":\"approved\",\"code\":\"00\"}",
                    PaymentStatus = "Completed"
                };
            }
            else
            {
                return new PaymentResult
                {
                    Success = false,
                    TransactionId = transactionId,
                    Message = "Payment declined by bank",
                    GatewayResponse = "{\"status\":\"declined\",\"code\":\"05\"}",
                    PaymentStatus = "Failed"
                };
            }
        }

        public async Task<RefundResult> ProcessRefundAsync(RefundRequest request)
        {
            // Simulate API call delay
            await Task.Delay(800);

            var refundId = $"REF{DateTime.UtcNow:yyyyMMddHHmmss}{_random.Next(1000, 9999)}";

            return new RefundResult
            {
                Success = true,
                RefundId = refundId,
                Message = "Refund processed successfully"
            };
        }

        public async Task<bool> ValidatePaymentAsync(PaymentRequest request)
        {
            // Simulate validation delay
            await Task.Delay(300);

            // Basic validation
            if (request.Amount <= 0)
                return false;

            if (request.PaymentMethod == "CreditCard")
            {
                if (string.IsNullOrEmpty(request.CardNumber) || request.CardNumber.Length < 13)
                    return false;

                if (string.IsNullOrEmpty(request.ExpiryDate) || !IsValidExpiryDate(request.ExpiryDate))
                    return false;

                if (string.IsNullOrEmpty(request.CVV) || request.CVV.Length < 3)
                    return false;
            }

            return true;
        }

        private bool IsValidExpiryDate(string expiryDate)
        {
            if (string.IsNullOrEmpty(expiryDate) || expiryDate.Length != 5 || expiryDate[2] != '/')
                return false;

            var parts = expiryDate.Split('/');
            if (parts.Length != 2 || !int.TryParse(parts[0], out int month) || !int.TryParse(parts[1], out int year))
                return false;

            if (month < 1 || month > 12)
                return false;

            var currentYear = DateTime.Now.Year % 100;
            var currentMonth = DateTime.Now.Month;

            if (year < currentYear || (year == currentYear && month < currentMonth))
                return false;

            return true;
        }
    }
}