﻿using AutoMapper;
using Bookify.Core.DTOs;
using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Core.Interfaces.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Services
{
    public class RoomTypeService : IRoomTypeService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public RoomTypeService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        #region Room Type Methods

        public async Task<IEnumerable<RoomTypeDto>> GetAllRoomTypesAsync()
        {
            var roomTypes = await _unitOfWork.RoomTypes.GetRoomTypesWithImagesAsync();
            return await MapRoomTypesToDtos(roomTypes);
        }

        public async Task<RoomTypeDto> GetRoomTypeByIdAsync(int id)
        {
            var roomType = await _unitOfWork.RoomTypes.GetRoomTypeWithDetailsAsync(id);
            if (roomType == null)
                return null;

            return await MapRoomTypeToDto(roomType);
        }

        public async Task<IEnumerable<RoomTypeDto>> GetActiveRoomTypesAsync()
        {
            var roomTypes = await _unitOfWork.RoomTypes.GetActiveRoomTypesAsync();
            return await MapRoomTypesToDtos(roomTypes);
        }

        public async Task<IEnumerable<RoomTypeDto>> GetPopularRoomTypesAsync(int count = 5)
        {
            var roomTypes = await _unitOfWork.RoomTypes.GetPopularRoomTypesAsync(count);
            return await MapRoomTypesToDtos(roomTypes);
        }

        public async Task<RoomTypeDto> CreateRoomTypeAsync(CreateRoomTypeDto dto)
        {
            var roomType = _mapper.Map<RoomType>(dto);
            roomType.CreatedDate = DateTime.UtcNow;
            roomType.IsActive = true;

            // Handle amenities if provided
            if (dto.AmenityIds != null && dto.AmenityIds.Any())
            {
                roomType.RoomTypeAmenities = dto.AmenityIds.Select(amenityId => new RoomTypeAmenity
                {
                    RoomTypeId = roomType.Id,
                    AmenityId = amenityId,
                    CreatedDate = DateTime.UtcNow
                }).ToList();
            }

            await _unitOfWork.RoomTypes.AddAsync(roomType);
            await _unitOfWork.SaveChangesAsync();

            // Reload with details to get all relationships
            var createdRoomType = await _unitOfWork.RoomTypes.GetRoomTypeWithDetailsAsync(roomType.Id);
            return await MapRoomTypeToDto(createdRoomType);
        }

        public async Task<RoomTypeDto> UpdateRoomTypeAsync(UpdateRoomTypeDto dto)
        {
            var roomType = await _unitOfWork.RoomTypes.GetRoomTypeWithDetailsAsync(dto.Id);
            if (roomType == null)
                throw new Exception("Room type not found");

            // Update basic properties
            roomType.Name = dto.Name;
            roomType.Description = dto.Description;
            roomType.PricePerNight = dto.PricePerNight;
            roomType.Capacity = dto.Capacity;
            roomType.SizeInSqFt = dto.SizeInSqFt;
            roomType.IsActive = dto.IsActive;
            roomType.UpdatedDate = DateTime.UtcNow;

            // Update amenities if provided
            if (dto.AmenityIds != null)
            {
                // Remove existing amenities
                roomType.RoomTypeAmenities?.Clear();

                // Add new amenities
                if (dto.AmenityIds.Any())
                {
                    roomType.RoomTypeAmenities = dto.AmenityIds.Select(amenityId => new RoomTypeAmenity
                    {
                        RoomTypeId = roomType.Id,
                        AmenityId = amenityId,
                        CreatedDate = DateTime.UtcNow
                    }).ToList();
                }
            }

            await _unitOfWork.RoomTypes.UpdateAsync(roomType);
            await _unitOfWork.SaveChangesAsync();

            // Reload with details
            var updatedRoomType = await _unitOfWork.RoomTypes.GetRoomTypeWithDetailsAsync(roomType.Id);
            return await MapRoomTypeToDto(updatedRoomType);
        }

        public async Task<bool> DeleteRoomTypeAsync(int id)
        {
            var roomType = await _unitOfWork.RoomTypes.GetByIdAsync(id);
            if (roomType == null)
                return false;

            // Check if there are any bookings for this room type
            var hasBookings = await _unitOfWork.Bookings.FindAsync(b =>
                b.RoomTypeId == id && b.BookingStatus != "Cancelled");

            if (hasBookings.Any())
                throw new InvalidOperationException("Cannot delete room type with active bookings");

            await _unitOfWork.RoomTypes.DeleteAsync(roomType);
            await _unitOfWork.SaveChangesAsync();

            return true;
        }

        public async Task<bool> ToggleRoomTypeStatusAsync(int id)
        {
            var roomType = await _unitOfWork.RoomTypes.GetByIdAsync(id);
            if (roomType == null)
                return false;

            roomType.IsActive = !roomType.IsActive;
            roomType.UpdatedDate = DateTime.UtcNow;

            await _unitOfWork.RoomTypes.UpdateAsync(roomType);
            await _unitOfWork.SaveChangesAsync();

            return true;
        }

        public async Task<Core.Interfaces.RoomTypeStatistics> GetRoomTypeStatisticsAsync(int roomTypeId)
        {
            return await _unitOfWork.RoomTypes.GetRoomTypeStatisticsAsync(roomTypeId);
        }

        #endregion

        #region Room Methods

        public async Task<IEnumerable<RoomDto>> GetAllRoomsAsync()
        {
            var rooms = await _unitOfWork.Rooms.GetAllAsync();
            return _mapper.Map<IEnumerable<RoomDto>>(rooms);
        }

        public async Task<IEnumerable<RoomWithDetailsDto>> GetAllRoomsWithDetailsAsync()
        {
            var rooms = await _unitOfWork.Rooms.GetRoomsWithDetailsAsync();
            var roomDtos = new List<RoomWithDetailsDto>();

            foreach (var room in rooms)
            {
                var dto = _mapper.Map<RoomWithDetailsDto>(room);

                // Calculate booking statistics
                dto.TotalBookings = room.Bookings?.Count ?? 0;
                dto.ActiveBookings = room.Bookings?.Count(b =>
                    b.BookingStatus == "Confirmed" || b.BookingStatus == "CheckedIn") ?? 0;

                roomDtos.Add(dto);
            }

            return roomDtos;
        }

        public async Task<RoomDto> GetRoomByIdAsync(int id)
        {
            var room = await _unitOfWork.Rooms.GetRoomWithDetailsAsync(id);
            if (room == null)
                return null;

            return _mapper.Map<RoomDto>(room);
        }

        public async Task<bool> CreateRoomAsync(CreateRoomDto dto)
        {
            // Check if room number already exists
            var roomExists = await _unitOfWork.Rooms.RoomNumberExistsAsync(dto.RoomNumber);
            if (roomExists)
                throw new InvalidOperationException($"Room with number {dto.RoomNumber} already exists");

            var room = _mapper.Map<Room>(dto);
            room.CreatedDate = DateTime.UtcNow;
            room.UpdatedDate = DateTime.UtcNow;

            await _unitOfWork.Rooms.AddAsync(room);
            await _unitOfWork.SaveChangesAsync();

            return true;
        }

        public async Task<bool> UpdateRoomAsync(UpdateRoomDto dto)
        {
            var room = await _unitOfWork.Rooms.GetByIdAsync(dto.Id);
            if (room == null)
                return false;

            // Check if room number already exists (excluding current room)
            var roomExists = await _unitOfWork.Rooms.RoomNumberExistsAsync(dto.RoomNumber, dto.Id);
            if (roomExists)
                throw new InvalidOperationException($"Room with number {dto.RoomNumber} already exists");

            _mapper.Map(dto, room);
            room.UpdatedDate = DateTime.UtcNow;

            await _unitOfWork.Rooms.UpdateAsync(room);
            await _unitOfWork.SaveChangesAsync();

            return true;
        }

        public async Task<bool> DeleteRoomAsync(int id)
        {
            var room = await _unitOfWork.Rooms.GetByIdAsync(id);
            if (room == null)
                return false;

            // Check if room has active bookings
            var hasActiveBookings = await _unitOfWork.Bookings.FindAsync(b =>
                b.RoomId == id && (b.BookingStatus == "Confirmed" || b.BookingStatus == "CheckedIn"));

            if (hasActiveBookings.Any())
                throw new InvalidOperationException("Cannot delete room with active bookings");

            await _unitOfWork.Rooms.DeleteAsync(room);
            await _unitOfWork.SaveChangesAsync();

            return true;
        }

        public async Task<bool> UpdateRoomStatusAsync(int id, string status)
        {
            var validStatuses = new[] { "Available", "Occupied", "Maintenance", "Cleaning" };
            if (!validStatuses.Contains(status))
                throw new ArgumentException("Invalid room status");

            await _unitOfWork.Rooms.UpdateRoomStatusAsync(id, status);
            await _unitOfWork.SaveChangesAsync();
            return true;
        }

        public async Task<bool> RoomNumberExistsAsync(string roomNumber, int? id = null)
        {
            return await _unitOfWork.Rooms.RoomNumberExistsAsync(roomNumber, id);
        }

        #endregion

        #region Search & Filter Methods

        public async Task<IEnumerable<RoomTypeDto>> SearchAvailableRoomsAsync(RoomSearchDto search)
        {
            var roomTypes = await _unitOfWork.RoomTypes.GetAvailableRoomTypesAsync(
                search.CheckInDate, search.CheckOutDate);

            return await MapRoomTypesToDtos(roomTypes);
        }

        public async Task<IEnumerable<RoomTypeDto>> FilterRoomTypesAsync(RoomTypeFilterDto filter)
        {
            var roomTypes = await _unitOfWork.RoomTypes.FilterRoomTypesAsync(filter);
            return await MapRoomTypesToDtos(roomTypes);
        }

        #endregion

        #region Helper Methods

        // Helper method to map multiple RoomTypes to DTOs
        private async Task<IEnumerable<RoomTypeDto>> MapRoomTypesToDtos(IEnumerable<RoomType> roomTypes)
        {
            var roomTypeDtos = new List<RoomTypeDto>();

            foreach (var roomType in roomTypes)
            {
                var dto = await MapRoomTypeToDto(roomType);
                roomTypeDtos.Add(dto);
            }

            return roomTypeDtos;
        }

        // Helper method to map RoomType to RoomTypeDto with additional calculations
        private async Task<RoomTypeDto> MapRoomTypeToDto(RoomType roomType)
        {
            var dto = _mapper.Map<RoomTypeDto>(roomType);

            // Calculate room statistics
            dto.TotalRooms = roomType.Rooms?.Count ?? 0;
            dto.AvailableRooms = roomType.Rooms?.Count(r => r.Status == "Available") ?? 0;

            // Calculate booking statistics
            dto.TotalBookings = roomType.Bookings?.Count(b => b.BookingStatus != "Cancelled") ?? 0;

            // Set amenity IDs
            dto.AmenityIds = roomType.RoomTypeAmenities?.Select(rta => rta.AmenityId).ToList() ?? new List<int>();

            // Calculate average rating and total reviews
            if (roomType.Reviews != null)
            {
                var approvedReviews = roomType.Reviews.Where(r => r.IsApproved).ToList();
                dto.TotalReviews = approvedReviews.Count;
                dto.AverageRating = approvedReviews.Any() ? approvedReviews.Average(r => r.Rating) : 0;
            }
            else
            {
                dto.TotalReviews = 0;
                dto.AverageRating = 0;
            }

            return dto;
        }

        // Helper method to get available rooms count for a room type
        private int GetAvailableRoomsCount(RoomType roomType)
        {
            return roomType.Rooms?.Count(r => r.Status == "Available") ?? 0;
        }

        // Helper method to get total rooms count for a room type
        private int GetTotalRoomsCount(RoomType roomType)
        {
            return roomType.Rooms?.Count ?? 0;
        }

        // Helper method to get total bookings for a room type
        private int GetTotalBookingsCount(RoomType roomType)
        {
            return roomType.Bookings?.Count(b => b.BookingStatus != "Cancelled") ?? 0;
        }

        Task<Core.Interfaces.Services.RoomTypeStatistics> IRoomTypeService.GetRoomTypeStatisticsAsync(int roomTypeId)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}