﻿using Bookify.Core.Interfaces;
using Bookify.Core.Interfaces.Services;
using Bookify.Infrastructure.Repositories;
using Bookify.Infrastructure.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Bookify.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services)
        {
            // Register Services
            services.AddScoped<IDashboardService, DashboardService>();

            // Register Repositories
            services.AddScoped<IBookingRepository, BookingRepository>();
            services.AddScoped<IRoomRepository, RoomRepository>();
            services.AddScoped<IRoomTypeRepository, RoomTypeRepository>();
            services.AddScoped<IPaymentRepository, PaymentRepository>();
            services.AddScoped<IReviewRepository, ReviewRepository>();
            services.AddScoped<IAmenityRepository, AmenityRepository>();
            services.AddScoped<IImageRepository, ImageRepository>();

            // Unit of Work
            services.AddScoped<IUnitOfWork, UnitOfWork.UnitOfWork>();

            return services;
        }
    }
}