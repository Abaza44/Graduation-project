﻿namespace Bookify.Infrastructure
{
    public class Class1
    {

    }
}
