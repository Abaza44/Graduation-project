﻿using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Repositories
{
    public class RoomRepository : GenericRepository<Room>, IRoomRepository
    {
        public RoomRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<IEnumerable<Room>> GetRoomsWithDetailsAsync()
        {
            return await _context.Rooms
                .Include(r => r.RoomType)
                .ToListAsync();
        }

        public async Task<Room> GetRoomWithDetailsAsync(int id)
        {
            return await _context.Rooms
                .Include(r => r.RoomType)
                .FirstOrDefaultAsync(r => r.Id == id);
        }

        public async Task<IEnumerable<Room>> GetAvailableRoomsAsync()
        {
            return await _context.Rooms
                .Where(r => r.Status == "Available")
                .Include(r => r.RoomType)
                .ToListAsync();
        }

        public async Task<IEnumerable<Room>> GetRoomsByTypeAsync(int roomTypeId)
        {
            return await _context.Rooms
                .Where(r => r.RoomTypeId == roomTypeId)
                .Include(r => r.RoomType)
                .ToListAsync();
        }

        public async Task<IEnumerable<Room>> GetRoomsByStatusAsync(string status)
        {
            return await _context.Rooms
                .Where(r => r.Status == status)
                .Include(r => r.RoomType)
                .ToListAsync();
        }

        public async Task<bool> RoomNumberExistsAsync(string roomNumber, int? id = null)
        {
            if (id.HasValue)
            {
                return await _context.Rooms
                    .AnyAsync(r => r.RoomNumber == roomNumber && r.Id != id.Value);
            }
            return await _context.Rooms
                .AnyAsync(r => r.RoomNumber == roomNumber);
        }

        public async Task UpdateRoomStatusAsync(int roomId, string status)
        {
            var room = await _context.Rooms.FindAsync(roomId);
            if (room != null)
            {
                room.Status = status;
                room.UpdatedDate = DateTime.UtcNow;
                _context.Rooms.Update(room);
            }
        }
        // أضف هذه الطريقة إلى RoomRepository.cs
        public async Task<IEnumerable<Room>> FindAsync(Func<Room, bool> predicate)
        {
            var rooms = await _context.Rooms
                .Include(r => r.RoomType)
                .Include(r => r.Bookings)
                .ToListAsync();

            return rooms.Where(predicate);
        }
    }
}