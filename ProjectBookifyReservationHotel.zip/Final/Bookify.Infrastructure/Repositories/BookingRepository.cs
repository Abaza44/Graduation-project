﻿using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Core.DTOs;
using Bookify.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Repositories
{
    public class BookingRepository : GenericRepository<Booking>, IBookingRepository
    {
        public BookingRepository(ApplicationDbContext context) : base(context)
        {
        }

        // الطريقة الأساسية - تأكد من أنها تطابق الواجهة تماماً
        public async Task<Booking> GetBookingWithDetailsAsync(int id)
        {
            return await _context.Bookings
                .Include(b => b.Room)
                    .ThenInclude(r => r.RoomType)
                .Include(b => b.User)
                .Include(b => b.Payments)
                .FirstOrDefaultAsync(b => b.Id == id);
        }

        // باقي الطرق تبقى كما هي...
        public async Task<IEnumerable<Booking>> GetBookingsByUserAsync(string userId)
        {
            return await _context.Bookings
                .Where(b => b.UserId == userId)
                .Include(b => b.Room)
                    .ThenInclude(r => r.RoomType)
                .Include(b => b.Payments)
                .OrderByDescending(b => b.BookingDate)
                .ToListAsync();
        }

        public async Task<Booking> GetBookingByConfirmationCodeAsync(string confirmationCode)
        {
            return await _context.Bookings
                .Include(b => b.Room)
                    .ThenInclude(r => r.RoomType)
                .Include(b => b.User)
                .Include(b => b.Payments)
                .FirstOrDefaultAsync(b => b.ConfirmationCode == confirmationCode);
        }

        public async Task<IEnumerable<Booking>> GetBookingsByDateRangeAsync(DateTime startDate, DateTime endDate)
        {
            return await _context.Bookings
                .Where(b => b.CheckInDate >= startDate && b.CheckInDate <= endDate)
                .Include(b => b.Room)
                    .ThenInclude(r => r.RoomType)
                .Include(b => b.User)
                .OrderBy(b => b.CheckInDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<Booking>> GetBookingsByStatusAsync(string status)
        {
            return await _context.Bookings
                .Where(b => b.BookingStatus == status)
                .Include(b => b.Room)
                    .ThenInclude(r => r.RoomType)
                .Include(b => b.User)
                .OrderByDescending(b => b.BookingDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<Booking>> FilterBookingsAsync(BookingFilterDto filter)
        {
            var query = _context.Bookings
                .Include(b => b.Room)
                    .ThenInclude(r => r.RoomType)
                .Include(b => b.User)
                .AsQueryable();

            if (!string.IsNullOrEmpty(filter.ConfirmationCode))
                query = query.Where(b => b.ConfirmationCode.Contains(filter.ConfirmationCode));

            if (filter.CheckInDateFrom.HasValue)
                query = query.Where(b => b.CheckInDate >= filter.CheckInDateFrom.Value);

            if (filter.CheckInDateTo.HasValue)
                query = query.Where(b => b.CheckInDate <= filter.CheckInDateTo.Value);

            if (!string.IsNullOrEmpty(filter.BookingStatus))
                query = query.Where(b => b.BookingStatus == filter.BookingStatus);

            if (!string.IsNullOrEmpty(filter.UserId))
                query = query.Where(b => b.UserId == filter.UserId);

            return await query
                .OrderByDescending(b => b.BookingDate)
                .Skip((filter.PageNumber - 1) * filter.PageSize)
                .Take(filter.PageSize)
                .ToListAsync();
        }

        public async Task<IEnumerable<Booking>> GetTodayCheckInsAsync()
        {
            var today = DateTime.Today;
            return await _context.Bookings
                .Where(b => b.CheckInDate.Date == today && b.BookingStatus == "Confirmed")
                .Include(b => b.Room)
                    .ThenInclude(r => r.RoomType)
                .Include(b => b.User)
                .ToListAsync();
        }

        public async Task<IEnumerable<Booking>> GetTodayCheckOutsAsync()
        {
            var today = DateTime.Today;
            return await _context.Bookings
                .Where(b => b.CheckOutDate.Date == today && b.BookingStatus == "CheckedIn")
                .Include(b => b.Room)
                    .ThenInclude(r => r.RoomType)
                .Include(b => b.User)
                .ToListAsync();
        }

        public async Task<bool> HasOverlappingBookingAsync(int roomId, DateTime checkIn, DateTime checkOut, int? excludeBookingId = null)
        {
            var query = _context.Bookings.Where(b =>
                b.RoomId == roomId &&
                b.BookingStatus != "Cancelled" &&
                b.CheckInDate < checkOut &&
                b.CheckOutDate > checkIn
            );

            if (excludeBookingId.HasValue)
                query = query.Where(b => b.Id != excludeBookingId.Value);

            return await query.AnyAsync();
        }

        public async Task<int> GetTotalBookingsCountAsync(DateTime? date = null)
        {
            if (date.HasValue)
            {
                return await _context.Bookings
                    .Where(b => b.BookingDate.Date == date.Value.Date)
                    .CountAsync();
            }

            return await _context.Bookings.CountAsync();
        }

        public async Task<decimal> GetTotalRevenueAsync(DateTime? startDate = null, DateTime? endDate = null)
        {
            var query = _context.Bookings.Where(b =>
                b.BookingStatus != "Cancelled" &&
                b.BookingStatus != "Pending"
            );

            if (startDate.HasValue)
                query = query.Where(b => b.BookingDate >= startDate.Value);

            if (endDate.HasValue)
                query = query.Where(b => b.BookingDate <= endDate.Value);

            var total = await query.SumAsync(b => (decimal?)b.TotalAmount);
            return total ?? 0;
        }

        public async Task<IEnumerable<Room>> GetAvailableRoomsForBookingAsync(int roomTypeId, DateTime checkIn, DateTime checkOut)
        {
            return await _context.Rooms
                .Where(r => r.RoomTypeId == roomTypeId &&
                           r.Status == "Available" &&
                           !r.Bookings.Any(b =>
                               b.BookingStatus != "Cancelled" &&
                               b.CheckInDate < checkOut &&
                               b.CheckOutDate > checkIn))
                .Include(r => r.RoomType)
                .ToListAsync();
        }

        public async Task<int> GetBookingCountByStatusAsync(string status)
        {
            return await _context.Bookings
                .CountAsync(b => b.BookingStatus == status);
        }
    }
}