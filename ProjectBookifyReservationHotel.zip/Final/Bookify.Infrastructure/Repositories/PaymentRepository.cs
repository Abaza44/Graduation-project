﻿using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Core.DTOs;
using Bookify.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Repositories
{
    public class PaymentRepository : GenericRepository<Payment>, IPaymentRepository
    {
        public PaymentRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<Payment> GetPaymentWithDetailsAsync(int id)
        {
            var payment = await _context.Payments
                .Include(p => p.Booking)
                    .ThenInclude(b => b.Room)
                .Include(p => p.Booking)
                    .ThenInclude(b => b.User)
                .FirstOrDefaultAsync(p => p.Id == id);

            return payment ?? throw new Exception($"Payment with ID {id} not found");
        }

        public async Task<Payment> GetPaymentByTransactionIdAsync(string transactionId)
        {
            var payment = await _context.Payments
                .Include(p => p.Booking)
                .FirstOrDefaultAsync(p => p.TransactionId == transactionId);

            return payment ?? throw new Exception($"Payment with transaction ID {transactionId} not found");
        }

        public async Task<IEnumerable<Payment>> GetPaymentsByBookingAsync(int bookingId)
        {
            return await _context.Payments
                .Where(p => p.BookingId == bookingId)
                .Include(p => p.Booking)
                .OrderByDescending(p => p.PaymentDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<Payment>> GetPaymentsByUserAsync(string userId)
        {
            return await _context.Payments
                .Include(p => p.Booking)
                .Where(p => p.Booking.UserId == userId)
                .OrderByDescending(p => p.PaymentDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<Payment>> FilterPaymentsAsync(PaymentFilterDto filter)
        {
            var query = _context.Payments
                .Include(p => p.Booking)
                .AsQueryable();

            if (!string.IsNullOrEmpty(filter.TransactionId))
                query = query.Where(p => p.TransactionId.Contains(filter.TransactionId));

            if (!string.IsNullOrEmpty(filter.PaymentStatus))
                query = query.Where(p => p.PaymentStatus == filter.PaymentStatus);

            if (!string.IsNullOrEmpty(filter.PaymentMethod))
                query = query.Where(p => p.PaymentMethod == filter.PaymentMethod);

            if (filter.StartDate.HasValue)
                query = query.Where(p => p.PaymentDate >= filter.StartDate.Value);

            if (filter.EndDate.HasValue)
                query = query.Where(p => p.PaymentDate <= filter.EndDate.Value);

            if (filter.MinAmount.HasValue)
                query = query.Where(p => p.Amount >= filter.MinAmount.Value);

            if (filter.MaxAmount.HasValue)
                query = query.Where(p => p.Amount <= filter.MaxAmount.Value);

            return await query
                .OrderByDescending(p => p.PaymentDate)
                .Skip((filter.PageNumber - 1) * filter.PageSize)
                .Take(filter.PageSize)
                .ToListAsync();
        }

        public async Task<IEnumerable<Payment>> GetPaymentsByStatusAsync(string status)
        {
            return await _context.Payments
                .Where(p => p.PaymentStatus == status)
                .Include(p => p.Booking)
                .OrderByDescending(p => p.PaymentDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<Payment>> GetPendingPaymentsAsync()
        {
            return await _context.Payments
                .Where(p => p.PaymentStatus == "Pending")
                .Include(p => p.Booking)
                .OrderBy(p => p.PaymentDate)
                .ToListAsync();
        }

        public async Task<decimal> GetTotalRevenueAsync(DateTime? startDate = null, DateTime? endDate = null)
        {
            var query = _context.Payments.Where(p => p.PaymentStatus == "Completed");

            if (startDate.HasValue)
                query = query.Where(p => p.PaymentDate >= startDate.Value);

            if (endDate.HasValue)
                query = query.Where(p => p.PaymentDate <= endDate.Value);

            var total = await query.SumAsync(p => (decimal?)p.Amount);
            return total ?? 0;
        }

        public async Task<int> GetPaymentCountByStatusAsync(string status)
        {
            return await _context.Payments
                .CountAsync(p => p.PaymentStatus == status);
        }

        public async Task<bool> TransactionIdExistsAsync(string transactionId)
        {
            return await _context.Payments
                .AnyAsync(p => p.TransactionId == transactionId);
        }
    }
}