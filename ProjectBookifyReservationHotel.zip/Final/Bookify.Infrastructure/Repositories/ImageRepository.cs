﻿using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Repositories
{
    public class ImageRepository : GenericRepository<Image>, IImageRepository
    {
        public ImageRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<IEnumerable<Image>> GetImagesByRoomTypeAsync(int roomTypeId)
        {
            return await _context.Images
                .Where(i => i.RoomTypeId == roomTypeId)
                .OrderBy(i => i.IsPrimary ? 0 : 1)
                .ThenBy(i => i.CreatedDate)
                .ToListAsync();
        }

        public async Task<Image> GetPrimaryImageAsync(int roomTypeId)
        {
            return await _context.Images
                .FirstOrDefaultAsync(i => i.RoomTypeId == roomTypeId && i.IsPrimary);
        }

        public async Task<bool> SetPrimaryImageAsync(int imageId)
        {
            var image = await _context.Images
                .Include(i => i.RoomType)
                .FirstOrDefaultAsync(i => i.Id == imageId);

            if (image == null)
                return false;

            // Remove primary status from all images of this room type
            var roomTypeImages = await _context.Images
                .Where(i => i.RoomTypeId == image.RoomTypeId)
                .ToListAsync();

            foreach (var img in roomTypeImages)
            {
                img.IsPrimary = (img.Id == imageId);
            }

            await _context.SaveChangesAsync();
            return true;
        }
    }
}