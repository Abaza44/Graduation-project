﻿using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Core.DTOs;
using Bookify.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Repositories
{
    public class RoomTypeRepository : GenericRepository<RoomType>, IRoomTypeRepository
    {
        public RoomTypeRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<IEnumerable<RoomType>> GetActiveRoomTypesAsync()
        {
            return await _dbSet
                .Where(rt => rt.IsActive)
                .Include(rt => rt.Images)
                .Include(rt => rt.RoomTypeAmenities)
                    .ThenInclude(rta => rta.Amenity)
                .Include(rt => rt.Rooms)
                .Include(rt => rt.Reviews)
                .Include(rt => rt.Bookings)
                .ToListAsync();
        }

        public async Task<RoomType> GetRoomTypeWithDetailsAsync(int id)
        {
            return await _dbSet
                .Include(rt => rt.Images)
                .Include(rt => rt.RoomTypeAmenities)
                    .ThenInclude(rta => rta.Amenity)
                .Include(rt => rt.Reviews)
                .Include(rt => rt.Rooms)
                .Include(rt => rt.Bookings)
                .FirstOrDefaultAsync(rt => rt.Id == id);
        }

        public async Task<IEnumerable<RoomType>> GetRoomTypesWithImagesAsync()
        {
            return await _dbSet
                .Include(rt => rt.Images)
                .Include(rt => rt.RoomTypeAmenities)
                    .ThenInclude(rta => rta.Amenity)
                .Include(rt => rt.Rooms)
                .Include(rt => rt.Reviews)
                .Include(rt => rt.Bookings)
                .Where(rt => rt.IsActive)
                .ToListAsync();
        }

        public async Task<IEnumerable<RoomType>> FilterRoomTypesAsync(RoomTypeFilterDto filter)
        {
            var query = _dbSet
                .Include(rt => rt.Images)
                .Include(rt => rt.RoomTypeAmenities)
                    .ThenInclude(rta => rta.Amenity)
                .Include(rt => rt.Rooms)
                .Include(rt => rt.Reviews)
                .Include(rt => rt.Bookings)
                .Where(rt => rt.IsActive);

            if (filter.MinPrice.HasValue)
                query = query.Where(rt => rt.PricePerNight >= filter.MinPrice.Value);

            if (filter.MaxPrice.HasValue)
                query = query.Where(rt => rt.PricePerNight <= filter.MaxPrice.Value);

            if (filter.MinCapacity.HasValue)
                query = query.Where(rt => rt.Capacity >= filter.MinCapacity.Value);

            if (filter.MaxCapacity.HasValue)
                query = query.Where(rt => rt.Capacity <= filter.MaxCapacity.Value);

            if (filter.AmenityIds != null && filter.AmenityIds.Any())
            {
                query = query.Where(rt => rt.RoomTypeAmenities
                    .Any(rta => filter.AmenityIds.Contains(rta.AmenityId)));
            }

            // Sorting
            query = filter.SortBy?.ToLower() switch
            {
                "price" => filter.SortOrder == "desc"
                    ? query.OrderByDescending(rt => rt.PricePerNight)
                    : query.OrderBy(rt => rt.PricePerNight),
                "capacity" => filter.SortOrder == "desc"
                    ? query.OrderByDescending(rt => rt.Capacity)
                    : query.OrderBy(rt => rt.Capacity),
                "rating" => filter.SortOrder == "desc"
                    ? query.OrderByDescending(rt => rt.Reviews.Where(r => r.IsApproved).Average(r => (double?)r.Rating) ?? 0)
                    : query.OrderBy(rt => rt.Reviews.Where(r => r.IsApproved).Average(r => (double?)r.Rating) ?? 0),
                "popularity" => filter.SortOrder == "desc"
                    ? query.OrderByDescending(rt => rt.Bookings.Count(b => b.BookingStatus != "Cancelled"))
                    : query.OrderBy(rt => rt.Bookings.Count(b => b.BookingStatus != "Cancelled")),
                _ => query.OrderBy(rt => rt.Name)
            };

            return await query
                .Skip((filter.PageNumber - 1) * filter.PageSize)
                .Take(filter.PageSize)
                .ToListAsync();
        }

        public async Task<IEnumerable<RoomType>> GetAvailableRoomTypesAsync(DateTime checkIn, DateTime checkOut)
        {
            return await _dbSet
                .Include(rt => rt.Images)
                .Include(rt => rt.Rooms)
                .Include(rt => rt.RoomTypeAmenities)
                    .ThenInclude(rta => rta.Amenity)
                .Include(rt => rt.Reviews)
                .Include(rt => rt.Bookings)
                .Where(rt => rt.IsActive && rt.Rooms.Any(r =>
                    r.Status == "Available" &&
                    !r.Bookings.Any(b =>
                        b.BookingStatus != "Cancelled" &&
                        b.CheckInDate < checkOut &&
                        b.CheckOutDate > checkIn
                    )
                ))
                .ToListAsync();
        }

        public async Task<double> GetAverageRatingAsync(int roomTypeId)
        {
            var reviews = await _context.Reviews
                .Where(r => r.RoomTypeId == roomTypeId && r.IsApproved)
                .ToListAsync();

            if (!reviews.Any())
                return 0;

            return reviews.Average(r => r.Rating);
        }

        public async Task<IEnumerable<RoomType>> GetAllRoomTypesWithAmenitiesAsync()
        {
            return await _dbSet
                .Include(rt => rt.RoomTypeAmenities)
                    .ThenInclude(rta => rta.Amenity)
                .Include(rt => rt.Rooms)
                .Include(rt => rt.Reviews)
                .Include(rt => rt.Bookings)
                .ToListAsync();
        }

        public async Task<bool> IsAmenityUsedAsync(int amenityId)
        {
            return await _context.RoomTypeAmenities
                .AnyAsync(rta => rta.AmenityId == amenityId);
        }

        // New method to get room type statistics
        public async Task<RoomTypeStatistics> GetRoomTypeStatisticsAsync(int roomTypeId)
        {
            var roomType = await _dbSet
                .Include(rt => rt.Rooms)
                .Include(rt => rt.Bookings)
                .Include(rt => rt.Reviews)
                .FirstOrDefaultAsync(rt => rt.Id == roomTypeId);

            if (roomType == null)
                return new RoomTypeStatistics();

            return new RoomTypeStatistics
            {
                TotalRooms = roomType.Rooms?.Count ?? 0,
                AvailableRooms = roomType.Rooms?.Count(r => r.Status == "Available") ?? 0,
                TotalBookings = roomType.Bookings?.Count(b => b.BookingStatus != "Cancelled") ?? 0,
                TotalReviews = roomType.Reviews?.Count(r => r.IsApproved) ?? 0,
                AverageRating = roomType.Reviews?.Where(r => r.IsApproved).Average(r => r.Rating) ?? 0
            };
        }

        // New method to get popular room types
        public async Task<IEnumerable<RoomType>> GetPopularRoomTypesAsync(int count = 5)
        {
            return await _dbSet
                .Include(rt => rt.Images)
                .Include(rt => rt.RoomTypeAmenities)
                    .ThenInclude(rta => rta.Amenity)
                .Include(rt => rt.Rooms)
                .Include(rt => rt.Bookings)
                .Include(rt => rt.Reviews)
                .Where(rt => rt.IsActive)
                .OrderByDescending(rt => rt.Bookings.Count(b => b.BookingStatus != "Cancelled"))
                .ThenByDescending(rt => rt.Reviews.Where(r => r.IsApproved).Average(r => (double?)r.Rating) ?? 0)
                .Take(count)
                .ToListAsync();
        }

        Task<Core.Interfaces.RoomTypeStatistics> IRoomTypeRepository.GetRoomTypeStatisticsAsync(int roomTypeId)
        {
            throw new NotImplementedException();
        }
    }

    // Helper class for room type statistics
    public class RoomTypeStatistics
    {
        public int TotalRooms { get; set; }
        public int AvailableRooms { get; set; }
        public int TotalBookings { get; set; }
        public int TotalReviews { get; set; }
        public double AverageRating { get; set; }
    }
}