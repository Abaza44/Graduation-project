﻿using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Repositories
{
    public class ReviewRepository : GenericRepository<Review>, IReviewRepository
    {
        public ReviewRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<IEnumerable<Review>> GetReviewsByRoomTypeAsync(int roomTypeId)
        {
            return await _context.Reviews
                .Where(r => r.RoomTypeId == roomTypeId)
                .Include(r => r.User)
                .OrderByDescending(r => r.CreatedDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<Review>> GetReviewsByUserAsync(string userId)
        {
            return await _context.Reviews
                .Where(r => r.UserId == userId)
                .Include(r => r.RoomType)
                .OrderByDescending(r => r.CreatedDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<Review>> GetApprovedReviewsAsync()
        {
            return await _context.Reviews
                .Where(r => r.IsApproved)
                .Include(r => r.User)
                .Include(r => r.RoomType)
                .OrderByDescending(r => r.CreatedDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<Review>> GetPendingReviewsAsync()
        {
            return await _context.Reviews
                .Where(r => !r.IsApproved)
                .Include(r => r.User)
                .Include(r => r.RoomType)
                .OrderBy(r => r.CreatedDate)
                .ToListAsync();
        }

        public async Task<double> GetAverageRatingAsync(int roomTypeId)
        {
            var reviews = await _context.Reviews
                .Where(r => r.RoomTypeId == roomTypeId && r.IsApproved)
                .ToListAsync();

            if (!reviews.Any())
                return 0;

            return reviews.Average(r => r.Rating);
        }

        public async Task<int> GetReviewCountAsync(int roomTypeId)
        {
            return await _context.Reviews
                .CountAsync(r => r.RoomTypeId == roomTypeId && r.IsApproved);
        }
    }
}