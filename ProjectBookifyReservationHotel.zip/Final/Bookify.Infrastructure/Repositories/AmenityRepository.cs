﻿using Bookify.Core.Entities;
using Bookify.Core.Interfaces;
using Bookify.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bookify.Infrastructure.Repositories
{
    public class AmenityRepository : GenericRepository<Amenity>, IAmenityRepository
    {
        public AmenityRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<IEnumerable<Amenity>> GetAmenitiesByRoomTypeAsync(int roomTypeId)
        {
            return await _context.RoomTypeAmenities
                .Where(rta => rta.RoomTypeId == roomTypeId)
                .Include(rta => rta.Amenity)
                .Select(rta => rta.Amenity)
                .ToListAsync();
        }

        public async Task<IEnumerable<Amenity>> GetPopularAmenitiesAsync(int count = 10)
        {
            return await _context.RoomTypeAmenities
                .GroupBy(rta => rta.AmenityId)
                .OrderByDescending(g => g.Count())
                .Take(count)
                .Select(g => g.First().Amenity)
                .ToListAsync();
        }

        public async Task<bool> IsAmenityUsedAsync(int amenityId)
        {
            return await _context.RoomTypeAmenities
                .AnyAsync(rta => rta.AmenityId == amenityId);
        }
    }
}