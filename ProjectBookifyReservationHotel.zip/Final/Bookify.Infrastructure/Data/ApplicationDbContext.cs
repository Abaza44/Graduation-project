﻿using Bookify.Core.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace Bookify.Infrastructure.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<RoomType> RoomTypes { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Review> Reviews { get; set; }
        public DbSet<Amenity> Amenities { get; set; }
        public DbSet<RoomTypeAmenity> RoomTypeAmenities { get; set; }
        public DbSet<Image> Images { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // RoomType Configuration
            modelBuilder.Entity<RoomType>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Description).HasMaxLength(1000);
                entity.Property(e => e.PricePerNight).HasColumnType("decimal(18,2)");
                entity.Property(e => e.SizeInSqFt).HasColumnType("decimal(10,2)");

                entity.HasMany(e => e.Rooms)
                    .WithOne(e => e.RoomType)
                    .HasForeignKey(e => e.RoomTypeId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasMany(e => e.Images)
                    .WithOne(e => e.RoomType)
                    .HasForeignKey(e => e.RoomTypeId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasMany(e => e.Reviews)
                    .WithOne(e => e.RoomType)
                    .HasForeignKey(e => e.RoomTypeId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasMany(e => e.Bookings)
                    .WithOne(e => e.RoomType)
                    .HasForeignKey(e => e.RoomTypeId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Room Configuration
            modelBuilder.Entity<Room>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.RoomNumber).IsRequired().HasMaxLength(20);
                entity.Property(e => e.Status).IsRequired().HasMaxLength(20);
                entity.Property(e => e.AdditionalNotes).HasMaxLength(500);

                entity.HasIndex(e => e.RoomNumber).IsUnique();

                entity.HasMany(e => e.Bookings)
                    .WithOne(e => e.Room)
                    .HasForeignKey(e => e.RoomId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Booking Configuration - التصحيح هنا
            modelBuilder.Entity<Booking>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.TotalAmount).HasColumnType("decimal(18,2)");
                entity.Property(e => e.ConfirmationCode).IsRequired().HasMaxLength(50);
                entity.Property(e => e.BookingStatus).IsRequired().HasMaxLength(20);
                entity.Property(e => e.SpecialRequests).HasMaxLength(1000);
                entity.Property(e => e.CancellationReason).HasMaxLength(500);

                entity.HasIndex(e => e.ConfirmationCode).IsUnique();

                entity.HasOne(e => e.User)
                    .WithMany(e => e.Bookings)
                    .HasForeignKey(e => e.UserId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.RoomType)
                    .WithMany(e => e.Bookings)
                    .HasForeignKey(e => e.RoomTypeId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.Room)
                    .WithMany(e => e.Bookings)
                    .HasForeignKey(e => e.RoomId)
                    .OnDelete(DeleteBehavior.Restrict);

                // التصحيح: تغيير العلاقة من One-to-One إلى One-to-Many
                entity.HasMany(e => e.Payments)
                    .WithOne(e => e.Booking)
                    .HasForeignKey(e => e.BookingId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // Payment Configuration - التصحيح هنا
            modelBuilder.Entity<Payment>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Amount).HasColumnType("decimal(18,2)");
                entity.Property(e => e.PaymentMethod).IsRequired().HasMaxLength(50);
                entity.Property(e => e.TransactionId).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Currency).HasMaxLength(10).HasDefaultValue("USD");
                entity.Property(e => e.PaymentStatus).IsRequired().HasMaxLength(20);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.Property(e => e.PaymentResponse).HasMaxLength(1000);
                entity.Property(e => e.LastFourDigits).HasMaxLength(4);
                entity.Property(e => e.CardType).HasMaxLength(50);

                entity.HasIndex(e => e.TransactionId).IsUnique();

                // إزالة RefundAmount إذا لم يكن موجوداً في الكيان
                // entity.Property(e => e.RefundAmount).HasColumnType("decimal(18,2)");
            });

            // Review Configuration
            modelBuilder.Entity<Review>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Comment).IsRequired().HasMaxLength(1000);
                entity.Property(e => e.Title).IsRequired().HasMaxLength(100);

                entity.HasOne(e => e.User)
                    .WithMany(e => e.Reviews)
                    .HasForeignKey(e => e.UserId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.RoomType)
                    .WithMany(e => e.Reviews)
                    .HasForeignKey(e => e.RoomTypeId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Amenity Configuration
            modelBuilder.Entity<Amenity>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.Property(e => e.IconClass).HasMaxLength(50);
            });

            // RoomTypeAmenity (Many-to-Many) Configuration
            modelBuilder.Entity<RoomTypeAmenity>(entity =>
            {
                entity.HasKey(e => new { e.RoomTypeId, e.AmenityId });

                entity.HasOne(e => e.RoomType)
                    .WithMany(e => e.RoomTypeAmenities)
                    .HasForeignKey(e => e.RoomTypeId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(e => e.Amenity)
                    .WithMany(e => e.RoomTypeAmenities)
                    .HasForeignKey(e => e.AmenityId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // Image Configuration
            modelBuilder.Entity<Image>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ImageUrl).IsRequired().HasMaxLength(500);
                entity.Property(e => e.AltText).HasMaxLength(100);
            });

            // Seed Data
            SeedData(modelBuilder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            // Seed Amenities
            modelBuilder.Entity<Amenity>().HasData(
                new Amenity { Id = 1, Name = "WiFi", Description = "Free WiFi", IconClass = "fa-wifi", CreatedDate = DateTime.UtcNow },
                new Amenity { Id = 2, Name = "Air Conditioning", Description = "Air Conditioning", IconClass = "fa-snowflake", CreatedDate = DateTime.UtcNow },
                new Amenity { Id = 3, Name = "TV", Description = "Flat Screen TV", IconClass = "fa-tv", CreatedDate = DateTime.UtcNow },
                new Amenity { Id = 4, Name = "Mini Bar", Description = "Mini Bar", IconClass = "fa-glass-martini", CreatedDate = DateTime.UtcNow },
                new Amenity { Id = 5, Name = "Safe", Description = "Safety Deposit Box", IconClass = "fa-lock", CreatedDate = DateTime.UtcNow },
                new Amenity { Id = 6, Name = "Breakfast", Description = "Breakfast Included", IconClass = "fa-utensils", CreatedDate = DateTime.UtcNow },
                new Amenity { Id = 7, Name = "Sea View", Description = "Sea View", IconClass = "fa-water", CreatedDate = DateTime.UtcNow },
                new Amenity { Id = 8, Name = "Balcony", Description = "Private Balcony", IconClass = "fa-door-open", CreatedDate = DateTime.UtcNow }
            );

            // Seed RoomTypes
            modelBuilder.Entity<RoomType>().HasData(
                new RoomType
                {
                    Id = 1,
                    Name = "Standard Room",
                    Description = "Comfortable room with basic amenities",
                    PricePerNight = 150,
                    Capacity = 2,
                    SizeInSqFt = 25,
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow,
                    ImageUrl = "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80"


                },
                new RoomType
                {
                    Id = 2,
                    Name = "Deluxe Room",
                    Description = "Spacious room with premium amenities",
                    PricePerNight = 250,
                    Capacity = 3,
                    SizeInSqFt = 35,
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow,
                    ImageUrl = "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80"

                },
                new RoomType
                {
                    Id = 3,
                    Name = "Suite",
                    Description = "Luxury suite with living area and premium services",
                    PricePerNight = 450,
                    Capacity = 4,
                    SizeInSqFt = 60,
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow,

                },
                new RoomType
                {
                    Id = 4,
                    Name = "Family Room",
                    Description = "Large room perfect for families",
                    PricePerNight = 350,
                    Capacity = 5,
                    SizeInSqFt = 45,
                    IsActive = true,
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                }
            );

            // Seed Rooms
            var rooms = new List<Room>();
            int roomId = 1;

            // Standard Rooms (101-110)
            for (int i = 1; i <= 10; i++)
            {
                rooms.Add(new Room
                {
                    Id = roomId++,
                    RoomTypeId = 1,
                    RoomNumber = $"10{i}",
                    Floor = "1",
                    View = i <= 5 ? "City View" : "Garden View",
                    Status = "Available",
                    AdditionalNotes = "Standard room with basic amenities",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                });
            }

            // Deluxe Rooms (201-208)
            for (int i = 1; i <= 8; i++)
            {
                rooms.Add(new Room
                {
                    Id = roomId++,
                    RoomTypeId = 2,
                    RoomNumber = $"20{i}",
                    Floor = "2",
                    View = i <= 4 ? "Sea View" : "City View",
                    Status = "Available",
                    AdditionalNotes = "Deluxe room with premium amenities",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                });
            }

            // Suites (301-305)
            for (int i = 1; i <= 5; i++)
            {
                rooms.Add(new Room
                {
                    Id = roomId++,
                    RoomTypeId = 3,
                    RoomNumber = $"30{i}",
                    Floor = "3",
                    View = "Sea View",
                    Status = "Available",
                    AdditionalNotes = "Luxury suite with premium services",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                });
            }

            // Family Rooms (401-407)
            for (int i = 1; i <= 7; i++)
            {
                rooms.Add(new Room
                {
                    Id = roomId++,
                    RoomTypeId = 4,
                    RoomNumber = $"40{i}",
                    Floor = "4",
                    View = i <= 3 ? "Sea View" : "Garden View",
                    Status = "Available",
                    AdditionalNotes = "Spacious family room",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                });
            }

            modelBuilder.Entity<Room>().HasData(rooms);

            // Seed RoomType-Amenity relationships
            modelBuilder.Entity<RoomTypeAmenity>().HasData(
                // Standard Room amenities
                new RoomTypeAmenity { RoomTypeId = 1, AmenityId = 1, CreatedDate = DateTime.UtcNow }, // WiFi
                new RoomTypeAmenity { RoomTypeId = 1, AmenityId = 2, CreatedDate = DateTime.UtcNow }, // AC
                new RoomTypeAmenity { RoomTypeId = 1, AmenityId = 3, CreatedDate = DateTime.UtcNow }, // TV

                // Deluxe Room amenities
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 1, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 2, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 3, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 4, CreatedDate = DateTime.UtcNow }, // Mini Bar
                new RoomTypeAmenity { RoomTypeId = 2, AmenityId = 6, CreatedDate = DateTime.UtcNow }, // Breakfast

                // Suite amenities
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 1, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 2, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 3, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 4, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 5, CreatedDate = DateTime.UtcNow }, // Safe
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 6, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 7, CreatedDate = DateTime.UtcNow }, // Sea View
                new RoomTypeAmenity { RoomTypeId = 3, AmenityId = 8, CreatedDate = DateTime.UtcNow }, // Balcony

                // Family Room amenities
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 1, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 2, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 3, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 4, CreatedDate = DateTime.UtcNow },
                new RoomTypeAmenity { RoomTypeId = 4, AmenityId = 6, CreatedDate = DateTime.UtcNow }
            );
        }
    }
}