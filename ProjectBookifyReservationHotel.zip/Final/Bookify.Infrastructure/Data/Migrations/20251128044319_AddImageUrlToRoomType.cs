﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Bookify.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddImageUrlToRoomType : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ImageUrl",
                table: "RoomTypes",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3656));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3658));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3660));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 4,
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3661));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 5,
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3662));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 6,
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3664));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 7,
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3665));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 8,
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3666));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 1, 1 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4034));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 2, 1 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4035));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 3, 1 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4036));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 1, 2 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4036));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 2, 2 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4037));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 3, 2 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4038));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 4, 2 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4039));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 6, 2 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4040));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 1, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4040));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 2, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4041));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 3, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4042));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 4, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4043));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 5, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4044));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 6, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4045));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 7, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4045));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 8, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4046));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 1, 4 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4047));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 2, 4 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4048));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 3, 4 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4049));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 4, 4 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4049));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 6, 4 },
                column: "CreatedDate",
                value: new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(4050));

            migrationBuilder.UpdateData(
                table: "RoomTypes",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedDate", "ImageUrl", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3849), "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80", new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3850) });

            migrationBuilder.UpdateData(
                table: "RoomTypes",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CreatedDate", "ImageUrl", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3853), "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80", new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3854) });

            migrationBuilder.UpdateData(
                table: "RoomTypes",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CreatedDate", "ImageUrl", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3856), "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80", new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3856) });

            migrationBuilder.UpdateData(
                table: "RoomTypes",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CreatedDate", "ImageUrl", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3877), "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80", new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3877) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3918), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3918) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3922), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3922) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3924), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3924) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3926), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3926) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3928), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3928) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3931), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3931) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 7,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3933), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3933) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 8,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3935), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3935) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 9,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3937), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3937) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 10,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3942), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3942) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3946), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3946) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 12,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3948), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3948) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 13,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3950), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3950) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 14,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3952), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3952) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 15,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3954), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3954) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 16,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3955), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3956) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 17,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3957), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3957) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 18,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3960), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3960) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 19,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3963), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3963) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 20,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3965), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3965) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 21,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3967), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3967) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 22,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3968), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3969) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 23,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3970), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3970) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 24,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3973), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3973) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 25,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3975), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3976) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 26,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3977), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3977) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 27,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3979), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3979) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 28,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3981), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3981) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 29,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3983), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3983) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 30,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3984), new DateTime(2025, 11, 28, 4, 43, 19, 66, DateTimeKind.Utc).AddTicks(3984) });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ImageUrl",
                table: "RoomTypes");

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(5773));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(5777));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(5780));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 4,
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(5782));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 5,
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(5785));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 6,
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(5788));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 7,
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(5791));

            migrationBuilder.UpdateData(
                table: "Amenities",
                keyColumn: "Id",
                keyValue: 8,
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(5794));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 1, 1 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7095));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 2, 1 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7098));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 3, 1 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7100));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 1, 2 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7101));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 2, 2 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7103));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 3, 2 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7105));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 4, 2 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7107));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 6, 2 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7108));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 1, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7110));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 2, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7112));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 3, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7114));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 4, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7115));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 5, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7117));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 6, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7119));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 7, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7121));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 8, 3 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7122));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 1, 4 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7124));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 2, 4 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7126));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 3, 4 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7128));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 4, 4 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7129));

            migrationBuilder.UpdateData(
                table: "RoomTypeAmenities",
                keyColumns: new[] { "AmenityId", "RoomTypeId" },
                keyValues: new object[] { 6, 4 },
                column: "CreatedDate",
                value: new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(7131));

            migrationBuilder.UpdateData(
                table: "RoomTypes",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6483), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6484) });

            migrationBuilder.UpdateData(
                table: "RoomTypes",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6491), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6492) });

            migrationBuilder.UpdateData(
                table: "RoomTypes",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6497), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6498) });

            migrationBuilder.UpdateData(
                table: "RoomTypes",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6503), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6504) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6596), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6598) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6612), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6613) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6618), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6619) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6624), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6625) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6630), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6631) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6640), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6641) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 7,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6646), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6647) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 8,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6652), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6653) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 9,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6658), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6659) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 10,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6672), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6673) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6683), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6684) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 12,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6689), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6690) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 13,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6695), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6695) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 14,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6700), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6701) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 15,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6706), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6707) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 16,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6711), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6712) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 17,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6717), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6718) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 18,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6726), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6727) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 19,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6734), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6736) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 20,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6740), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6741) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 21,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6746), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6746) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 22,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6751), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6752) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 23,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6757), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6757) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 24,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6764), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6765) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 25,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6876), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6877) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 26,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6882), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6883) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 27,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6888), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6889) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 28,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6894), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6895) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 29,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6899), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6900) });

            migrationBuilder.UpdateData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 30,
                columns: new[] { "CreatedDate", "UpdatedDate" },
                values: new object[] { new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6905), new DateTime(2025, 10, 25, 20, 4, 8, 945, DateTimeKind.Utc).AddTicks(6906) });
        }
    }
}
