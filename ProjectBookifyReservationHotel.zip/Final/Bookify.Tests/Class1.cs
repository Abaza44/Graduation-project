﻿namespace Bookify.Tests
{
    public class Class1
    {

    }
}
